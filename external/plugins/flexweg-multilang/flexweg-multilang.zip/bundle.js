import { pathToPublicUrl as S, getActiveTheme as se, renderMarkdown as Te, markdownToPlainText as ae, renderPageToHtml as re, renderHome as Pe, updatePost as ie, buildRssFeedXml as B, uploadFile as V, publishPostsJson as $e, publishAuthorsJson as ke, useCmsData as oe, toast as q, isValidSlug as le, fetchAllPosts as X } from "@flexweg/cms-runtime";
import { jsxs as w, jsx as p } from "react/jsx-runtime";
import { useState as K } from "react";
import { useTranslation as ce } from "react-i18next";
const Me = {
  title: "Multi-language",
  intro: "Configure additional languages. Each enabled language gets its own URL prefix and per-post translations.",
  save: "Save settings",
  saving: "Saving…",
  saved: "Saved.",
  primaryLanguage: {
    title: "Primary language",
    help: "Pages in this language live at the root URL (no language prefix). All other languages render under /<lang>/.",
    siteHint: 'Site language is currently "{{lang}}".'
  },
  enabledLanguages: {
    title: "Additional languages",
    help: "Click a language to toggle it. Enabled languages appear in the editor's Translations tab + on the public site under /<lang>/."
  },
  homePages: {
    title: "Home page per language",
    help: "Optional: pick a static page (in the corresponding language) to render at /<lang>/. Leave empty for a basic latest-posts list.",
    none: "— Latest posts —"
  },
  switcher: {
    title: "Language switcher",
    help: "Show a language switcher on the public site. Themes must include a [data-cms-langswitch] container in their Header / Footer for the switcher to appear (built-in themes already do).",
    header: "Show switcher in the site header",
    footer: "Show switcher in the site footer"
  }
}, Ce = {
  label: "Translations",
  noLanguages: "No additional languages are configured for this site.",
  configureLanguages: "Configure languages",
  editPrimaryInMain: "Edit the primary language in the main editor (title, slug, content above).",
  save: "Save translations",
  saving: "Saving…",
  saved: "Translations saved.",
  duplicate: "Duplicate from primary",
  invalidSlug: "Invalid slug for {{lang}}.",
  fields: {
    title: "Title",
    slug: "Slug",
    slugHelp: "Lower-case ASCII + dashes only.",
    excerpt: "Excerpt",
    content: "Content (Markdown)",
    contentHelp: "Plain Markdown. Theme blocks (Hero, embeds, etc.) embedded in the primary language do NOT replicate automatically — paste your translated body here.",
    seo: "SEO",
    seoTitle: "SEO title",
    seoDescription: "Meta description"
  }
}, Ne = {
  title: "Translations",
  name: "Name",
  slug: "Slug",
  invalidSlug: "Invalid slug",
  noLanguages: "Enable secondary languages in the Multi-language plugin settings to translate this term."
}, Ie = {
  settings: Me,
  tab: Ce,
  termSection: Ne
}, Ue = {
  title: "Multilingue",
  intro: "Configurez les langues supplémentaires. Chaque langue activée obtient son préfixe d'URL et des traductions par contenu.",
  save: "Sauvegarder",
  saving: "Sauvegarde…",
  saved: "Sauvegardé.",
  primaryLanguage: {
    title: "Langue principale",
    help: "Les pages dans cette langue se trouvent à la racine du site (sans préfixe). Les autres langues sont sous /<lang>/.",
    siteHint: "La langue du site est actuellement « {{lang}} »."
  },
  enabledLanguages: {
    title: "Langues supplémentaires",
    help: "Cliquez une langue pour l'activer. Les langues activées apparaissent dans l'onglet Traductions de l'éditeur et sur le site public sous /<lang>/."
  },
  homePages: {
    title: "Page d'accueil par langue",
    help: "Optionnel : choisissez une page statique (dans la langue correspondante) pour servir d'accueil à /<lang>/. Sinon, une liste des derniers articles est rendue.",
    none: "— Derniers articles —"
  },
  switcher: {
    title: "Sélecteur de langue",
    help: "Affiche un sélecteur de langue sur le site public. Les thèmes doivent intégrer un conteneur [data-cms-langswitch] dans leur Header / Footer pour que le sélecteur apparaisse (les thèmes intégrés le font déjà).",
    header: "Afficher le sélecteur dans l'en-tête du site",
    footer: "Afficher le sélecteur dans le pied de page du site"
  }
}, Ae = {
  label: "Traductions",
  noLanguages: "Aucune langue supplémentaire n'est configurée.",
  configureLanguages: "Configurer les langues",
  editPrimaryInMain: "Modifiez la langue principale dans l'éditeur (titre, slug, contenu ci-dessus).",
  save: "Sauvegarder les traductions",
  saving: "Sauvegarde…",
  saved: "Traductions sauvegardées.",
  duplicate: "Dupliquer depuis la langue principale",
  invalidSlug: "Slug invalide pour {{lang}}.",
  fields: {
    title: "Titre",
    slug: "Slug",
    slugHelp: "Caractères ASCII minuscules + tirets uniquement.",
    excerpt: "Extrait",
    content: "Contenu (Markdown)",
    contentHelp: "Markdown simple. Les blocs de thème (Hero, embeds, etc.) intégrés dans la langue principale ne sont PAS répliqués automatiquement — collez votre contenu traduit ici.",
    seo: "SEO",
    seoTitle: "Titre SEO",
    seoDescription: "Méta description"
  }
}, He = {
  title: "Traductions",
  name: "Nom",
  slug: "Slug",
  invalidSlug: "Slug invalide",
  noLanguages: "Activez des langues secondaires dans les réglages du plugin Multilingue pour traduire ce terme."
}, Fe = {
  settings: Ue,
  tab: Ae,
  termSection: He
}, H = {
  primaryLanguage: "en",
  enabledLanguages: [],
  homePages: {},
  menuTranslations: {},
  showHeaderSwitcher: !0,
  showFooterSwitcher: !1
}, _e = "flexweg-multilang";
function b(n) {
  var t;
  const e = (t = n.pluginConfigs) == null ? void 0 : t[_e];
  return {
    ...H,
    // Default the primary language to the site's BCP-47 language tag
    // so a fresh install picks the right value without manual setup.
    primaryLanguage: (e == null ? void 0 : e.primaryLanguage) || (n.language || "en").split("-")[0],
    enabledLanguages: (e == null ? void 0 : e.enabledLanguages) ?? [],
    homePages: (e == null ? void 0 : e.homePages) ?? {},
    menuTranslations: (e == null ? void 0 : e.menuTranslations) ?? {},
    showHeaderSwitcher: (e == null ? void 0 : e.showHeaderSwitcher) ?? H.showHeaderSwitcher,
    showFooterSwitcher: (e == null ? void 0 : e.showFooterSwitcher) ?? H.showFooterSwitcher
  };
}
function f(n, e) {
  return n.primaryLanguage === e;
}
function F(n) {
  const { post: e, trans: t, primaryTermTrans: s, primaryTermSlug: a, language: r, config: o } = n, i = f(o, r) ? "" : `${r}/`;
  if (e.type === "page")
    return `${i}${t.slug}.html`;
  const l = (s == null ? void 0 : s.slug) ?? a;
  return l ? `${i}${l}/${t.slug}.html` : `${i}${t.slug}.html`;
}
function _(n, e, t, s) {
  if (n.type !== "category")
    throw new Error(`buildLocalizedTermUrl: term type "${n.type}" is not supported (categories only).`);
  return `${f(s, t) ? "" : `${t}/`}${e.slug}/index.html`;
}
function E(n, e) {
  return f(e, n) ? "index.html" : `${n}/index.html`;
}
function $(n, e) {
  const t = n.translations, s = t == null ? void 0 : t[e];
  return !s || !s.slug || !s.title ? null : s;
}
function P(n, e) {
  const t = n.translations, s = t == null ? void 0 : t[e];
  return !s || !s.slug || !s.name ? null : s;
}
function D(n) {
  return {
    slug: n.slug,
    title: n.title,
    contentMarkdown: n.contentMarkdown,
    excerpt: n.excerpt,
    seo: n.seo
  };
}
function z(n) {
  return {
    slug: n.slug,
    name: n.name,
    description: n.description
  };
}
function W(n) {
  const e = n.replace("-", "_");
  return e.includes("_") ? e : {
    en: "en_US",
    fr: "fr_FR",
    es: "es_ES",
    de: "de_DE",
    nl: "nl_NL",
    pt: "pt_PT",
    ko: "ko_KR",
    it: "it_IT",
    ja: "ja_JP"
  }[e] ?? `${e}_${e.toUpperCase()}`;
}
function T(n) {
  return n.replace(/[&<>"']/g, (e) => {
    switch (e) {
      case "&":
        return "&amp;";
      case "<":
        return "&lt;";
      case ">":
        return "&gt;";
      case '"':
        return "&quot;";
      default:
        return "&apos;";
    }
  });
}
function R(n, e, t) {
  const s = e.replace(/\/+$/, "");
  if (!s) return "";
  const a = [];
  for (const o of n.alternates) {
    const i = S(s, o.path);
    a.push(
      `<link rel="alternate" hreflang="${T(o.language)}" href="${T(i)}" />`
    );
  }
  const r = n.alternates.find((o) => o.language === t.primaryLanguage);
  if (r) {
    const o = S(s, r.path);
    a.push(`<link rel="alternate" hreflang="x-default" href="${T(o)}" />`);
  }
  a.push(
    `<meta property="og:locale" content="${T(W(n.current.language))}" />`
  );
  for (const o of n.alternates)
    o.language !== n.current.language && a.push(
      `<meta property="og:locale:alternate" content="${T(W(o.language))}" />`
    );
  return a.join(`
`);
}
function ue(n, e, t) {
  const s = e.replace(/\/+$/, "");
  if (!s || n.alternates.length === 0) return "";
  const a = [];
  for (const o of n.alternates) {
    const i = S(s, o.path);
    a.push(
      `    <xhtml:link rel="alternate" hreflang="${T(o.language)}" href="${T(i)}"/>`
    );
  }
  const r = n.alternates.find((o) => o.language === t.primaryLanguage);
  if (r) {
    const o = S(s, r.path);
    a.push(
      `    <xhtml:link rel="alternate" hreflang="x-default" href="${T(o)}"/>`
    );
  }
  return a.join(`
`);
}
function O(n, e, t) {
  const s = [];
  for (const a of [t.primaryLanguage, ...t.enabledLanguages]) {
    if (s.some((c) => c.language === a)) continue;
    const r = a === t.primaryLanguage ? D(n) : $(n, a);
    if (!r) continue;
    const o = n.primaryTermId ? e.find((c) => c.id === n.primaryTermId) : void 0, i = o ? a === t.primaryLanguage ? z(o) : P(o, a) ?? void 0 : void 0;
    if (o && !i && !f(t, a)) continue;
    const l = F({
      post: n,
      trans: r,
      primaryTermTrans: i,
      primaryTermSlug: o == null ? void 0 : o.slug,
      language: a,
      config: t
    });
    s.push({ language: a, path: l });
  }
  return s;
}
function ge(n, e) {
  const t = [];
  for (const s of [e.primaryLanguage, ...e.enabledLanguages]) {
    if (t.some((r) => r.language === s)) continue;
    const a = s === e.primaryLanguage ? z(n) : P(n, s);
    a && n.type === "category" && t.push({ language: s, path: _(n, a, s, e) });
  }
  return t;
}
function de(n) {
  const e = [];
  for (const t of [n.primaryLanguage, ...n.enabledLanguages])
    e.some((s) => s.language === t) || e.push({ language: t, path: E(t, n) });
  return e;
}
function pe(n) {
  return (n.baseUrl || "").replace(/\/+$/, "");
}
const N = /* @__PURE__ */ new Map();
function k(n, e, t, s, a) {
  N.clear();
  const r = pe(s);
  if (!r) return;
  for (const i of [...n, ...e]) {
    if (i.status !== "online") continue;
    const l = O(i, t, a);
    if (l.length !== 0)
      for (const c of l) {
        const g = R(
          { current: { path: c.path, language: c.language }, alternates: l },
          r,
          a
        );
        N.set(c.path, g);
      }
  }
  for (const i of t) {
    if (i.type !== "category") continue;
    const l = ge(i, a);
    if (l.length !== 0)
      for (const c of l) {
        const g = R(
          { current: { path: c.path, language: c.language }, alternates: l },
          r,
          a
        );
        N.set(c.path, g);
      }
  }
  const o = de(a);
  for (const i of o) {
    const l = R(
      { current: { path: i.path, language: i.language }, alternates: o },
      r,
      a
    );
    N.set(i.path, l);
  }
}
function Ee(n) {
  const e = n.replace(/^\/+/, "");
  return N.get(e) ?? N.get(`/${e}`) ?? "";
}
const I = /* @__PURE__ */ new Map();
function M(n, e, t, s) {
  I.clear();
  for (const r of [...n, ...e]) {
    if (r.status !== "online") continue;
    const o = O(r, t, s);
    if (o.length !== 0)
      for (const i of o)
        I.set(i.path, { language: i.language, alternates: o });
  }
  for (const r of t) {
    if (r.type !== "category") continue;
    const o = ge(r, s);
    if (o.length !== 0)
      for (const i of o)
        I.set(i.path, { language: i.language, alternates: o });
  }
  const a = de(s);
  for (const r of a)
    I.set(r.path, { language: r.language, alternates: a });
}
function De(n) {
  const e = n.replace(/^\/+/, "");
  return I.get(e) ?? I.get(`/${e}`) ?? null;
}
function ze(n, e, t) {
  const s = f(t, e), a = s ? "" : `${e}/`, r = { ...n.settings, language: e }, o = n.terms.map((g) => {
    if (g.type !== "category") return g;
    const d = s ? z(g) : P(g, e);
    return d ? {
      ...g,
      name: d.name,
      // Prefix with language code so buildPostUrl produces
      // <lang>/<term-slug>/<post-slug>.html for posts and
      // <lang>/<term-slug>/index.html for the archive itself.
      slug: `${a}${d.slug}`,
      description: d.description
    } : g;
  }), i = (g) => {
    const d = s ? D(g) : $(g, e);
    if (!d) return null;
    const y = g.type !== "post" || !g.primaryTermId;
    return {
      ...g,
      title: d.title,
      slug: y ? `${a}${d.slug}` : d.slug,
      contentMarkdown: d.contentMarkdown,
      excerpt: d.excerpt,
      seo: d.seo
    };
  }, l = n.posts.map(i).filter((g) => g !== null), c = n.pages.map(i).filter((g) => g !== null);
  return {
    ...n,
    settings: r,
    posts: l,
    pages: c,
    terms: o
  };
}
async function Oe(n) {
  var i;
  const { language: e, ctx: t, config: s } = n, a = (i = s.homePages) == null ? void 0 : i[e], r = a ? { ...t.settings, homeMode: "static-page", homePageId: a } : t.settings, o = ze({ ...t, settings: r }, e, s);
  return Pe(o, {
    homePath: E(e, s),
    currentLocale: e
  });
}
function Re(n) {
  var U, A, j, J, G;
  const { post: e, trans: t, termTrans: s, language: a, ctx: r, config: o } = n, i = se(r.settings.activeThemeId), l = {
    settings: { ...r.settings, language: a },
    resolvedMenus: { header: [], footer: [] },
    themeCssPath: `theme-assets/${r.settings.activeThemeId}.css`,
    themeConfig: void 0,
    homePath: f(o, a) ? "/index.html" : `/${a}/index.html`
  }, c = Te(t.contentMarkdown), g = r.terms.filter((C) => e.termIds.includes(C.id) && C.type === "tag"), d = e.primaryTermId ? r.terms.find((C) => C.id === e.primaryTermId && C.type === "category") : void 0, y = r.authorLookup(e.authorId), u = e.heroMediaId ? r.media.get(e.heroMediaId) : void 0, h = ((U = t.seo) == null ? void 0 : U.description) ?? ae(t.contentMarkdown, 160);
  let m = d;
  if (d && s) {
    const xe = f(o, a) ? "" : `${a}/`;
    m = {
      ...d,
      name: s.name,
      slug: `${xe}${s.slug}`,
      description: s.description
    };
  }
  const L = F({
    post: e,
    trans: t,
    primaryTermTrans: s,
    primaryTermSlug: d == null ? void 0 : d.slug,
    language: a,
    config: o
  }), x = {
    site: l,
    post: {
      ...e,
      title: t.title,
      slug: t.slug,
      contentMarkdown: t.contentMarkdown,
      excerpt: t.excerpt,
      seo: t.seo
    },
    bodyHtml: c,
    author: y,
    hero: u ? {
      alt: u.alt,
      caption: u.caption,
      default: ((j = (A = u.formats) == null ? void 0 : A[u.defaultFormat ?? ""]) == null ? void 0 : j.url) ?? u.url ?? "",
      formats: u.formats ?? {}
    } : void 0,
    primaryTerm: m,
    tags: g
  }, v = {
    site: l,
    pageTitle: ((J = t.seo) == null ? void 0 : J.title) ?? t.title,
    pageDescription: h || void 0,
    ogImage: (G = t.seo) == null ? void 0 : G.ogImage,
    currentPath: L,
    currentLocale: a
  };
  return re({
    base: i.templates.base,
    baseProps: v,
    template: i.templates.single,
    templateProps: x
  });
}
function qe(n) {
  const { term: e, termTrans: t, language: s, ctx: a, config: r } = n, o = se(a.settings.activeThemeId), i = {
    settings: { ...a.settings, language: s },
    resolvedMenus: { header: [], footer: [] },
    themeCssPath: `theme-assets/${a.settings.activeThemeId}.css`,
    themeConfig: void 0,
    homePath: f(r, s) ? "/index.html" : `/${s}/index.html`
  }, l = {
    ...e,
    name: t.name,
    slug: t.slug,
    description: t.description
  }, c = f(r, s), g = c ? "" : `${s}/`, d = a.posts.filter((m) => m.status === "online" && m.primaryTermId === e.id).filter((m) => c ? !0 : $(m, s) !== null).map((m) => {
    var U, A;
    const L = c ? D(m) : $(m, s), x = F({
      post: m,
      trans: L,
      primaryTermTrans: t,
      primaryTermSlug: e.slug,
      language: s,
      config: r
    }), v = m.heroMediaId ? a.media.get(m.heroMediaId) : void 0;
    return {
      ...m,
      title: L.title,
      slug: L.slug,
      excerpt: L.excerpt,
      url: x,
      hero: v ? {
        alt: v.alt,
        caption: v.caption,
        default: ((A = (U = v.formats) == null ? void 0 : U[v.defaultFormat ?? ""]) == null ? void 0 : A.url) ?? v.url ?? "",
        formats: v.formats ?? {}
      } : void 0,
      category: {
        name: t.name,
        url: `/${g}${t.slug}/index.html`
      }
    };
  }), y = {
    site: i,
    term: l,
    posts: d,
    categoryRssUrl: void 0,
    archivesLink: void 0,
    allCategories: [],
    popularTags: []
  }, u = _(e, t, s, r), h = {
    site: i,
    pageTitle: t.name,
    pageDescription: t.description,
    currentPath: u,
    currentLocale: s
  };
  return re({
    base: o.templates.base,
    baseProps: h,
    template: o.templates.category,
    templateProps: y
  });
}
async function je(n, e, t) {
  const s = b(t.settings);
  if (s.enabledLanguages.length === 0) return n;
  k(t.posts, t.pages, t.terms, t.settings, s), M(t.posts, t.pages, t.terms, s);
  const a = [...n], r = {}, o = e.primaryTermId ? t.terms.find((i) => i.id === e.primaryTermId && i.type === "category") : void 0;
  for (const i of s.enabledLanguages) {
    if (f(s, i)) continue;
    const l = $(e, i);
    if (!l) continue;
    const c = o ? P(o, i) : void 0;
    if (o && !c) continue;
    const g = F({
      post: e,
      trans: l,
      primaryTermTrans: c ?? void 0,
      primaryTermSlug: o == null ? void 0 : o.slug,
      language: i,
      config: s
    }), d = Re({
      post: e,
      trans: l,
      termTrans: c ?? void 0,
      language: i,
      ctx: t,
      config: s
    });
    a.push({ path: g, html: d }), r[i] = g;
  }
  try {
    await ie(e.id, { lastPublishedPathsByLocale: r });
  } catch {
  }
  return a;
}
async function Je(n, e) {
  const t = b(e.settings);
  if (t.enabledLanguages.length === 0) return n;
  k(e.posts, e.pages, e.terms, e.settings, t), M(e.posts, e.pages, e.terms, t);
  const s = [...n];
  for (const a of t.enabledLanguages) {
    if (f(t, a)) continue;
    const r = E(a, t), o = await Oe({ language: a, ctx: e, config: t });
    s.push({ path: r, html: o });
    for (const i of e.terms) {
      if (i.type !== "category") continue;
      const l = P(i, a);
      if (!l) continue;
      const c = _(i, l, a, t), g = qe({ term: i, termTrans: l, language: a, ctx: e, config: t });
      s.push({ path: c, html: g });
    }
  }
  return s;
}
function Ge(n) {
  return { ...n, "xmlns:xhtml": "http://www.w3.org/1999/xhtml" };
}
function Be(n, e) {
  if (!e.entity) return n;
  const t = Ke(), s = We();
  if (!t || !s) return n;
  const a = O(e.entity, s, t);
  if (a.length === 0) return n;
  const r = e.baseUrl.replace(/\/+$/, "");
  return n + ue(
    { current: { path: e.path, language: t.primaryLanguage }, alternates: a },
    r,
    t
  ) + `
`;
}
function Ve(n, e) {
  var r, o, i, l, c, g;
  const t = b(e.settings);
  if (t.enabledLanguages.length === 0) return n;
  const s = pe(e.settings);
  if (!s) return n;
  const a = [...n];
  for (const d of [...e.posts, ...e.pages]) {
    if (d.status !== "online") continue;
    const y = ((o = (r = d.createdAt) == null ? void 0 : r.toMillis) == null ? void 0 : o.call(r)) ?? ((l = (i = d.publishedAt) == null ? void 0 : i.toMillis) == null ? void 0 : l.call(i)) ?? Date.now();
    if (new Date(y).getUTCFullYear() !== e.year) continue;
    const u = O(d, e.terms, t);
    if (u.length !== 0)
      for (const h of u)
        f(t, h.language) || a.push({
          path: h.path,
          lastmodMs: ((g = (c = d.updatedAt) == null ? void 0 : c.toMillis) == null ? void 0 : g.call(c)) ?? y,
          extraInnerXml: ue(
            { current: { path: h.path, language: h.language }, alternates: u },
            s,
            t
          )
        });
  }
  return a;
}
function Xe(n, e) {
  const t = b(e.settings);
  if (t.enabledLanguages.length === 0) return n;
  const s = [...n];
  for (const a of t.enabledLanguages)
    f(t, a) || s.push({ path: `sitemaps/sitemap-news-${a}.xml` });
  return s;
}
let me = null, he = null;
function fe(n) {
  me = n;
}
function ye(n) {
  he = n;
}
function Ke() {
  return me;
}
function We() {
  return he;
}
const be = 20;
function Y(n) {
  return `${n}/feed.xml`;
}
function Q(n, e) {
  return `${n}/${e}/${e}.xml`;
}
async function we(n) {
  const e = b(n.settings);
  if (e.enabledLanguages.length === 0) return;
  const t = (n.settings.baseUrl || "").replace(/\/+$/, "");
  if (t)
    for (const s of e.enabledLanguages) {
      if (f(e, s)) continue;
      const a = Ye(n.posts, n.terms, s, e, t), r = B({
        title: `${n.settings.title || "Site"} — ${s.toUpperCase()}`,
        link: S(t, E(s, e)),
        description: n.settings.description || n.settings.title || "",
        feedUrl: S(t, Y(s)),
        language: s,
        items: a
      });
      try {
        await V({ path: Y(s), content: r });
      } catch {
      }
      for (const o of n.terms) {
        if (o.type !== "category") continue;
        const i = P(o, s);
        if (!i) continue;
        const l = Qe(
          n.posts,
          n.terms,
          o,
          s,
          e,
          t
        ), c = B({
          title: `${n.settings.title || "Site"} — ${i.name}`,
          link: S(t, _(o, i, s, e)),
          description: i.description || i.name,
          feedUrl: S(t, Q(s, i.slug)),
          language: s,
          items: l
        });
        try {
          await V({
            path: Q(s, i.slug),
            content: c
          });
        } catch {
        }
      }
    }
}
function Ye(n, e, t, s, a) {
  return n.filter((r) => r.status === "online").map((r) => Le(r, e, t, s, a)).filter((r) => r !== null).sort((r, o) => o.pubDateMs - r.pubDateMs).slice(0, be);
}
function Qe(n, e, t, s, a, r) {
  return n.filter((o) => o.status === "online" && o.primaryTermId === t.id).map((o) => Le(o, e, s, a, r)).filter((o) => o !== null).sort((o, i) => i.pubDateMs - o.pubDateMs).slice(0, be);
}
function Le(n, e, t, s, a) {
  var y, u, h, m, L, x;
  const r = $(n, t);
  if (!r) return null;
  const o = n.primaryTermId ? e.find((v) => v.id === n.primaryTermId && v.type === "category") : void 0, i = o ? P(o, t) : void 0;
  if (o && !i) return null;
  const l = F({
    post: n,
    trans: r,
    primaryTermTrans: i ?? void 0,
    primaryTermSlug: o == null ? void 0 : o.slug,
    language: t,
    config: s
  }), c = S(a, l), g = (r.excerpt && r.excerpt.trim().length > 0 ? r.excerpt : ae(r.contentMarkdown, 300)).trim(), d = ((u = (y = n.publishedAt) == null ? void 0 : y.toMillis) == null ? void 0 : u.call(y)) ?? ((m = (h = n.updatedAt) == null ? void 0 : h.toMillis) == null ? void 0 : m.call(h)) ?? ((x = (L = n.createdAt) == null ? void 0 : L.toMillis) == null ? void 0 : x.call(L)) ?? Date.now();
  return {
    title: r.title,
    link: c,
    guid: c,
    description: g,
    pubDateMs: d,
    category: i == null ? void 0 : i.name
  };
}
function Ze(n, e, t) {
  const s = f(t, e), a = s ? "" : `${e}/`, r = n.terms.map((i) => {
    if (i.type !== "category") return i;
    const l = s ? z(i) : P(i, e);
    return l ? {
      ...i,
      name: l.name,
      slug: `${a}${l.slug}`,
      description: l.description
    } : i;
  }), o = (i) => {
    const l = s ? D(i) : $(i, e);
    if (!l) return null;
    const c = i.type !== "post" || !i.primaryTermId;
    return {
      ...i,
      title: l.title,
      slug: c ? `${a}${l.slug}` : l.slug,
      contentMarkdown: l.contentMarkdown,
      excerpt: l.excerpt,
      seo: l.seo
    };
  };
  return {
    posts: n.posts.map(o).filter((i) => i !== null),
    pages: n.pages.map(o).filter((i) => i !== null),
    terms: r
  };
}
async function ve(n) {
  const e = b(n.settings);
  if (e.enabledLanguages.length !== 0)
    for (const t of e.enabledLanguages) {
      if (f(e, t)) continue;
      const s = Ze(n, t, e), a = { ...n.settings, language: t }, r = `${t}/data/posts.json`, o = `${t}/data/authors.json`;
      try {
        await $e(
          a,
          s.posts,
          s.pages,
          s.terms,
          n.media,
          r
        );
      } catch {
      }
      try {
        await ke(
          n.users,
          n.media,
          s.posts,
          s.pages,
          o
        );
      } catch {
      }
    }
}
const Z = ["en", "fr", "de", "es", "nl", "pt", "ko"];
function et({ config: n, save: e }) {
  const { t } = ce("flexweg-multilang"), { settings: s, pages: a } = oe(), [r, o] = K({
    ...H,
    ...n
  }), [i, l] = K(!1);
  async function c() {
    l(!0);
    try {
      await e(r), q.success(t("settings.saved"));
    } catch (u) {
      q.error(u.message || "Save failed");
    } finally {
      l(!1);
    }
  }
  function g(u) {
    o((h) => {
      const L = h.enabledLanguages.includes(u) ? h.enabledLanguages.filter((x) => x !== u) : [...h.enabledLanguages, u];
      return { ...h, enabledLanguages: L };
    });
  }
  function d(u, h) {
    o((m) => ({
      ...m,
      homePages: { ...m.homePages ?? {}, [u]: h || "" }
    }));
  }
  const y = (s.language || "en").split("-")[0];
  return /* @__PURE__ */ w("div", { className: "space-y-6", children: [
    /* @__PURE__ */ w("div", { children: [
      /* @__PURE__ */ p("h2", { className: "font-semibold text-lg", children: t("settings.title") }),
      /* @__PURE__ */ p("p", { className: "text-sm text-surface-500 dark:text-surface-400", children: t("settings.intro") })
    ] }),
    /* @__PURE__ */ w("section", { className: "card p-4 space-y-3", children: [
      /* @__PURE__ */ p("h3", { className: "font-medium", children: t("settings.primaryLanguage.title") }),
      /* @__PURE__ */ p("p", { className: "text-xs text-surface-500 dark:text-surface-400", children: t("settings.primaryLanguage.help") }),
      /* @__PURE__ */ w("div", { className: "flex flex-wrap gap-2", children: [
        /* @__PURE__ */ p(
          "select",
          {
            className: "input max-w-[200px]",
            value: r.primaryLanguage,
            onChange: (u) => o({ ...r, primaryLanguage: u.target.value }),
            children: Z.map((u) => /* @__PURE__ */ p("option", { value: u, children: u.toUpperCase() }, u))
          }
        ),
        /* @__PURE__ */ p("span", { className: "text-[11px] text-surface-500 self-center", children: t("settings.primaryLanguage.siteHint", { lang: y }) })
      ] })
    ] }),
    /* @__PURE__ */ w("section", { className: "card p-4 space-y-3", children: [
      /* @__PURE__ */ p("h3", { className: "font-medium", children: t("settings.enabledLanguages.title") }),
      /* @__PURE__ */ p("p", { className: "text-xs text-surface-500 dark:text-surface-400", children: t("settings.enabledLanguages.help") }),
      /* @__PURE__ */ p("div", { className: "flex flex-wrap gap-2", children: Z.filter((u) => u !== r.primaryLanguage).map((u) => {
        const h = r.enabledLanguages.includes(u);
        return /* @__PURE__ */ p(
          "button",
          {
            type: "button",
            onClick: () => g(u),
            className: "text-xs px-3 py-1.5 rounded uppercase font-medium " + (h ? "bg-surface-900 text-surface-50 dark:bg-surface-100 dark:text-surface-900" : "bg-surface-100 text-surface-700 dark:bg-surface-800 dark:text-surface-300"),
            children: u
          },
          u
        );
      }) })
    ] }),
    r.enabledLanguages.length > 0 && /* @__PURE__ */ w("section", { className: "card p-4 space-y-3", children: [
      /* @__PURE__ */ p("h3", { className: "font-medium", children: t("settings.homePages.title") }),
      /* @__PURE__ */ p("p", { className: "text-xs text-surface-500 dark:text-surface-400", children: t("settings.homePages.help") }),
      /* @__PURE__ */ p("div", { className: "space-y-2", children: r.enabledLanguages.map((u) => {
        var h;
        return /* @__PURE__ */ w("div", { className: "flex items-center gap-2", children: [
          /* @__PURE__ */ p("span", { className: "text-[10px] uppercase font-semibold w-8", children: u }),
          /* @__PURE__ */ w(
            "select",
            {
              className: "input flex-1",
              value: ((h = r.homePages) == null ? void 0 : h[u]) ?? "",
              onChange: (m) => d(u, m.target.value),
              children: [
                /* @__PURE__ */ p("option", { value: "", children: t("settings.homePages.none") }),
                a.filter((m) => m.status === "online").map((m) => /* @__PURE__ */ p("option", { value: m.id, children: m.title }, m.id))
              ]
            }
          )
        ] }, u);
      }) })
    ] }),
    r.enabledLanguages.length > 0 && /* @__PURE__ */ w("section", { className: "card p-4 space-y-3", children: [
      /* @__PURE__ */ p("h3", { className: "font-medium", children: t("settings.switcher.title") }),
      /* @__PURE__ */ p("p", { className: "text-xs text-surface-500 dark:text-surface-400", children: t("settings.switcher.help") }),
      /* @__PURE__ */ w("label", { className: "flex items-center gap-2 text-sm", children: [
        /* @__PURE__ */ p(
          "input",
          {
            type: "checkbox",
            checked: r.showHeaderSwitcher ?? !0,
            onChange: (u) => o({ ...r, showHeaderSwitcher: u.target.checked })
          }
        ),
        /* @__PURE__ */ p("span", { children: t("settings.switcher.header") })
      ] }),
      /* @__PURE__ */ w("label", { className: "flex items-center gap-2 text-sm", children: [
        /* @__PURE__ */ p(
          "input",
          {
            type: "checkbox",
            checked: r.showFooterSwitcher ?? !1,
            onChange: (u) => o({ ...r, showFooterSwitcher: u.target.checked })
          }
        ),
        /* @__PURE__ */ p("span", { children: t("settings.switcher.footer") })
      ] })
    ] }),
    /* @__PURE__ */ p("div", { className: "flex gap-2", children: /* @__PURE__ */ p(
      "button",
      {
        type: "button",
        className: "btn-primary",
        onClick: c,
        disabled: i,
        children: t(i ? "settings.saving" : "settings.save")
      }
    ) })
  ] });
}
function tt({ term: n, updateTerm: e }) {
  const { t } = ce("flexweg-multilang"), { settings: s } = oe(), a = b(s);
  if (a.enabledLanguages.length === 0)
    return /* @__PURE__ */ p("p", { className: "text-xs text-surface-500 dark:text-surface-400", children: t("termSection.noLanguages") });
  const r = n.translations ?? {};
  function o(i, l) {
    const c = {
      ...r,
      [i]: { ...r[i] ?? ee(), ...l }
    };
    e({ translations: c });
  }
  return /* @__PURE__ */ w("div", { className: "space-y-2", children: [
    /* @__PURE__ */ p("p", { className: "text-[11px] uppercase tracking-wide font-semibold text-surface-500 dark:text-surface-400", children: t("termSection.title") }),
    a.enabledLanguages.map((i) => {
      const l = r[i] ?? ee(), c = l.slug && !le(l.slug);
      return /* @__PURE__ */ w("div", { className: "flex flex-wrap items-start gap-2", children: [
        /* @__PURE__ */ p("span", { className: "text-[10px] uppercase font-semibold w-8 pt-2 text-surface-500", children: i }),
        /* @__PURE__ */ p(
          "input",
          {
            type: "text",
            className: "input flex-1 min-w-[120px]",
            placeholder: t("termSection.name"),
            value: l.name,
            onChange: (g) => o(i, { name: g.target.value })
          }
        ),
        /* @__PURE__ */ w("div", { className: "flex-1 min-w-[120px]", children: [
          /* @__PURE__ */ p(
            "input",
            {
              type: "text",
              className: "input",
              placeholder: t("termSection.slug"),
              value: l.slug,
              onChange: (g) => o(i, { slug: g.target.value })
            }
          ),
          c && /* @__PURE__ */ p("p", { className: "text-[10px] text-red-600 mt-0.5", children: t("termSection.invalidSlug") })
        ] })
      ] }, i);
    })
  ] });
}
function ee() {
  return { slug: "", name: "", description: "" };
}
function Se(n, e, t) {
  if (t)
    return {
      title: n.title,
      slug: n.slug,
      contentMarkdown: n.contentMarkdown,
      excerpt: n.excerpt,
      seo: n.seo
    };
  const s = n.translations, a = s == null ? void 0 : s[e];
  return !a || !a.title ? null : {
    title: a.title ?? "",
    slug: a.slug ?? "",
    contentMarkdown: a.contentMarkdown ?? "",
    excerpt: a.excerpt,
    seo: a.seo
  };
}
function te(n, e, t) {
  if (t) return "★";
  const s = Se(n, e, !1);
  return s && s.slug && s.title ? "" : "○";
}
const nt = {
  id: "flexweg-multilang/languages",
  priority: 50,
  listVariants(n, e) {
    const t = b(e.settings);
    if (t.enabledLanguages.length === 0) return [];
    const s = [], a = /* @__PURE__ */ new Set();
    s.push({
      id: t.primaryLanguage,
      label: t.primaryLanguage.toUpperCase(),
      badge: te(n, t.primaryLanguage, !0),
      primary: !0
    }), a.add(t.primaryLanguage);
    for (const r of t.enabledLanguages)
      a.has(r) || (a.add(r), s.push({
        id: r,
        label: r.toUpperCase(),
        badge: te(n, r, !1),
        primary: !1
      }));
    return s;
  },
  loadFields(n, e, t) {
    const s = b(t.settings), a = f(s, e);
    return Se(n, e, a);
  },
  validate(n, e, t, s) {
    const a = b(s.settings);
    return f(a, e) ? null : t.title.trim() ? le(t.slug) ? null : `Invalid slug for ${e.toUpperCase()}.` : `Title required for ${e.toUpperCase()}.`;
  },
  async saveFields(n, e, t, s) {
    const a = b(s.settings);
    if (f(a, e))
      return;
    const r = n.translations ?? {}, o = {
      title: t.title,
      slug: t.slug,
      contentMarkdown: t.contentMarkdown
    };
    if (t.excerpt && (o.excerpt = t.excerpt), t.seo) {
      const l = {};
      t.seo.title && (l.title = t.seo.title), t.seo.description && (l.description = t.seo.description), t.seo.ogImage && (l.ogImage = t.seo.ogImage), Object.keys(l).length > 0 && (o.seo = l);
    }
    const i = { ...r, [e]: o };
    try {
      await ie(n.id, { translations: i });
    } catch (l) {
      throw q.error(l.message), l;
    }
  },
  getSlugPathPrefix(n, e, t, s) {
    var g;
    const a = b(s.settings), r = f(a, e) ? "" : `${e}/`;
    if (n.type !== "post" || !n.primaryTermId) return r;
    const o = s.terms.find((d) => d.id === n.primaryTermId);
    if (!o) return r;
    const i = o.translations, c = !f(a, e) && ((g = i == null ? void 0 : i[e]) == null ? void 0 : g.slug) || o.slug;
    return `${r}${c}/`;
  }
}, st = `
.cms-langswitch{display:inline-flex;align-items:center;gap:6px;font-size:12px;line-height:1;letter-spacing:0.05em;}
.cms-langswitch a,.cms-langswitch span{padding:4px 8px;border-radius:4px;text-decoration:none;color:inherit;text-transform:uppercase;font-weight:600;}
.cms-langswitch a{opacity:0.55;}
.cms-langswitch a:hover{opacity:1;}
.cms-langswitch__current{background:currentColor;color:transparent;position:relative;}
.cms-langswitch__current::after{content:attr(data-label);position:absolute;inset:0;display:flex;align-items:center;justify-content:center;color:var(--cms-langswitch-on,white);mix-blend-mode:difference;}
`.replace(/\s+/g, " ").trim();
function at(n) {
  return n.replace(/[<>&\u2028\u2029]/g, (e) => e === "<" ? "\\u003c" : e === ">" ? "\\u003e" : e === "&" ? "\\u0026" : e === "\u2028" ? "\\u2028" : "\\u2029");
}
function rt(n) {
  const { config: e, settings: t, currentPath: s } = n;
  if (e.enabledLanguages.length === 0 || !e.showHeaderSwitcher && !e.showFooterSwitcher) return "";
  const a = De(s);
  if (!a || a.alternates.length < 2) return "";
  const r = (t.baseUrl || "").replace(/\/+$/, ""), o = a.alternates.map((y) => ({
    lang: y.language,
    label: y.language.toUpperCase(),
    href: r ? S(r, y.path) : `/${y.path.replace(/^\/+/, "")}`
  })), i = a.language, l = e.primaryLanguage, c = {
    current: i,
    primary: l,
    items: o,
    showHeader: e.showHeaderSwitcher !== !1,
    showFooter: e.showFooterSwitcher === !0
  };
  return `<script>${`
(function(){
  try {
    var D = ${at(JSON.stringify(c))};
    function render(host) {
      var html = '<div class="cms-langswitch" role="navigation" aria-label="Language">';
      for (var i = 0; i < D.items.length; i++) {
        var it = D.items[i];
        if (it.lang === D.current) {
          html += '<span class="cms-langswitch__current" data-label="' + it.label + '" aria-current="true">' + it.label + '</span>';
        } else {
          html += '<a href="' + it.href + '" hreflang="' + it.lang + '" rel="alternate">' + it.label + '</a>';
        }
      }
      html += '</div>';
      host.innerHTML = html;
      host.removeAttribute('data-cms-langswitch-empty');
    }
    function paint() {
      if (D.showHeader) {
        var h = document.querySelector('[data-cms-langswitch="header"]');
        if (h) render(h);
      }
      if (D.showFooter) {
        var f = document.querySelector('[data-cms-langswitch="footer"]');
        if (f) render(f);
      }
      var s = document.createElement('style');
      s.setAttribute('data-cms-langswitch-css', '');
      s.textContent = ${JSON.stringify(st)};
      document.head.appendChild(s);
    }
    if (document.readyState !== 'loading') paint();
    else document.addEventListener('DOMContentLoaded', paint);
  } catch (e) {}
})();`}<\/script>`;
}
async function it(n, e) {
  const t = b(e.settings);
  fe(t), ye(e.terms), k(e.posts, e.pages, e.terms, e.settings, t), M(e.posts, e.pages, e.terms, t), await we(e), await ve(e);
}
async function ne(n, e) {
  const t = b(e.settings);
  fe(t), ye(e.terms), k(e.posts, e.pages, e.terms, e.settings, t), M(e.posts, e.pages, e.terms, t), await we(e), await ve(e);
}
async function ot() {
  try {
    const n = window, e = n == null ? void 0 : n.__FLEXWEG_LIVE_SETTINGS__;
    if (!e) return;
    const t = b(e);
    if (t.enabledLanguages.length === 0) return;
    const [s, a] = await Promise.all([
      X({ type: "post" }),
      X({ type: "page" })
    ]);
    k(s, a, [], e, t), M(s, a, [], t);
  } catch {
  }
}
const dt = {
  id: "flexweg-multilang",
  name: "Multi-language",
  version: "1.0.0",
  description: "Multi-language site support — translated posts/pages/terms, hreflang SEO, per-language sitemap entries, per-language RSS feeds.",
  author: "Flexweg",
  i18n: { en: Ie, fr: Fe },
  settings: {
    navLabelKey: "settings.title",
    defaultConfig: H,
    component: et
  },
  register(n) {
    n.addFilter("publish.additional", async (e, t, s) => je(
      e,
      t,
      s
    )), n.addFilter("publish.extraListings", async (e, t) => Je(
      e,
      t
    )), n.addAction("publish.before", async (e, t) => {
      const s = t, a = b(s.settings);
      k(s.posts, s.pages, s.terms, s.settings, a), M(s.posts, s.pages, s.terms, a);
    }), n.addAction("regenerate.listings.before", async (e) => {
      const t = e, s = b(t.settings);
      k(t.posts, t.pages, t.terms, t.settings, s), M(t.posts, t.pages, t.terms, s);
    }), n.addAction("publish.complete", async (e, t) => {
      await it(e, t);
    }), n.addAction("post.unpublished", async (e, t) => {
      await ne(e, t);
    }), n.addAction("post.deleted", async (e, t) => {
      await ne(e, t);
    }), n.addFilter("page.head.extra", (e, ...t) => {
      const s = t[0];
      if (!(s != null && s.currentPath)) return e;
      const a = Ee(s.currentPath);
      return a ? e + (e ? `
` : "") + a : e;
    }), n.addFilter("page.body.end", (e, ...t) => {
      var o;
      const s = t[0];
      if (!(s != null && s.currentPath) || !((o = s == null ? void 0 : s.site) != null && o.settings)) return e;
      const a = b(s.site.settings), r = rt({
        config: a,
        settings: s.site.settings,
        currentPath: s.currentPath
      });
      return r ? e + (e ? `
` : "") + r : e;
    }), n.addFilter(
      "sitemap.urlset.namespaces",
      (e) => Ge(e)
    ), n.addFilter("sitemap.url.entry", (e, ...t) => {
      const s = t[0];
      return Be(e, s);
    }), n.addFilter("sitemap.urls.extra", (e, ...t) => {
      const s = t[0];
      return Ve(
        e,
        s
      );
    }), n.addFilter("sitemap.index.extra", (e, ...t) => {
      const s = t[0];
      return Xe(
        e,
        s
      );
    }), n.registerEditorVariantProvider(nt), n.registerTermEditorSection({
      id: "flexweg-multilang/term-translations",
      termType: "all",
      priority: 50,
      component: tt
    }), ot();
  }
};
export {
  dt as default
};
