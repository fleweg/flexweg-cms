import { jsx as u, jsxs as g } from "react/jsx-runtime";
import { i18n as Z, pickPublicLocale as ee, pickFormat as Q, FontSelect as Kt, MediaPicker as Fr, pickMediaUrl as pt } from "@flexweg/cms-runtime";
import O, { forwardRef as At, createElement as Ge, useState as he, createRef as Lr, memo as Pr, createContext as Tn, version as Gt, useContext as $r, useRef as Dr, useEffect as Yt, useMemo as jr } from "react";
import { useTranslation as ot } from "react-i18next";
import Hr, { flushSync as Ur } from "react-dom";
const Xt = `/* Marketplace Core — hand-written theme stylesheet (no Tailwind
   build for the external scaffold to keep \`npm install\` light). All
   rules use CSS variables for the Material 3 palette, so the
   Theme Settings → Style tab can swap them at upload time via
   compileCss. */
@import url("https://fonts.googleapis.com/css2?family=Hanken+Grotesk:ital,wght@0,400;0,500;0,600;0,700;0,800;1,400&family=Inter:wght@400;500;600;700&display=swap");
@import url("https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:wght,FILL@100..700,0..1&display=swap");

:root {
  --color-background: 249 249 255;
  --color-surface: 249 249 255;
  --color-surface-container-lowest: 255 255 255;
  --color-surface-container-low: 241 243 255;
  --color-surface-container: 233 237 255;
  --color-surface-container-high: 227 232 249;
  --color-surface-container-highest: 221 226 243;
  --color-on-surface: 22 28 40;
  --color-on-surface-variant: 67 70 85;
  --color-outline: 116 118 134;
  --color-outline-variant: 196 197 215;
  --color-primary: 0 55 176;
  --color-on-primary: 255 255 255;
  --color-primary-container: 29 78 216;
  --color-on-primary-container: 202 211 255;
  --color-secondary: 70 72 212;
  --color-on-secondary: 255 255 255;
  --color-tertiary: 101 0 174;
  --color-on-tertiary: 255 255 255;
  --color-success: 46 125 50;
  --color-success-container: 232 245 233;
  --font-headline: "Hanken Grotesk";
  --font-body: "Inter";
}

/* ───── Reset / base ───── */
*, *::before, *::after { box-sizing: border-box; }
html, body { margin: 0; padding: 0; }
body {
  background: rgb(var(--color-background));
  color: rgb(var(--color-on-surface));
  font-family: var(--font-body), Inter, system-ui, sans-serif;
  font-size: 16px;
  line-height: 1.5;
  -webkit-font-smoothing: antialiased;
}
a { color: inherit; text-decoration: none; }
img { display: block; max-width: 100%; height: auto; }
button {
  font-family: inherit;
  cursor: pointer;
  border: 0;
  background: transparent;
  padding: 0;
}

/* ───── Material Symbols ───── */
.material-symbols-outlined {
  font-family: "Material Symbols Outlined";
  font-variation-settings: "FILL" 0, "wght" 400, "GRAD" 0, "opsz" 24;
  vertical-align: middle;
  line-height: 1;
  font-size: 24px;
}

/* ───── Typography helpers ───── */
.font-headline {
  font-family: var(--font-headline), "Hanken Grotesk", system-ui, sans-serif;
}
.text-display-lg {
  font-size: 48px; line-height: 1.1; font-weight: 800; letter-spacing: -0.02em;
}
.text-headline-lg { font-size: 32px; line-height: 1.2; font-weight: 700; letter-spacing: -0.01em; }
.text-headline-md { font-size: 24px; line-height: 1.3; font-weight: 600; }
.text-body-lg { font-size: 18px; line-height: 1.6; }
.text-body-md { font-size: 16px; line-height: 1.5; }
.text-label-md { font-size: 14px; font-weight: 600; line-height: 1; letter-spacing: 0.02em; }
@media (max-width: 768px) {
  .text-display-lg { font-size: 36px; }
  .text-headline-lg { font-size: 28px; }
}

/* ───── Layout shell ───── */
.mp-app {
  display: flex;
  flex-direction: column;
  min-height: 100vh;
}
.mp-header {
  position: sticky;
  top: 0;
  z-index: 50;
  background: rgb(var(--color-surface));
  box-shadow: 0 4px 15px rgba(0, 0, 0, 0.04);
}
.mp-header__inner {
  max-width: 1280px;
  margin: 0 auto;
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 16px 24px;
  gap: 24px;
}
.mp-brand {
  font-family: var(--font-headline);
  font-size: 28px;
  font-weight: 800;
  color: rgb(var(--color-primary));
  letter-spacing: -0.01em;
}
.mp-header__nav {
  display: none;
  align-items: center;
  gap: 24px;
}
.mp-nav-link {
  font-size: 14px;
  font-weight: 600;
  color: rgb(var(--color-on-surface-variant));
  padding: 8px 12px;
  border-radius: 9999px;
  transition: background 0.2s, color 0.2s;
}
.mp-nav-link:hover { background: rgb(var(--color-surface-container)); color: rgb(var(--color-on-surface)); }
.mp-nav-link.is-active { background: rgb(var(--color-primary)); color: rgb(var(--color-on-primary)); }
.mp-header__search {
  flex: 1;
  max-width: 480px;
  display: none;
}
.mp-search-input {
  width: 100%;
  background: rgb(var(--color-surface-container));
  border: 1px solid transparent;
  border-radius: 12px;
  padding: 10px 16px;
  font-size: 14px;
  color: rgb(var(--color-on-surface));
  outline: none;
  cursor: pointer;
  text-overflow: ellipsis;
}
.mp-search-input:hover {
  background: rgb(var(--color-surface-container-high));
}
.mp-search-input:focus {
  border-color: rgb(var(--color-primary));
  background: rgb(var(--color-surface-container-lowest));
}
@media (min-width: 768px) {
  .mp-header__nav { display: flex; }
  .mp-header__search { display: block; }
}

.mp-layout {
  display: flex;
  flex: 1;
  max-width: 1280px;
  width: 100%;
  margin: 0 auto;
  padding: 0 20px;
  gap: 24px;
}
@media (min-width: 768px) {
  .mp-layout { padding: 0 24px; }
}

.mp-sidebar {
  display: none;
  width: 280px;
  flex-shrink: 0;
  padding-top: 24px;
}
@media (min-width: 1024px) {
  .mp-sidebar {
    display: block;
    position: sticky;
    top: 88px;
    height: calc(100vh - 88px);
    overflow-y: auto;
  }
}
.mp-sidebar__heading {
  font-family: var(--font-headline);
  font-size: 24px;
  font-weight: 700;
  color: rgb(var(--color-on-surface));
  margin: 0 0 16px 8px;
}
.mp-sidebar__group { margin-bottom: 24px; }
.mp-sidebar__label {
  display: block;
  font-size: 11px;
  font-weight: 600;
  letter-spacing: 0.08em;
  text-transform: uppercase;
  color: rgb(var(--color-on-surface-variant));
  padding: 0 12px;
  margin-bottom: 8px;
}
.mp-sidebar__link {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 10px 12px;
  border-radius: 12px;
  font-size: 14px;
  font-weight: 500;
  color: rgb(var(--color-on-surface-variant));
  transition: background 0.15s, color 0.15s;
}
.mp-sidebar__link:hover { background: rgb(var(--color-surface-container)); color: rgb(var(--color-on-surface)); }
.mp-sidebar__link.is-active { background: rgb(var(--color-primary-container)); color: rgb(var(--color-on-primary-container)); }
.mp-sidebar__link .material-symbols-outlined { font-size: 20px; }

.mp-main {
  flex: 1;
  min-width: 0;
  padding: 24px 0 64px;
}

/* ───── Cards (product card — Level 1 elevation) ───── */
.mp-card {
  background: rgb(var(--color-surface-container-lowest));
  border-radius: 24px;
  box-shadow: 0 4px 15px rgba(0, 0, 0, 0.04);
  overflow: hidden;
  display: block;
  transition: transform 0.25s ease, box-shadow 0.25s ease;
}
.mp-card:hover {
  transform: translateY(-2px) scale(1.01);
  box-shadow: 0 10px 25px rgba(0, 0, 0, 0.08);
}
.mp-card__image {
  width: 100%;
  aspect-ratio: 16 / 10;
  background: rgb(var(--color-surface-container));
  object-fit: cover;
}
.mp-card__body { padding: 20px 24px 24px; }
.mp-card__category {
  display: inline-block;
  font-size: 11px;
  font-weight: 600;
  letter-spacing: 0.05em;
  text-transform: uppercase;
  color: rgb(var(--color-primary));
  margin-bottom: 6px;
}
.mp-card__title {
  font-family: var(--font-headline);
  font-size: 18px;
  font-weight: 700;
  color: rgb(var(--color-on-surface));
  margin: 0 0 6px;
  letter-spacing: -0.01em;
}
.mp-card__excerpt {
  font-size: 14px;
  color: rgb(var(--color-on-surface-variant));
  margin: 0 0 16px;
  line-height: 1.5;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  overflow: hidden;
}
.mp-card__footer {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
}
.mp-card__author {
  font-size: 13px;
  color: rgb(var(--color-on-surface-variant));
  display: flex;
  align-items: center;
  gap: 8px;
}
.mp-badge-free {
  display: inline-block;
  font-size: 11px;
  font-weight: 700;
  letter-spacing: 0.05em;
  text-transform: uppercase;
  color: rgb(var(--color-success));
  background: rgb(var(--color-success-container));
  padding: 4px 10px;
  border-radius: 9999px;
}

/* ───── Grid layouts ───── */
.mp-grid { display: grid; gap: 24px; }
.mp-grid--3 { grid-template-columns: 1fr; }
@media (min-width: 640px) { .mp-grid--3 { grid-template-columns: repeat(2, minmax(0, 1fr)); } }
@media (min-width: 1024px) { .mp-grid--3 { grid-template-columns: repeat(3, minmax(0, 1fr)); } }
.mp-grid--2 { grid-template-columns: 1fr; }
@media (min-width: 768px) { .mp-grid--2 { grid-template-columns: repeat(2, minmax(0, 1fr)); } }

.mp-section { margin-bottom: 64px; }
.mp-section__heading {
  display: flex;
  align-items: baseline;
  justify-content: space-between;
  margin-bottom: 24px;
  gap: 16px;
}
.mp-section__heading h2 {
  font-family: var(--font-headline);
  font-size: 28px;
  font-weight: 700;
  margin: 0;
  letter-spacing: -0.01em;
}
.mp-section__see-all {
  font-size: 14px;
  font-weight: 600;
  color: rgb(var(--color-primary));
}

/* ───── Hero banner ───── */
.mp-hero {
  position: relative;
  background: linear-gradient(135deg, rgb(var(--color-primary)) 0%, rgb(var(--color-tertiary)) 100%);
  border-radius: 32px;
  overflow: hidden;
  padding: 56px 48px;
  color: rgb(var(--color-on-primary));
  margin-bottom: 64px;
  min-height: 320px;
  display: flex;
  flex-direction: column;
  justify-content: center;
}
.mp-hero__eyebrow {
  font-size: 14px;
  font-weight: 700;
  letter-spacing: 0.05em;
  text-transform: uppercase;
  opacity: 0.85;
  margin-bottom: 12px;
}
.mp-hero h1 {
  font-family: var(--font-headline);
  font-size: 36px;
  font-weight: 800;
  line-height: 1.1;
  letter-spacing: -0.02em;
  margin: 0 0 16px;
  max-width: 680px;
}
@media (min-width: 768px) {
  .mp-hero h1 { font-size: 48px; }
}
.mp-hero p {
  font-size: 18px;
  line-height: 1.6;
  max-width: 580px;
  opacity: 0.95;
  margin: 0 0 24px;
}

/* ───── Buttons ───── */
.mp-btn {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 8px;
  font-size: 16px;
  font-weight: 700;
  border-radius: 9999px;
  padding: 14px 28px;
  transition: opacity 0.15s, transform 0.1s, box-shadow 0.2s;
  min-height: 48px;
}
.mp-btn:active { transform: scale(0.98); }
a.mp-btn { text-decoration: none; }
.mp-btn.mp-btn--primary {
  background: rgb(var(--color-primary));
  color: rgb(var(--color-on-primary));
  box-shadow: 0 6px 20px rgba(0, 55, 176, 0.25);
}
.mp-btn.mp-btn--primary:hover { opacity: 0.92; color: rgb(var(--color-on-primary)); }
.mp-btn.mp-btn--secondary {
  background: rgb(var(--color-surface-container));
  color: rgb(var(--color-primary));
  border: 1px solid rgb(var(--color-outline-variant));
}
.mp-btn.mp-btn--secondary:hover { background: rgb(var(--color-surface-container-high)); }
.mp-btn.mp-btn--ghost {
  background: rgb(var(--color-surface));
  color: rgb(var(--color-on-surface));
}
.mp-btn.mp-btn--ghost:hover { background: rgb(var(--color-surface-container)); }

/* ───── Single page ───── */
.mp-product {
  display: grid;
  grid-template-columns: 1fr;
  gap: 32px;
  margin-bottom: 64px;
}
@media (min-width: 1024px) {
  .mp-product { grid-template-columns: 7fr 5fr; }
}
.mp-product__gallery {
  display: flex;
  flex-direction: column;
  gap: 16px;
}
.mp-product__hero-image {
  width: 100%;
  aspect-ratio: 16 / 10;
  background: rgb(var(--color-surface-container));
  border-radius: 24px;
  object-fit: cover;
  box-shadow: 0 4px 15px rgba(0, 0, 0, 0.04);
}
.mp-product__thumbs {
  display: grid;
  grid-template-columns: repeat(4, minmax(0, 1fr));
  gap: 12px;
}
.mp-product__thumb {
  aspect-ratio: 1 / 1;
  background: rgb(var(--color-surface-container));
  border-radius: 12px;
  overflow: hidden;
  cursor: pointer;
  border: 2px solid transparent;
  transition: border-color 0.2s;
}
.mp-product__thumb img { width: 100%; height: 100%; object-fit: cover; display: block; }
.mp-product__thumb:hover, .mp-product__thumb.is-active { border-color: rgb(var(--color-primary)); }
.mp-product__hero-image { cursor: zoom-in; }

.mp-product__info {
  display: flex;
  flex-direction: column;
  gap: 16px;
}
.mp-product__category {
  font-size: 13px;
  font-weight: 600;
  letter-spacing: 0.05em;
  text-transform: uppercase;
  color: rgb(var(--color-primary));
}
.mp-product__title {
  font-family: var(--font-headline);
  font-size: 36px;
  font-weight: 700;
  line-height: 1.1;
  letter-spacing: -0.02em;
  margin: 0;
}
.mp-product__author {
  display: flex;
  align-items: center;
  gap: 12px;
  color: rgb(var(--color-on-surface-variant));
  font-size: 14px;
}
.mp-product__author img {
  width: 32px;
  height: 32px;
  border-radius: 9999px;
  object-fit: cover;
  background: rgb(var(--color-surface-container));
}
.mp-product__excerpt {
  font-size: 18px;
  line-height: 1.6;
  color: rgb(var(--color-on-surface-variant));
}
.mp-product__cta-row {
  display: flex;
  gap: 12px;
  margin-top: 8px;
}
.mp-product__cta-row .mp-btn { flex: 1; }

/* ───── Sections inside single (description, body prose) ───── */
.mp-section-heading {
  font-family: var(--font-headline);
  font-size: 24px;
  font-weight: 700;
  border-bottom: 1px solid rgb(var(--color-outline-variant));
  padding-bottom: 16px;
  margin: 48px 0 24px;
}
.mp-prose {
  font-size: 16px;
  line-height: 1.7;
  color: rgb(var(--color-on-surface));
  max-width: 720px;
}
.mp-prose p { margin: 0 0 16px; }
.mp-prose h2 {
  font-family: var(--font-headline);
  font-size: 24px;
  font-weight: 700;
  margin: 32px 0 16px;
}
.mp-prose h3 {
  font-family: var(--font-headline);
  font-size: 18px;
  font-weight: 600;
  margin: 24px 0 12px;
}
.mp-prose ul, .mp-prose ol { padding-left: 24px; margin: 0 0 16px; }
.mp-prose ul { list-style: disc; }
.mp-prose ol { list-style: decimal; }
.mp-prose li { margin-bottom: 6px; }
.mp-prose a {
  color: rgb(var(--color-primary));
  text-decoration: underline;
  text-underline-offset: 3px;
}
.mp-prose img {
  border-radius: 16px;
  margin: 24px 0;
}
.mp-prose code {
  background: rgb(var(--color-surface-container));
  padding: 2px 6px;
  border-radius: 4px;
  font-size: 0.9em;
  font-family: ui-monospace, Menlo, monospace;
}
.mp-prose pre {
  background: rgb(var(--color-surface-container));
  padding: 16px;
  border-radius: 12px;
  overflow-x: auto;
  margin: 16px 0;
}

/* ───── Specs block ───── */
.mp-specs {
  background: rgb(var(--color-surface-container-lowest));
  border-radius: 24px;
  padding: 24px;
  box-shadow: 0 4px 15px rgba(0, 0, 0, 0.04);
}
.mp-specs__grid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 24px 32px;
}
@media (max-width: 640px) {
  .mp-specs__grid { grid-template-columns: 1fr; }
}
.mp-specs__row {
  display: flex;
  flex-direction: column;
  gap: 4px;
}
.mp-specs__label {
  font-size: 11px;
  font-weight: 600;
  letter-spacing: 0.05em;
  text-transform: uppercase;
  color: rgb(var(--color-on-surface-variant));
}
.mp-specs__value {
  font-size: 16px;
  color: rgb(var(--color-on-surface));
  font-weight: 500;
}

/* ───── Features bento ───── */
.mp-features {
  display: grid;
  grid-template-columns: 1fr;
  gap: 16px;
}
@media (min-width: 640px) {
  .mp-features { grid-template-columns: repeat(2, minmax(0, 1fr)); }
}
.mp-features__item {
  background: rgb(var(--color-surface-container-lowest));
  border-radius: 24px;
  padding: 24px;
  box-shadow: 0 4px 15px rgba(0, 0, 0, 0.04);
  display: flex;
  flex-direction: column;
  gap: 12px;
}
.mp-features__icon {
  width: 48px;
  height: 48px;
  border-radius: 12px;
  background: rgb(var(--color-primary-container));
  color: rgb(var(--color-on-primary-container));
  display: flex;
  align-items: center;
  justify-content: center;
}
.mp-features__icon .material-symbols-outlined { font-size: 28px; color: rgb(var(--color-on-primary));}
.mp-features__title {
  font-family: var(--font-headline);
  font-size: 16px;
  font-weight: 700;
  margin: 0;
}

/* ───── Author profile card ───── */
.mp-author-card {
  background: rgb(var(--color-surface-container-lowest));
  border-radius: 32px;
  padding: 32px;
  box-shadow: 0 4px 15px rgba(0, 0, 0, 0.04);
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 24px;
  margin-bottom: 48px;
}
@media (min-width: 768px) {
  .mp-author-card { flex-direction: row; align-items: flex-start; }
}
.mp-author-card__avatar {
  width: 120px;
  height: 120px;
  border-radius: 9999px;
  background: rgb(var(--color-surface-container));
  object-fit: cover;
  flex-shrink: 0;
}
.mp-author-card__info { flex: 1; text-align: center; }
@media (min-width: 768px) { .mp-author-card__info { text-align: left; } }
.mp-author-card__name {
  font-family: var(--font-headline);
  font-size: 32px;
  font-weight: 700;
  margin: 0 0 8px;
}
.mp-author-card__title {
  font-size: 14px;
  font-weight: 600;
  color: rgb(var(--color-primary));
  margin-bottom: 12px;
  text-transform: uppercase;
  letter-spacing: 0.05em;
}
.mp-author-card__bio { color: rgb(var(--color-on-surface-variant)); margin: 0; }

/* ───── Breadcrumb ───── */
.mp-breadcrumb {
  font-size: 13px;
  color: rgb(var(--color-on-surface-variant));
  margin-bottom: 16px;
  display: flex;
  align-items: center;
  gap: 8px;
  flex-wrap: wrap;
}
.mp-breadcrumb a:hover { color: rgb(var(--color-primary)); }
.mp-breadcrumb__sep { opacity: 0.6; }

/* ───── Footer ───── */
.mp-footer {
  background: rgb(var(--color-surface));
  padding: 48px 24px 32px;
  border-top: 1px solid rgb(var(--color-outline-variant));
}
.mp-footer__inner {
  max-width: 1280px;
  margin: 0 auto;
  display: flex;
  flex-direction: column;
  gap: 24px;
}
@media (min-width: 768px) {
  .mp-footer__inner { flex-direction: row; align-items: center; justify-content: space-between; }
}
.mp-footer__nav {
  display: flex;
  flex-wrap: wrap;
  gap: 24px;
}
.mp-footer__nav a {
  font-size: 14px;
  color: rgb(var(--color-on-surface-variant));
}
.mp-footer__nav a:hover { color: rgb(var(--color-primary)); }
.mp-footer__copyright {
  font-size: 13px;
  color: rgb(var(--color-on-surface-variant));
}

/* ───── Mobile bottom nav ───── */
.mp-bottom-nav {
  display: flex;
  position: fixed;
  bottom: 0;
  left: 0;
  right: 0;
  background: rgb(var(--color-surface));
  border-top: 1px solid rgb(var(--color-outline-variant));
  z-index: 40;
  padding: 8px 0 max(8px, env(safe-area-inset-bottom));
}
@media (min-width: 1024px) { .mp-bottom-nav { display: none; } }
.mp-bottom-nav__item {
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 4px;
  font-size: 11px;
  font-weight: 500;
  color: rgb(var(--color-on-surface-variant));
  padding: 8px 4px;
}
.mp-bottom-nav__item.is-active { color: rgb(var(--color-primary)); }
.mp-bottom-nav__item .material-symbols-outlined { font-size: 24px; }

/* Add bottom padding on mobile main canvas so content doesn't sit
   under the bottom nav. */
@media (max-width: 1023px) {
  .mp-app { padding-bottom: 72px; }
}

/* ───── Filter tabs ───── */
.mp-tabs {
  display: flex;
  gap: 8px;
  margin-bottom: 24px;
  border-bottom: 1px solid rgb(var(--color-outline-variant));
  overflow-x: auto;
}
.mp-tabs__tab {
  padding: 12px 20px;
  font-size: 14px;
  font-weight: 600;
  color: rgb(var(--color-on-surface-variant));
  border-bottom: 2px solid transparent;
  margin-bottom: -1px;
  white-space: nowrap;
  transition: color 0.15s, border-color 0.15s;
}
.mp-tabs__tab.is-active {
  color: rgb(var(--color-primary));
  border-bottom-color: rgb(var(--color-primary));
}

/* ───── 404 ───── */
.mp-404 {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  text-align: center;
  padding: 96px 24px;
  gap: 16px;
}
.mp-404 .material-symbols-outlined {
  font-size: 80px;
  color: rgb(var(--color-primary));
}
.mp-404 h1 {
  font-family: var(--font-headline);
  font-size: 48px;
  font-weight: 800;
  margin: 0;
}

/* ───── Static page body ───── */
.mp-page-body {
  max-width: 800px;
  margin: 0 auto;
  padding: 48px 0;
}
.mp-page-body h1 {
  font-family: var(--font-headline);
  font-size: 48px;
  font-weight: 800;
  letter-spacing: -0.02em;
  line-height: 1.1;
  margin: 0 0 32px;
}

/* ───── Lightbox (gallery zoom) ───── */
.mp-lightbox {
  position: fixed;
  inset: 0;
  z-index: 1000;
  display: flex;
  align-items: center;
  justify-content: center;
  background: rgba(0, 0, 0, 0.92);
  padding: 24px;
  animation: mp-lightbox-fade 0.18s ease-out;
}
.mp-lightbox[hidden] { display: none; }
@keyframes mp-lightbox-fade {
  from { opacity: 0; }
  to { opacity: 1; }
}
.mp-lightbox__stage {
  position: relative;
  max-width: min(1200px, 100%);
  max-height: 100%;
  display: flex;
  align-items: center;
  justify-content: center;
}
.mp-lightbox__image {
  max-width: 100%;
  max-height: calc(100vh - 96px);
  width: auto;
  height: auto;
  border-radius: 16px;
  box-shadow: 0 30px 80px rgba(0, 0, 0, 0.6);
  object-fit: contain;
  user-select: none;
}
.mp-lightbox__close,
.mp-lightbox__prev,
.mp-lightbox__next {
  position: absolute;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: 48px;
  height: 48px;
  border-radius: 999px;
  border: 0;
  background: rgba(255, 255, 255, 0.12);
  color: #fff;
  cursor: pointer;
  transition: background 0.15s, transform 0.15s;
  backdrop-filter: blur(8px);
}
.mp-lightbox__close:hover,
.mp-lightbox__prev:hover,
.mp-lightbox__next:hover {
  background: rgba(255, 255, 255, 0.22);
}
.mp-lightbox__close:active,
.mp-lightbox__prev:active,
.mp-lightbox__next:active {
  transform: scale(0.94);
}
.mp-lightbox__close {
  top: 20px;
  right: 20px;
}
.mp-lightbox__prev {
  left: 20px;
  top: 50%;
  transform: translateY(-50%);
}
.mp-lightbox__next {
  right: 20px;
  top: 50%;
  transform: translateY(-50%);
}
.mp-lightbox__prev:active { transform: translateY(-50%) scale(0.94); }
.mp-lightbox__next:active { transform: translateY(-50%) scale(0.94); }
.mp-lightbox__prev .material-symbols-outlined,
.mp-lightbox__next .material-symbols-outlined,
.mp-lightbox__close .material-symbols-outlined {
  font-size: 28px;
}
.mp-lightbox__counter {
  position: absolute;
  left: 50%;
  bottom: 20px;
  transform: translateX(-50%);
  color: rgba(255, 255, 255, 0.85);
  font-size: 13px;
  font-weight: 500;
  letter-spacing: 0.04em;
  padding: 6px 14px;
  border-radius: 999px;
  background: rgba(255, 255, 255, 0.08);
  backdrop-filter: blur(8px);
}
@media (max-width: 640px) {
  .mp-lightbox { padding: 12px; }
  .mp-lightbox__close,
  .mp-lightbox__prev,
  .mp-lightbox__next {
    width: 40px;
    height: 40px;
  }
  .mp-lightbox__close { top: 12px; right: 12px; }
  .mp-lightbox__prev { left: 12px; }
  .mp-lightbox__next { right: 12px; }
  .mp-lightbox__image { max-height: calc(100vh - 72px); }
}
`;
function Jr({ site: r, currentPath: e }) {
  var c;
  const { settings: t, resolvedMenus: n } = r, i = Z.getFixedT(ee(t.language), "theme-marketplace-core"), o = r.themeConfig, s = ((c = o == null ? void 0 : o.brand.wordmark) == null ? void 0 : c.trim()) || t.title, a = n.header.slice(0, 5);
  function l(d) {
    if (!e) return !1;
    const p = ("/" + e).replace(/\/index\.html$/, "/"), f = d.replace(/\/index\.html$/, "/");
    return p === f;
  }
  return /* @__PURE__ */ u("header", { className: "mp-header", children: /* @__PURE__ */ g("div", { className: "mp-header__inner", children: [
    /* @__PURE__ */ u("a", { className: "mp-brand font-headline", href: "/index.html", children: s }),
    /* @__PURE__ */ u("nav", { className: "mp-header__nav", "aria-label": "Primary", children: a.map((d) => /* @__PURE__ */ u(
      "a",
      {
        className: `mp-nav-link${l(d.href) ? " is-active" : ""}`,
        href: d.href,
        children: d.label
      },
      d.id
    )) }),
    /* @__PURE__ */ u("div", { className: "mp-header__search", children: /* @__PURE__ */ u(
      "input",
      {
        type: "search",
        className: "mp-search-input",
        placeholder: i("publicBaked.nav.themes") + " · " + i("publicBaked.nav.plugins"),
        "aria-label": "Search",
        "data-cms-search": !0,
        readOnly: !0,
        role: "button"
      }
    ) })
  ] }) });
}
function Vr({ site: r }) {
  var o, s;
  const { settings: e, resolvedMenus: t } = r, n = r.themeConfig, i = ((o = n == null ? void 0 : n.footer.copyright) == null ? void 0 : o.trim()) || `© ${(/* @__PURE__ */ new Date()).getFullYear()} ${e.title}.`;
  return /* @__PURE__ */ u("footer", { className: "mp-footer", children: /* @__PURE__ */ g("div", { className: "mp-footer__inner", children: [
    /* @__PURE__ */ u("a", { className: "mp-brand font-headline", href: "/index.html", children: ((s = n == null ? void 0 : n.brand.wordmark) == null ? void 0 : s.trim()) || e.title }),
    /* @__PURE__ */ u("nav", { className: "mp-footer__nav", "aria-label": "Footer", children: t.footer.map((a) => /* @__PURE__ */ u("a", { href: a.href, children: a.label }, a.id)) }),
    /* @__PURE__ */ u("p", { className: "mp-footer__copyright", children: i })
  ] }) });
}
const In = {
  heroEyebrow: "FLEXWEG MARKETPLACE",
  heroHeadline: "Modern assets for professional creators.",
  heroIntro: "Curated themes and plugins for your Flexweg CMS site. Free, open-source, and ready to install.",
  featuredCategorySlug: "plugins",
  featuredHeading: "Featured Plugins",
  featuredCount: 2,
  newCategorySlug: "themes",
  newHeading: "New Themes",
  newCount: 6,
  showRecentlyUpdated: !1,
  recentlyUpdatedHeading: "Recently Updated",
  recentlyUpdatedCount: 6
}, Wr = {
  descriptionLabel: "Description",
  specificationsLabel: "Specifications",
  featuresLabel: "Key Features",
  downloadLabel: "Download",
  previewLabel: "Live Preview",
  freeBadgeLabel: "Free",
  showSpecs: !0,
  showFeatures: !0
}, On = {
  heading: "Discover",
  topItems: [
    { icon: "auto_awesome", label: "Featured", href: "/index.html" },
    { icon: "fiber_new", label: "New", href: "/new.html" },
    { icon: "trending_up", label: "Top Rated", href: "/top.html" }
  ],
  categoriesHeading: "Categories",
  categoriesItems: [
    { icon: "palette", label: "Themes", href: "/themes/index.html" },
    { icon: "extension", label: "Plugins", href: "/plugins/index.html" },
    { icon: "shopping_bag", label: "E-commerce", href: "/e-commerce/index.html" },
    { icon: "analytics", label: "Analytics", href: "/analytics/index.html" },
    { icon: "lock", label: "Authentication", href: "/authentication/index.html" }
  ]
}, qr = {
  copyright: ""
}, Kr = {
  wordmark: ""
}, K = {
  vars: {},
  fontHeadline: "Hanken Grotesk",
  fontBody: "Inter"
}, X = {
  home: In,
  single: Wr,
  sidebar: On,
  footer: qr,
  brand: Kr,
  style: K
};
function Gr({ site: r, currentPath: e }) {
  const t = r.themeConfig, n = { ...On, ...(t == null ? void 0 : t.sidebar) ?? {} };
  function i(o) {
    if (!e) return !1;
    const s = ("/" + e).replace(/\/index\.html$/, "/"), a = o.replace(/\/index\.html$/, "/");
    return s === a;
  }
  return /* @__PURE__ */ g("aside", { className: "mp-sidebar", "aria-label": "Sidebar", children: [
    /* @__PURE__ */ u("h2", { className: "mp-sidebar__heading font-headline", children: n.heading }),
    n.topItems.length > 0 && /* @__PURE__ */ u("div", { className: "mp-sidebar__group", children: n.topItems.map((o, s) => /* @__PURE__ */ g(
      "a",
      {
        className: `mp-sidebar__link${i(o.href) ? " is-active" : ""}`,
        href: o.href,
        children: [
          o.icon && /* @__PURE__ */ u("span", { className: "material-symbols-outlined", children: o.icon }),
          /* @__PURE__ */ u("span", { children: o.label })
        ]
      },
      `top-${s}`
    )) }),
    n.categoriesItems.length > 0 && /* @__PURE__ */ g("div", { className: "mp-sidebar__group", children: [
      /* @__PURE__ */ u("span", { className: "mp-sidebar__label", children: n.categoriesHeading }),
      n.categoriesItems.map((o, s) => /* @__PURE__ */ g(
        "a",
        {
          className: `mp-sidebar__link${i(o.href) ? " is-active" : ""}`,
          href: o.href,
          children: [
            o.icon && /* @__PURE__ */ u("span", { className: "material-symbols-outlined", children: o.icon }),
            /* @__PURE__ */ u("span", { children: o.label })
          ]
        },
        `cat-${s}`
      ))
    ] })
  ] });
}
function Yr({ site: r, currentPath: e }) {
  const t = Z.getFixedT(ee(r.settings.language), "theme-marketplace-core"), n = [
    { icon: "home", label: t("publicBaked.nav.home"), href: "/index.html" },
    { icon: "palette", label: t("publicBaked.nav.themes"), href: "/themes/index.html" },
    { icon: "extension", label: t("publicBaked.nav.plugins"), href: "/plugins/index.html" },
    { icon: "groups", label: t("publicBaked.nav.authors"), href: "/authors/index.html" }
  ];
  function i(o) {
    if (!e) return !1;
    const s = ("/" + e).replace(/\/index\.html$/, "/"), a = o.replace(/\/index\.html$/, "/");
    return s === a || o === "/index.html" && s === "/";
  }
  return /* @__PURE__ */ u("nav", { className: "mp-bottom-nav", "aria-label": "Mobile navigation", children: n.map((o) => /* @__PURE__ */ g(
    "a",
    {
      className: `mp-bottom-nav__item${i(o.href) ? " is-active" : ""}`,
      href: o.href,
      children: [
        /* @__PURE__ */ u("span", { className: "material-symbols-outlined", children: o.icon }),
        /* @__PURE__ */ u("span", { children: o.label })
      ]
    },
    o.href
  )) });
}
function Xr({
  site: r,
  pageTitle: e,
  pageDescription: t,
  ogImage: n,
  currentPath: i,
  children: o
}) {
  const s = `/${r.themeCssPath}`, a = r.settings.baseUrl && i ? `${r.settings.baseUrl.replace(/\/+$/, "")}/${i.replace(/^\/+/, "")}` : void 0, l = e ? `${e} — ${r.settings.title}` : r.settings.title;
  return /* @__PURE__ */ g("html", { lang: r.settings.language || "en", children: [
    /* @__PURE__ */ g("head", { children: [
      /* @__PURE__ */ u("meta", { charSet: "UTF-8" }),
      /* @__PURE__ */ u("meta", { name: "viewport", content: "width=device-width, initial-scale=1" }),
      /* @__PURE__ */ u("title", { children: l }),
      t && /* @__PURE__ */ u("meta", { name: "description", content: t }),
      a && /* @__PURE__ */ u("link", { rel: "canonical", href: a }),
      /* @__PURE__ */ u("link", { rel: "preconnect", href: "https://fonts.googleapis.com" }),
      /* @__PURE__ */ u("link", { rel: "preconnect", href: "https://fonts.gstatic.com", crossOrigin: "" }),
      /* @__PURE__ */ u("link", { rel: "stylesheet", href: s }),
      /* @__PURE__ */ u("meta", { property: "og:title", content: l }),
      t && /* @__PURE__ */ u("meta", { property: "og:description", content: t }),
      n && /* @__PURE__ */ u("meta", { property: "og:image", content: n }),
      a && /* @__PURE__ */ u("meta", { property: "og:url", content: a }),
      /* @__PURE__ */ u("meta", { property: "og:type", content: "website" }),
      /* @__PURE__ */ u("meta", { name: "x-cms-head-extra" })
    ] }),
    /* @__PURE__ */ g("body", { children: [
      /* @__PURE__ */ g("div", { className: "mp-app", children: [
        /* @__PURE__ */ u(Jr, { site: r, currentPath: i }),
        /* @__PURE__ */ g("div", { className: "mp-layout", children: [
          /* @__PURE__ */ u(Gr, { site: r, currentPath: i }),
          /* @__PURE__ */ u("main", { className: "mp-main", children: o })
        ] }),
        /* @__PURE__ */ u(Vr, { site: r })
      ] }),
      /* @__PURE__ */ u(Yr, { site: r, currentPath: i }),
      /* @__PURE__ */ u("script", { type: "application/x-cms-body-end" })
    ] })
  ] });
}
function Se({ card: r, site: e }) {
  var o;
  const t = Z.getFixedT(ee(e.settings.language), "theme-marketplace-core"), n = r.hero ? Q(r.hero, "large") || Q(r.hero, "medium") || Q(r.hero) : "", i = ((o = r.hero) == null ? void 0 : o.alt) ?? r.title;
  return /* @__PURE__ */ g("a", { className: "mp-card", href: r.url, children: [
    /* @__PURE__ */ u("img", { className: "mp-card__image", src: n, alt: i, loading: "lazy" }),
    /* @__PURE__ */ g("div", { className: "mp-card__body", children: [
      r.category && /* @__PURE__ */ u("span", { className: "mp-card__category", children: r.category.name }),
      /* @__PURE__ */ u("h3", { className: "mp-card__title", children: r.title }),
      r.excerpt && /* @__PURE__ */ u("p", { className: "mp-card__excerpt", children: r.excerpt }),
      /* @__PURE__ */ u("div", { className: "mp-card__footer", children: /* @__PURE__ */ u("span", { className: "mp-badge-free", children: t("publicBaked.free") }) })
    ] })
  ] });
}
function Qr({
  posts: r,
  staticPage: e,
  site: t
}) {
  const n = Z.getFixedT(ee(t.settings.language), "theme-marketplace-core"), i = t.themeConfig, o = { ...In, ...(i == null ? void 0 : i.home) ?? {} };
  if (e)
    return /* @__PURE__ */ u("article", { className: "mp-page-body", children: /* @__PURE__ */ u(
      "div",
      {
        className: "mp-prose",
        dangerouslySetInnerHTML: { __html: e.bodyHtml }
      }
    ) });
  function s(d, p) {
    return !d || p <= 0 ? [] : r.filter((f) => f.category ? f.category.url.replace(/^\/+/, "").split("/")[0] === d : !1).slice(0, p);
  }
  const a = s(o.featuredCategorySlug, o.featuredCount), l = s(o.newCategorySlug, o.newCount), c = o.showRecentlyUpdated ? r.slice(0, o.recentlyUpdatedCount) : [];
  return /* @__PURE__ */ g("div", { children: [
    (o.heroHeadline || o.heroIntro) && /* @__PURE__ */ g("section", { className: "mp-hero", children: [
      o.heroEyebrow && /* @__PURE__ */ u("p", { className: "mp-hero__eyebrow", children: o.heroEyebrow }),
      o.heroHeadline && /* @__PURE__ */ u("h1", { children: o.heroHeadline }),
      o.heroIntro && /* @__PURE__ */ u("p", { children: o.heroIntro })
    ] }),
    a.length > 0 && /* @__PURE__ */ g("section", { className: "mp-section", children: [
      /* @__PURE__ */ g("div", { className: "mp-section__heading", children: [
        /* @__PURE__ */ u("h2", { children: o.featuredHeading }),
        o.featuredCategorySlug && /* @__PURE__ */ g(
          "a",
          {
            className: "mp-section__see-all",
            href: `/${o.featuredCategorySlug}/index.html`,
            children: [
              n("publicBaked.seeAll"),
              " →"
            ]
          }
        )
      ] }),
      /* @__PURE__ */ u("div", { className: "mp-grid mp-grid--2", children: a.map((d) => /* @__PURE__ */ u(Se, { card: d, site: t }, d.id)) })
    ] }),
    l.length > 0 && /* @__PURE__ */ g("section", { className: "mp-section", children: [
      /* @__PURE__ */ g("div", { className: "mp-section__heading", children: [
        /* @__PURE__ */ u("h2", { children: o.newHeading }),
        o.newCategorySlug && /* @__PURE__ */ g(
          "a",
          {
            className: "mp-section__see-all",
            href: `/${o.newCategorySlug}/index.html`,
            children: [
              n("publicBaked.seeAll"),
              " →"
            ]
          }
        )
      ] }),
      /* @__PURE__ */ u("div", { className: "mp-grid mp-grid--3", children: l.map((d) => /* @__PURE__ */ u(Se, { card: d, site: t }, d.id)) })
    ] }),
    c.length > 0 && /* @__PURE__ */ g("section", { className: "mp-section", children: [
      /* @__PURE__ */ u("div", { className: "mp-section__heading", children: /* @__PURE__ */ u("h2", { children: o.recentlyUpdatedHeading }) }),
      /* @__PURE__ */ u("div", { className: "mp-grid mp-grid--3", children: c.map((d) => /* @__PURE__ */ u(Se, { card: d, site: t }, d.id)) })
    ] })
  ] });
}
function Zr({
  post: r,
  bodyHtml: e,
  hero: t,
  primaryTerm: n,
  site: i
}) {
  const o = Z.getFixedT(ee(i.settings.language), "theme-marketplace-core");
  if (r.type === "page")
    return /* @__PURE__ */ g("article", { className: "mp-page-body", children: [
      /* @__PURE__ */ u("h1", { children: r.title }),
      /* @__PURE__ */ u("div", { className: "mp-prose", dangerouslySetInnerHTML: { __html: e } })
    ] });
  const a = t ? Q(t, "large") || Q(t, "medium") || Q(t) : "";
  return /* @__PURE__ */ g("article", { children: [
    /* @__PURE__ */ g("section", { className: "mp-product", children: [
      /* @__PURE__ */ g("div", { className: "mp-product__gallery", children: [
        a ? /* @__PURE__ */ u("img", { className: "mp-product__hero-image", src: a, alt: (t == null ? void 0 : t.alt) ?? r.title }) : /* @__PURE__ */ u("div", { className: "mp-product__hero-image" }),
        /* @__PURE__ */ u("div", { className: "mp-product__thumbs", "data-cms-mp-thumbs": !0, hidden: !0 })
      ] }),
      /* @__PURE__ */ g("div", { className: "mp-product__info", children: [
        n && /* @__PURE__ */ u("span", { className: "mp-product__category", children: n.name }),
        /* @__PURE__ */ u("h1", { className: "mp-product__title", children: r.title }),
        /* @__PURE__ */ u("div", { "data-cms-mp-byline-slot": !0 }),
        r.excerpt && /* @__PURE__ */ u("p", { className: "mp-product__excerpt", children: r.excerpt }),
        /* @__PURE__ */ u("div", { "data-cms-mp-cta-slot": !0 })
      ] })
    ] }),
    /* @__PURE__ */ u("div", { className: "mp-prose", dangerouslySetInnerHTML: { __html: e } }),
    /* @__PURE__ */ g("p", { className: "sr-only", children: [
      o("publicBaked.free"),
      " · ",
      o("publicBaked.description")
    ] })
  ] });
}
function ei({
  term: r,
  posts: e,
  site: t
}) {
  const n = Z.getFixedT(ee(t.settings.language), "theme-marketplace-core");
  return /* @__PURE__ */ g("article", { children: [
    /* @__PURE__ */ g("nav", { className: "mp-breadcrumb", "aria-label": "Breadcrumb", children: [
      /* @__PURE__ */ u("a", { href: "/index.html", children: n("publicBaked.home") }),
      /* @__PURE__ */ u("span", { className: "mp-breadcrumb__sep", children: "/" }),
      /* @__PURE__ */ u("span", { children: r.name })
    ] }),
    /* @__PURE__ */ g("header", { className: "mp-section", children: [
      /* @__PURE__ */ u("h1", { className: "text-display-lg font-headline", children: r.name }),
      r.description && /* @__PURE__ */ u("p", { className: "text-body-lg", style: { color: "rgb(var(--color-on-surface-variant))", maxWidth: "640px", marginTop: 8 }, children: r.description })
    ] }),
    /* @__PURE__ */ u("section", { className: "mp-section", children: /* @__PURE__ */ u("div", { className: "mp-grid mp-grid--3", children: e.map((i) => /* @__PURE__ */ u(Se, { card: i, site: t }, i.id)) }) })
  ] });
}
function ti({
  author: r,
  posts: e,
  site: t
}) {
  const n = Z.getFixedT(ee(t.settings.language), "theme-marketplace-core"), i = r.avatar ? Q(r.avatar, "medium") || Q(r.avatar) : "", o = /* @__PURE__ */ new Map();
  return e.forEach((s) => {
    if (!s.category) return;
    const a = s.category.url.replace(/^\/+/, "").split("/")[0];
    a && !o.has(a) && o.set(a, s.category.name);
  }), /* @__PURE__ */ g("article", { children: [
    /* @__PURE__ */ g("section", { className: "mp-author-card", children: [
      i ? /* @__PURE__ */ u("img", { className: "mp-author-card__avatar", src: i, alt: r.displayName }) : /* @__PURE__ */ u("div", { className: "mp-author-card__avatar" }),
      /* @__PURE__ */ g("div", { className: "mp-author-card__info", children: [
        /* @__PURE__ */ u("h1", { className: "mp-author-card__name", children: r.displayName }),
        r.title && /* @__PURE__ */ u("p", { className: "mp-author-card__title", children: r.title }),
        r.bio && /* @__PURE__ */ u("p", { className: "mp-author-card__bio", children: r.bio })
      ] })
    ] }),
    o.size > 1 && /* @__PURE__ */ g("div", { className: "mp-tabs", "data-cms-author-tabs": !0, role: "tablist", children: [
      /* @__PURE__ */ u("button", { type: "button", className: "mp-tabs__tab is-active", "data-cms-author-tab": "*", children: n("publicBaked.seeAll") }),
      Array.from(o.entries()).map(([s, a]) => /* @__PURE__ */ u(
        "button",
        {
          type: "button",
          className: "mp-tabs__tab",
          "data-cms-author-tab": s,
          children: a
        },
        s
      ))
    ] }),
    /* @__PURE__ */ u("div", { className: "mp-grid mp-grid--3", children: e.map((s) => {
      const a = s.category ? s.category.url.replace(/^\/+/, "").split("/")[0] : "";
      return /* @__PURE__ */ u("div", { "data-cms-author-card": a, children: /* @__PURE__ */ u(Se, { card: s, site: t }) }, s.id);
    }) }),
    /* @__PURE__ */ u(
      "script",
      {
        dangerouslySetInnerHTML: {
          __html: "(function(){var t=document.querySelector('[data-cms-author-tabs]');if(!t)return;t.addEventListener('click',function(e){var b=e.target.closest('[data-cms-author-tab]');if(!b)return;var s=b.getAttribute('data-cms-author-tab');t.querySelectorAll('[data-cms-author-tab]').forEach(function(x){x.classList.toggle('is-active',x===b)});document.querySelectorAll('[data-cms-author-card]').forEach(function(c){var ok=s==='*'||c.getAttribute('data-cms-author-card')===s;c.style.display=ok?'':'none'})});})();"
        }
      }
    )
  ] });
}
function ni({ site: r }) {
  const e = Z.getFixedT(ee(r.settings.language), "theme-marketplace-core");
  return /* @__PURE__ */ g("div", { className: "mp-404", children: [
    /* @__PURE__ */ u("span", { className: "material-symbols-outlined", children: "search_off" }),
    /* @__PURE__ */ u("h1", { children: "404" }),
    /* @__PURE__ */ u("p", { className: "text-body-lg", style: { color: "rgb(var(--color-on-surface-variant))" }, children: e("publicBaked.notFound") }),
    /* @__PURE__ */ u("a", { href: "/index.html", className: "mp-btn mp-btn--primary", children: e("publicBaked.backHome") })
  ] });
}
const ye = {
  title: "Theme settings",
  settings: {
    description: "Marketplace Core — app-store style theme for listing your themes and plugins. Wide cards, soft shadows, big rounded corners.",
    tabs: {
      home: "Home",
      single: "Product page",
      sidebar: "Sidebar",
      footer: "Footer",
      style: "Style & branding"
    },
    buttons: {
      save: "Save & apply",
      saving: "Saving…",
      saved: "Saved"
    }
  },
  publicBaked: {
    free: "Free",
    download: "Download",
    livePreview: "Live Preview",
    description: "Description",
    specifications: "Specifications",
    keyFeatures: "Key Features",
    nav: {
      home: "Home",
      themes: "Themes",
      plugins: "Plugins",
      authors: "Authors"
    },
    seeAll: "See all",
    by: "by",
    notFound: "Page not found",
    backHome: "Back to home",
    home: "Home"
  },
  blocks: {
    headerButtons: { title: "Download / Preview buttons", untitled: "(no URLs)" },
    gallery: { title: "Screenshot gallery", count: "{{n}} images" },
    specs: { title: "Specifications table", untitled: "Empty specs" },
    features: { title: "Key features bento", count: "{{n}} features" }
  }
}, ri = {
  title: "Réglages du thème",
  settings: {
    description: "Marketplace Core — thème app-store pour répertorier vos thèmes et plugins. Cartes larges, ombres douces, coins arrondis XL.",
    tabs: {
      home: "Accueil",
      single: "Page produit",
      sidebar: "Sidebar",
      footer: "Pied de page",
      style: "Style & branding"
    },
    buttons: {
      save: "Enregistrer et appliquer",
      saving: "Enregistrement…",
      saved: "Enregistré"
    }
  },
  publicBaked: {
    free: "Gratuit",
    download: "Télécharger",
    livePreview: "Démo en ligne",
    description: "Description",
    specifications: "Spécifications",
    keyFeatures: "Fonctionnalités clés",
    nav: {
      home: "Accueil",
      themes: "Thèmes",
      plugins: "Plugins",
      authors: "Auteurs"
    },
    seeAll: "Voir tout",
    by: "par",
    notFound: "Page introuvable",
    backHome: "Retour à l'accueil",
    home: "Accueil"
  },
  blocks: {
    headerButtons: { title: "Boutons Télécharger / Démo", untitled: "(aucune URL)" },
    gallery: { title: "Galerie captures d'écran", count: "{{n}} images" },
    specs: { title: "Tableau de spécifications", untitled: "Vide" },
    features: { title: "Fonctionnalités clés", count: "{{n}} fonctionnalités" }
  }
}, ii = ye, oi = ye, si = ye, ai = ye, li = ye, ci = "marketplace-core";
function ve(r) {
  if (r == null) return "";
  try {
    const e = JSON.stringify(r);
    return typeof window > "u" ? Buffer.from(e, "utf-8").toString("base64") : window.btoa(unescape(encodeURIComponent(e)));
  } catch {
    return "";
  }
}
function Le(r, e) {
  if (!r || typeof r != "string") return e;
  try {
    const t = typeof window > "u" ? Buffer.from(r, "base64").toString("utf-8") : decodeURIComponent(escape(window.atob(r)));
    return JSON.parse(t);
  } catch {
    return e;
  }
}
function Qt(r) {
  return typeof r != "string" ? "" : r.replace(/&/g, "&amp;").replace(/"/g, "&quot;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}
function J(r) {
  return typeof r != "string" ? "" : r.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}
function Rn(r) {
  return `marketplace${r.charAt(0).toUpperCase()}${r.slice(1)}`;
}
const Pe = {
  downloadUrl: "",
  previewUrl: "",
  downloadLabel: "Download",
  previewLabel: "Live Preview",
  freeLabel: "Free",
  creator: "",
  creatorPrefix: "by"
};
function di(r) {
  var p;
  const e = !!(r.downloadUrl || r.previewUrl), t = !!((p = r.creator) != null && p.trim());
  if (!e && !t) return "";
  const n = t ? `<div class="mp-product__author"><span>${J(r.creatorPrefix || "by")} <strong>${J(r.creator)}</strong></span></div>` : "", i = e ? `<span class="mp-badge-free">${J(r.freeLabel)}</span>` : "", o = r.downloadUrl ? `<a class="mp-btn mp-btn--primary" href="${Qt(r.downloadUrl)}" target="_blank" rel="noopener noreferrer"><span class="material-symbols-outlined">download</span>${J(r.downloadLabel)}</a>` : "", s = r.previewUrl ? `<a class="mp-btn mp-btn--secondary" href="${Qt(r.previewUrl)}" target="_blank" rel="noopener noreferrer"><span class="material-symbols-outlined">open_in_new</span>${J(r.previewLabel)}</a>` : "", a = e ? `${i}<div class="mp-product__cta-row">${o}${s}</div>` : "", l = n ? `<template data-cms-mp-headerbuttons-byline>${n}</template>` : "", c = a ? `<template data-cms-mp-headerbuttons-cta>${a}</template>` : "";
  return `${l}${c}<script>(function(){
function move(srcSel, dstSel){
  var tpl = document.querySelector(srcSel);
  if (!tpl) return;
  var dst = document.querySelector(dstSel);
  if (!dst) return;
  while (tpl.content.firstChild) dst.appendChild(tpl.content.firstChild);
  tpl.remove();
}
move('[data-cms-mp-headerbuttons-byline]','[data-cms-mp-byline-slot]');
move('[data-cms-mp-headerbuttons-cta]','[data-cms-mp-cta-slot]');
})();<\/script>`;
}
const ui = /<div\s+([^>]*data-cms-block="marketplace-core\/header-buttons"[^>]*)>\s*<\/div>/g;
function pi(r) {
  return r.replace(ui, (e, t) => {
    const n = t.match(/data-attrs=(?:"([^"]*)"|'([^']*)'|([^\s>]+))/), i = n ? n[1] ?? n[2] ?? n[3] ?? "" : "", o = Le(i, Pe);
    return di(o) || "";
  });
}
const $e = { images: [] };
function fi(r) {
  const e = (r.images ?? []).filter((i) => i && i.url);
  return e.length === 0 ? "" : `<template data-cms-mp-gallery>${JSON.stringify({ images: e }).replace(/</g, "\\u003c")}</template>` + `<script>(function(){
var tpl = document.querySelector('[data-cms-mp-gallery]');
if (!tpl) return;
var data; try { data = JSON.parse(tpl.innerHTML); } catch(e) { return; }
var galleryImgs = (data.images || []).filter(function(i){return i && i.url;});
if (galleryImgs.length === 0) return;

var hero = document.querySelector('.mp-product__hero-image');
var thumbsHost = document.querySelector('[data-cms-mp-thumbs]');

// Combine hero (slide 0) + gallery images (slides 1..n) for the
// lightbox slider. Allows clicking the hero to also open the
// zoom view.
var all = [];
if (hero && hero.src) all.push({ url: hero.src, alt: hero.alt || '' });
galleryImgs.forEach(function(g){ all.push({ url: g.url, alt: g.alt || '' }); });

// Populate the thumb strip — one per gallery image (the hero
// is its own visible image, no need to thumbnail it).
if (thumbsHost) {
  thumbsHost.removeAttribute('hidden');
  thumbsHost.innerHTML = '';
  galleryImgs.forEach(function(img, i){
    var b = document.createElement('button');
    b.type = 'button';
    b.className = 'mp-product__thumb';
    b.setAttribute('data-mp-lightbox-index', String(i + 1));
    var im = document.createElement('img');
    im.src = img.url;
    im.alt = img.alt;
    im.loading = 'lazy';
    b.appendChild(im);
    thumbsHost.appendChild(b);
  });
}

// Build the lightbox markup once and append to body. Idempotent —
// if a previous run already injected it (e.g. script re-evaluated
// in dev), we reuse the existing nodes.
var box = document.querySelector('.mp-lightbox');
if (!box) {
  box = document.createElement('div');
  box.className = 'mp-lightbox';
  box.setAttribute('hidden', '');
  box.setAttribute('role', 'dialog');
  box.setAttribute('aria-modal', 'true');
  box.innerHTML = '<button class="mp-lightbox__close" aria-label="Close">' +
    '<span class="material-symbols-outlined">close</span></button>' +
    '<button class="mp-lightbox__prev" aria-label="Previous">' +
    '<span class="material-symbols-outlined">chevron_left</span></button>' +
    '<button class="mp-lightbox__next" aria-label="Next">' +
    '<span class="material-symbols-outlined">chevron_right</span></button>' +
    '<div class="mp-lightbox__stage"><img class="mp-lightbox__image" alt=""/></div>' +
    '<div class="mp-lightbox__counter"></div>';
  document.body.appendChild(box);
}

var lbImg = box.querySelector('.mp-lightbox__image');
var lbCounter = box.querySelector('.mp-lightbox__counter');
var current = 0;

function show(i){
  if (i < 0) i = all.length - 1;
  if (i >= all.length) i = 0;
  current = i;
  lbImg.src = all[i].url;
  lbImg.alt = all[i].alt || '';
  lbCounter.textContent = (i + 1) + ' / ' + all.length;
}
function open(i){
  show(i);
  box.removeAttribute('hidden');
  document.body.style.overflow = 'hidden';
}
function close(){
  box.setAttribute('hidden', '');
  document.body.style.overflow = '';
}

box.addEventListener('click', function(e){
  if (e.target === box) close();
});
box.querySelector('.mp-lightbox__close').addEventListener('click', close);
box.querySelector('.mp-lightbox__prev').addEventListener('click', function(){ show(current - 1); });
box.querySelector('.mp-lightbox__next').addEventListener('click', function(){ show(current + 1); });

document.addEventListener('keydown', function(e){
  if (box.hasAttribute('hidden')) return;
  if (e.key === 'Escape') close();
  else if (e.key === 'ArrowLeft') show(current - 1);
  else if (e.key === 'ArrowRight') show(current + 1);
});

// Wire openers — hero image + every thumb.
if (hero) {
  hero.style.cursor = 'zoom-in';
  hero.addEventListener('click', function(){ open(0); });
}
if (thumbsHost) {
  thumbsHost.addEventListener('click', function(e){
    var btn = e.target.closest('[data-mp-lightbox-index]');
    if (!btn) return;
    var i = parseInt(btn.getAttribute('data-mp-lightbox-index'), 10);
    if (!isNaN(i)) open(i);
  });
}
})();<\/script>`;
}
const hi = /<div\s+([^>]*data-cms-block="marketplace-core\/gallery"[^>]*)>\s*<\/div>/g;
function mi(r) {
  return r.replace(hi, (e, t) => {
    const n = t.match(/data-attrs=(?:"([^"]*)"|'([^']*)'|([^\s>]+))/), i = n ? n[1] ?? n[2] ?? n[3] ?? "" : "", o = Le(i, $e);
    return fi(o) || "";
  });
}
const De = {
  heading: "Specifications",
  rows: [
    { label: "Version", value: "1.0.0" },
    { label: "License", value: "MIT" },
    { label: "Last Updated", value: "" },
    { label: "Requires Flexweg", value: "≥ 1.0.0" }
  ]
};
function gi(r) {
  const e = (r.rows ?? []).filter((i) => i.label || i.value);
  if (e.length === 0) return "";
  const t = e.map(
    (i) => `<div class="mp-specs__row"><span class="mp-specs__label">${J(i.label)}</span><span class="mp-specs__value">${J(i.value)}</span></div>`
  ).join("");
  return `${r.heading ? `<h3 class="mp-section-heading">${J(r.heading)}</h3>` : ""}<section class="mp-specs"><div class="mp-specs__grid">${t}</div></section>`;
}
const bi = /<div\s+([^>]*data-cms-block="marketplace-core\/specs"[^>]*)>\s*<\/div>/g;
function yi(r) {
  return r.replace(bi, (e, t) => {
    const n = t.match(/data-attrs=(?:"([^"]*)"|'([^']*)'|([^\s>]+))/), i = n ? n[1] ?? n[2] ?? n[3] ?? "" : "", o = Le(i, De);
    return gi(o) || "";
  });
}
const je = {
  heading: "Key Features",
  items: []
};
function xi(r) {
  const e = (r.items ?? []).filter((i) => i.title);
  if (e.length === 0) return "";
  const t = e.map(
    (i) => `<div class="mp-features__item"><div class="mp-features__icon"><span class="material-symbols-outlined">${J(i.icon || "bolt")}</span></div><h4 class="mp-features__title">${J(i.title)}</h4></div>`
  ).join("");
  return `${r.heading ? `<h3 class="mp-section-heading">${J(r.heading)}</h3>` : ""}<div class="mp-features">${t}</div>`;
}
const vi = /<div\s+([^>]*data-cms-block="marketplace-core\/features"[^>]*)>\s*<\/div>/g;
function wi(r) {
  return r.replace(vi, (e, t) => {
    const n = t.match(/data-attrs=(?:"([^"]*)"|'([^']*)'|([^\s>]+))/), i = n ? n[1] ?? n[2] ?? n[3] ?? "" : "", o = Le(i, je);
    return xi(o) || "";
  });
}
function ki(r) {
  let e = r;
  return e = pi(e), e = mi(e), e = yi(e), e = wi(e), e;
}
function Si(r) {
  const e = r.trim(), t = /^#([0-9a-fA-F]{3}|[0-9a-fA-F]{6})$/.exec(e);
  if (!t) return e;
  const n = t[1];
  if (n.length === 3) {
    const a = parseInt(n[0] + n[0], 16), l = parseInt(n[1] + n[1], 16), c = parseInt(n[2] + n[2], 16);
    return `${a} ${l} ${c}`;
  }
  const i = parseInt(n.slice(0, 2), 16), o = parseInt(n.slice(2, 4), 16), s = parseInt(n.slice(4, 6), 16);
  return `${i} ${o} ${s}`;
}
function Zt(r) {
  return `"${r.replace(/"/g, '\\"')}"`;
}
const ge = {
  sans: {
    "Hanken Grotesk": "Hanken+Grotesk:ital,wght@0,400;0,500;0,600;0,700;0,800;1,400",
    Inter: "Inter:wght@400;500;600;700",
    Manrope: "Manrope:wght@400;500;600;700",
    "Plus Jakarta Sans": "Plus+Jakarta+Sans:wght@400;500;600;700",
    Outfit: "Outfit:wght@400;500;600;700",
    "Space Grotesk": "Space+Grotesk:wght@400;500;600;700",
    "DM Sans": "DM+Sans:wght@400;500;600;700",
    "Work Sans": "Work+Sans:wght@400;500;600;700",
    "Bricolage Grotesque": "Bricolage+Grotesque:wght@400;500;600;700",
    Oswald: "Oswald:wght@400;500;600;700",
    "Barlow Condensed": "Barlow+Condensed:wght@400;500;600;700",
    "Big Shoulders Display": "Big+Shoulders+Display:wght@400;500;600;700",
    Anton: "Anton",
    "Archivo Black": "Archivo+Black",
    "Bowlby One": "Bowlby+One",
    Unbounded: "Unbounded:wght@400;500;600;700"
  },
  serif: {
    Newsreader: "Newsreader:ital,wght@0,300;0,400;0,500;0,600;0,700;1,400;1,700",
    Lora: "Lora:ital,wght@0,400;0,500;0,600;0,700;1,400;1,700",
    "Playfair Display": "Playfair+Display:ital,wght@0,400;0,500;0,600;0,700;1,400;1,700",
    "EB Garamond": "EB+Garamond:ital,wght@0,400;0,500;0,600;0,700;1,400;1,700",
    "Source Serif 4": "Source+Serif+4:ital,wght@0,400;0,500;0,600;0,700;1,400;1,700",
    "Cormorant Garamond": "Cormorant+Garamond:ital,wght@0,400;0,500;0,600;0,700;1,400;1,700",
    "Crimson Pro": "Crimson+Pro:ital,wght@0,400;0,500;0,600;0,700;1,400;1,700",
    Spectral: "Spectral:ital,wght@0,400;0,500;0,600;0,700;1,400;1,700",
    "DM Serif Display": "DM+Serif+Display:ital,wght@0,400;1,400"
  }
};
function en(r, e) {
  const t = {
    ...ge.sans,
    ...ge.serif
  };
  return t[r] ?? t[e];
}
function Ni(r, e) {
  const t = en(r, "Hanken Grotesk"), n = en(e, "Inter");
  return t === n ? `https://fonts.googleapis.com/css2?family=${t}&display=swap` : `https://fonts.googleapis.com/css2?family=${t}&family=${n}&display=swap`;
}
function Ci() {
  return `https://fonts.googleapis.com/css2?${[
    ...Object.keys(ge.sans),
    ...Object.keys(ge.serif)
  ].map((t) => `family=${t.replace(/ /g, "+")}`).join("&")}&display=swap`;
}
function Ei(r, e) {
  const t = {
    vars: { ...K.vars, ...e.vars },
    fontHeadline: e.fontHeadline || K.fontHeadline,
    fontBody: e.fontBody || K.fontBody
  }, n = t.fontHeadline !== K.fontHeadline || t.fontBody !== K.fontBody, i = Object.entries(t.vars).filter(([, l]) => l && l.trim());
  if (!n && i.length === 0) return r;
  let o = r;
  if (n) {
    const l = Ni(t.fontHeadline, t.fontBody);
    o = o.replace(
      /@import\s+url\(\s*"https:\/\/fonts\.googleapis\.com\/css2[^"]*"\s*\)\s*;/,
      `@import url("${l}");`
    );
  }
  const s = i.map(([l, c]) => {
    const d = l.startsWith("--color-");
    return `${l}:${d ? Si(c) : c};`;
  }).join(""), a = n ? `--font-headline:${Zt(t.fontHeadline)};--font-body:${Zt(t.fontBody)};` : "";
  return o += `
:root{${a}${s}}
`, o;
}
/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const _i = (r) => r.replace(/([a-z0-9])([A-Z])/g, "$1-$2").toLowerCase(), zn = (...r) => r.filter((e, t, n) => !!e && e.trim() !== "" && n.indexOf(e) === t).join(" ").trim();
/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
var Mi = {
  xmlns: "http://www.w3.org/2000/svg",
  width: 24,
  height: 24,
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  strokeWidth: 2,
  strokeLinecap: "round",
  strokeLinejoin: "round"
};
/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const Ai = At(
  ({
    color: r = "currentColor",
    size: e = 24,
    strokeWidth: t = 2,
    absoluteStrokeWidth: n,
    className: i = "",
    children: o,
    iconNode: s,
    ...a
  }, l) => Ge(
    "svg",
    {
      ref: l,
      ...Mi,
      width: e,
      height: e,
      stroke: r,
      strokeWidth: n ? Number(t) * 24 / Number(e) : t,
      className: zn("lucide", i),
      ...a
    },
    [
      ...s.map(([c, d]) => Ge(c, d)),
      ...Array.isArray(o) ? o : [o]
    ]
  )
);
/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const q = (r, e) => {
  const t = At(
    ({ className: n, ...i }, o) => Ge(Ai, {
      ref: o,
      iconNode: e,
      className: zn(`lucide-${_i(r)}`, n),
      ...i
    })
  );
  return t.displayName = `${r}`, t;
};
/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const Ti = q("ArrowDown", [
  ["path", { d: "M12 5v14", key: "s699le" }],
  ["path", { d: "m19 12-7 7-7-7", key: "1idqje" }]
]);
/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const Ii = q("ArrowUp", [
  ["path", { d: "m5 12 7-7 7 7", key: "hav0vg" }],
  ["path", { d: "M12 19V5", key: "x0mq9r" }]
]);
/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const Bn = q("Download", [
  ["path", { d: "M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4", key: "ih7n3h" }],
  ["polyline", { points: "7 10 12 15 17 10", key: "2ggqvy" }],
  ["line", { x1: "12", x2: "12", y1: "15", y2: "3", key: "1vk2je" }]
]);
/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const Tt = q("ImagePlus", [
  ["path", { d: "M16 5h6", key: "1vod17" }],
  ["path", { d: "M19 2v6", key: "4bpg5p" }],
  ["path", { d: "M21 11.5V19a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h7.5", key: "1ue2ih" }],
  ["path", { d: "m21 15-3.086-3.086a2 2 0 0 0-2.828 0L6 21", key: "1xmnt7" }],
  ["circle", { cx: "9", cy: "9", r: "2", key: "af1f0g" }]
]);
/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const Fn = q("ListChecks", [
  ["path", { d: "m3 17 2 2 4-4", key: "1jhpwq" }],
  ["path", { d: "m3 7 2 2 4-4", key: "1obspn" }],
  ["path", { d: "M13 6h8", key: "15sg57" }],
  ["path", { d: "M13 12h8", key: "h98zly" }],
  ["path", { d: "M13 18h8", key: "oe0vm4" }]
]);
/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const Oi = q("LoaderCircle", [
  ["path", { d: "M21 12a9 9 0 1 1-6.219-8.56", key: "13zald" }]
]);
/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const It = q("Plus", [
  ["path", { d: "M5 12h14", key: "1ays0h" }],
  ["path", { d: "M12 5v14", key: "s699le" }]
]);
/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const Ln = q("RotateCcw", [
  ["path", { d: "M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8", key: "1357e3" }],
  ["path", { d: "M3 3v5h5", key: "1xhq8a" }]
]);
/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const Ri = q("Save", [
  [
    "path",
    {
      d: "M15.2 3a2 2 0 0 1 1.4.6l3.8 3.8a2 2 0 0 1 .6 1.4V19a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2z",
      key: "1c8476"
    }
  ],
  ["path", { d: "M17 21v-7a1 1 0 0 0-1-1H8a1 1 0 0 0-1 1v7", key: "1ydtos" }],
  ["path", { d: "M7 3v4a1 1 0 0 0 1 1h7", key: "t51u73" }]
]);
/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const Pn = q("Sparkles", [
  [
    "path",
    {
      d: "M9.937 15.5A2 2 0 0 0 8.5 14.063l-6.135-1.582a.5.5 0 0 1 0-.962L8.5 9.936A2 2 0 0 0 9.937 8.5l1.582-6.135a.5.5 0 0 1 .963 0L14.063 8.5A2 2 0 0 0 15.5 9.937l6.135 1.581a.5.5 0 0 1 0 .964L15.5 14.063a2 2 0 0 0-1.437 1.437l-1.582 6.135a.5.5 0 0 1-.963 0z",
      key: "4pj2yx"
    }
  ],
  ["path", { d: "M20 3v4", key: "1olli1" }],
  ["path", { d: "M22 5h-4", key: "1gvqau" }],
  ["path", { d: "M4 17v2", key: "vumght" }],
  ["path", { d: "M5 18H3", key: "zchphs" }]
]);
/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const st = q("Trash2", [
  ["path", { d: "M3 6h18", key: "d0wm0j" }],
  ["path", { d: "M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6", key: "4alrt4" }],
  ["path", { d: "M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2", key: "v07s0e" }],
  ["line", { x1: "10", x2: "10", y1: "11", y2: "17", key: "1uufr5" }],
  ["line", { x1: "14", x2: "14", y1: "11", y2: "17", key: "xtxkd" }]
]);
function zi({
  config: r,
  save: e
}) {
  const t = {
    ...X,
    ...r,
    home: { ...X.home, ...r.home ?? {} },
    single: { ...X.single, ...r.single ?? {} },
    sidebar: { ...X.sidebar, ...r.sidebar ?? {} },
    footer: { ...X.footer, ...r.footer ?? {} },
    brand: { ...X.brand, ...r.brand ?? {} },
    style: { ...X.style, ...r.style ?? {} }
  }, [n, i] = he(t), [o, s] = he("home"), [a, l] = he(!1);
  async function c() {
    l(!0);
    try {
      await e(n);
    } finally {
      l(!1);
    }
  }
  return /* @__PURE__ */ g("div", { className: "space-y-6", children: [
    /* @__PURE__ */ u("p", { className: "text-sm text-surface-600 dark:text-surface-300", children: "Marketplace Core — app-store style theme for listing your themes and plugins." }),
    /* @__PURE__ */ u(
      "nav",
      {
        className: "flex flex-wrap gap-1 border-b border-surface-200 dark:border-surface-800",
        "aria-label": "Marketplace settings tabs",
        children: [
          { id: "home", label: "Home" },
          { id: "single", label: "Product page" },
          { id: "sidebar", label: "Sidebar" },
          { id: "footer", label: "Footer" },
          { id: "style", label: "Style" }
        ].map((p) => /* @__PURE__ */ u(
          Di,
          {
            active: o === p.id,
            onClick: () => s(p.id),
            label: p.label
          },
          p.id
        ))
      }
    ),
    o === "home" && /* @__PURE__ */ u(Bi, { home: n.home, onChange: (p) => i({ ...n, home: p }) }),
    o === "single" && /* @__PURE__ */ u(
      Fi,
      {
        single: n.single,
        onChange: (p) => i({ ...n, single: p })
      }
    ),
    o === "sidebar" && /* @__PURE__ */ u(
      Li,
      {
        sidebar: n.sidebar,
        onChange: (p) => i({ ...n, sidebar: p })
      }
    ),
    o === "footer" && /* @__PURE__ */ u(
      Pi,
      {
        copyright: n.footer.copyright,
        wordmark: n.brand.wordmark,
        onChange: (p, f) => i({
          ...n,
          footer: { ...n.footer, ...p },
          brand: { ...n.brand, ...f }
        })
      }
    ),
    o === "style" && /* @__PURE__ */ u($i, { style: n.style, onChange: (p) => i({ ...n, style: p }) }),
    /* @__PURE__ */ g("div", { className: "card p-4 flex flex-wrap gap-3 justify-end", children: [
      o === "style" && (() => {
        const p = n.style.fontHeadline !== K.fontHeadline || n.style.fontBody !== K.fontBody || Object.keys(n.style.vars ?? {}).length > 0;
        return /* @__PURE__ */ g(
          "button",
          {
            type: "button",
            onClick: () => i({ ...n, style: { ...K } }),
            disabled: !p,
            className: "btn-ghost disabled:opacity-40 disabled:cursor-not-allowed",
            title: "Reset fonts and palette to their defaults",
            children: [
              /* @__PURE__ */ u(Ln, { className: "h-4 w-4" }),
              "Reset to defaults"
            ]
          }
        );
      })(),
      /* @__PURE__ */ g(
        "button",
        {
          type: "button",
          onClick: c,
          disabled: a,
          className: "btn-primary disabled:opacity-60 disabled:cursor-wait",
          children: [
            a ? /* @__PURE__ */ u(Oi, { className: "h-4 w-4 animate-spin" }) : /* @__PURE__ */ u(Ri, { className: "h-4 w-4" }),
            a ? "Saving…" : "Save & apply"
          ]
        }
      )
    ] })
  ] });
}
function Bi({
  home: r,
  onChange: e
}) {
  return /* @__PURE__ */ g("div", { className: "space-y-4", children: [
    /* @__PURE__ */ g(j, { title: "Hero", children: [
      /* @__PURE__ */ u(E, { label: "Eyebrow", children: /* @__PURE__ */ u(
        "input",
        {
          className: "input",
          value: r.heroEyebrow,
          onChange: (t) => e({ ...r, heroEyebrow: t.target.value })
        }
      ) }),
      /* @__PURE__ */ u(E, { label: "Headline", children: /* @__PURE__ */ u(
        "input",
        {
          className: "input",
          value: r.heroHeadline,
          onChange: (t) => e({ ...r, heroHeadline: t.target.value })
        }
      ) }),
      /* @__PURE__ */ u(E, { label: "Intro", children: /* @__PURE__ */ u(
        "textarea",
        {
          className: "input",
          rows: 3,
          value: r.heroIntro,
          onChange: (t) => e({ ...r, heroIntro: t.target.value })
        }
      ) })
    ] }),
    /* @__PURE__ */ u(j, { title: "Featured section", children: /* @__PURE__ */ g("div", { className: "grid grid-cols-1 sm:grid-cols-3 gap-3", children: [
      /* @__PURE__ */ u(E, { label: "Category slug", children: /* @__PURE__ */ u(
        "input",
        {
          className: "input",
          value: r.featuredCategorySlug,
          onChange: (t) => e({ ...r, featuredCategorySlug: t.target.value })
        }
      ) }),
      /* @__PURE__ */ u(E, { label: "Heading", children: /* @__PURE__ */ u(
        "input",
        {
          className: "input",
          value: r.featuredHeading,
          onChange: (t) => e({ ...r, featuredHeading: t.target.value })
        }
      ) }),
      /* @__PURE__ */ u(E, { label: "Item count", children: /* @__PURE__ */ u(
        "input",
        {
          type: "number",
          min: 0,
          className: "input",
          value: r.featuredCount,
          onChange: (t) => e({ ...r, featuredCount: parseInt(t.target.value, 10) || 0 })
        }
      ) })
    ] }) }),
    /* @__PURE__ */ u(j, { title: "New section", children: /* @__PURE__ */ g("div", { className: "grid grid-cols-1 sm:grid-cols-3 gap-3", children: [
      /* @__PURE__ */ u(E, { label: "Category slug", children: /* @__PURE__ */ u(
        "input",
        {
          className: "input",
          value: r.newCategorySlug,
          onChange: (t) => e({ ...r, newCategorySlug: t.target.value })
        }
      ) }),
      /* @__PURE__ */ u(E, { label: "Heading", children: /* @__PURE__ */ u(
        "input",
        {
          className: "input",
          value: r.newHeading,
          onChange: (t) => e({ ...r, newHeading: t.target.value })
        }
      ) }),
      /* @__PURE__ */ u(E, { label: "Item count", children: /* @__PURE__ */ u(
        "input",
        {
          type: "number",
          min: 0,
          className: "input",
          value: r.newCount,
          onChange: (t) => e({ ...r, newCount: parseInt(t.target.value, 10) || 0 })
        }
      ) })
    ] }) }),
    /* @__PURE__ */ g(j, { title: "Recently Updated", children: [
      /* @__PURE__ */ u(
        St,
        {
          label: "Show this section",
          value: r.showRecentlyUpdated,
          onChange: (t) => e({ ...r, showRecentlyUpdated: t })
        }
      ),
      /* @__PURE__ */ g("div", { className: "grid grid-cols-1 sm:grid-cols-2 gap-3", children: [
        /* @__PURE__ */ u(E, { label: "Heading", children: /* @__PURE__ */ u(
          "input",
          {
            className: "input",
            value: r.recentlyUpdatedHeading,
            onChange: (t) => e({ ...r, recentlyUpdatedHeading: t.target.value })
          }
        ) }),
        /* @__PURE__ */ u(E, { label: "Item count", children: /* @__PURE__ */ u(
          "input",
          {
            type: "number",
            min: 0,
            className: "input",
            value: r.recentlyUpdatedCount,
            onChange: (t) => e({ ...r, recentlyUpdatedCount: parseInt(t.target.value, 10) || 0 })
          }
        ) })
      ] })
    ] })
  ] });
}
function Fi({
  single: r,
  onChange: e
}) {
  return /* @__PURE__ */ g("div", { className: "space-y-4", children: [
    /* @__PURE__ */ u(j, { title: "Section labels", children: /* @__PURE__ */ g("div", { className: "grid grid-cols-1 sm:grid-cols-3 gap-3", children: [
      /* @__PURE__ */ u(E, { label: "Description", children: /* @__PURE__ */ u(
        "input",
        {
          className: "input",
          value: r.descriptionLabel,
          onChange: (t) => e({ ...r, descriptionLabel: t.target.value })
        }
      ) }),
      /* @__PURE__ */ u(E, { label: "Specifications", children: /* @__PURE__ */ u(
        "input",
        {
          className: "input",
          value: r.specificationsLabel,
          onChange: (t) => e({ ...r, specificationsLabel: t.target.value })
        }
      ) }),
      /* @__PURE__ */ u(E, { label: "Features", children: /* @__PURE__ */ u(
        "input",
        {
          className: "input",
          value: r.featuresLabel,
          onChange: (t) => e({ ...r, featuresLabel: t.target.value })
        }
      ) })
    ] }) }),
    /* @__PURE__ */ u(j, { title: "Call-to-action labels", children: /* @__PURE__ */ g("div", { className: "grid grid-cols-1 sm:grid-cols-3 gap-3", children: [
      /* @__PURE__ */ u(E, { label: "Download button", children: /* @__PURE__ */ u(
        "input",
        {
          className: "input",
          value: r.downloadLabel,
          onChange: (t) => e({ ...r, downloadLabel: t.target.value })
        }
      ) }),
      /* @__PURE__ */ u(E, { label: "Preview button", children: /* @__PURE__ */ u(
        "input",
        {
          className: "input",
          value: r.previewLabel,
          onChange: (t) => e({ ...r, previewLabel: t.target.value })
        }
      ) }),
      /* @__PURE__ */ u(E, { label: "Free badge", children: /* @__PURE__ */ u(
        "input",
        {
          className: "input",
          value: r.freeBadgeLabel,
          onChange: (t) => e({ ...r, freeBadgeLabel: t.target.value })
        }
      ) })
    ] }) }),
    /* @__PURE__ */ g(j, { title: "Block visibility", children: [
      /* @__PURE__ */ u(
        St,
        {
          label: "Show specs block when present in body",
          value: r.showSpecs,
          onChange: (t) => e({ ...r, showSpecs: t })
        }
      ),
      /* @__PURE__ */ u(
        St,
        {
          label: "Show features block when present in body",
          value: r.showFeatures,
          onChange: (t) => e({ ...r, showFeatures: t })
        }
      )
    ] })
  ] });
}
function Li({
  sidebar: r,
  onChange: e
}) {
  return /* @__PURE__ */ g("div", { className: "space-y-4", children: [
    /* @__PURE__ */ g(j, { title: "Top section", children: [
      /* @__PURE__ */ u(E, { label: "Heading", children: /* @__PURE__ */ u(
        "input",
        {
          className: "input",
          value: r.heading,
          onChange: (t) => e({ ...r, heading: t.target.value })
        }
      ) }),
      /* @__PURE__ */ u(
        tn,
        {
          items: r.topItems,
          onChange: (t) => e({ ...r, topItems: t })
        }
      )
    ] }),
    /* @__PURE__ */ g(j, { title: "Categories", children: [
      /* @__PURE__ */ u(E, { label: "Heading", children: /* @__PURE__ */ u(
        "input",
        {
          className: "input",
          value: r.categoriesHeading,
          onChange: (t) => e({ ...r, categoriesHeading: t.target.value })
        }
      ) }),
      /* @__PURE__ */ u(
        tn,
        {
          items: r.categoriesItems,
          onChange: (t) => e({ ...r, categoriesItems: t })
        }
      )
    ] })
  ] });
}
function Pi({
  copyright: r,
  wordmark: e,
  onChange: t
}) {
  return /* @__PURE__ */ g("div", { className: "space-y-4", children: [
    /* @__PURE__ */ u(j, { title: "Brand", children: /* @__PURE__ */ g(E, { label: "Wordmark", children: [
      /* @__PURE__ */ u(
        "input",
        {
          className: "input",
          value: e,
          onChange: (n) => t({ copyright: r }, { wordmark: n.target.value })
        }
      ),
      /* @__PURE__ */ u("p", { className: "text-xs text-surface-500 mt-1", children: "Leave empty to fall back to the site title." })
    ] }) }),
    /* @__PURE__ */ u(j, { title: "Footer", children: /* @__PURE__ */ g(E, { label: "Copyright line", children: [
      /* @__PURE__ */ u(
        "input",
        {
          className: "input",
          value: r,
          onChange: (n) => t({ copyright: n.target.value }, { wordmark: e })
        }
      ),
      /* @__PURE__ */ g("p", { className: "text-xs text-surface-500 mt-1", children: [
        "Empty falls back to ",
        /* @__PURE__ */ u("code", { children: "© <year> <site title>." })
      ] })
    ] }) })
  ] });
}
function $i({
  style: r,
  onChange: e
}) {
  const t = [
    { name: "--color-primary", label: "Primary (action color)" },
    { name: "--color-secondary", label: "Secondary" },
    { name: "--color-tertiary", label: "Tertiary" },
    { name: "--color-background", label: "Background" },
    { name: "--color-on-surface", label: "Text" }
  ], n = [
    ...Object.keys(ge.sans).map((s) => ({
      name: s,
      fallback: "sans-serif"
    })),
    ...Object.keys(ge.serif).map((s) => ({
      name: s,
      fallback: "serif"
    }))
  ];
  function i(s, a) {
    const l = { ...r.vars };
    a && a.trim() ? l[s] = a : delete l[s], e({ ...r, vars: l });
  }
  function o(s) {
    const a = { ...r.vars };
    delete a[s], e({ ...r, vars: a });
  }
  return /* @__PURE__ */ g("div", { className: "space-y-4", children: [
    /* @__PURE__ */ u("link", { rel: "stylesheet", href: Ci() }),
    /* @__PURE__ */ u(j, { title: "Typography", children: /* @__PURE__ */ g("div", { className: "grid grid-cols-1 sm:grid-cols-2 gap-3", children: [
      /* @__PURE__ */ u(E, { label: "Headline font", children: /* @__PURE__ */ u(
        Kt,
        {
          options: n,
          value: r.fontHeadline,
          onChange: (s) => e({ ...r, fontHeadline: s }),
          ariaLabel: "Headline font"
        }
      ) }),
      /* @__PURE__ */ u(E, { label: "Body font", children: /* @__PURE__ */ u(
        Kt,
        {
          options: n,
          value: r.fontBody,
          onChange: (s) => e({ ...r, fontBody: s }),
          ariaLabel: "Body font"
        }
      ) })
    ] }) }),
    /* @__PURE__ */ g(j, { title: "Palette overrides", children: [
      /* @__PURE__ */ u("p", { className: "text-xs text-surface-500", children: "Leave a field empty to keep the bundled default. Click ↺ to clear an override." }),
      /* @__PURE__ */ u("div", { className: "space-y-2", children: t.map((s) => /* @__PURE__ */ u(
        ji,
        {
          label: s.label,
          value: r.vars[s.name] ?? "",
          onChange: (a) => i(s.name, a),
          onClear: () => o(s.name)
        },
        s.name
      )) })
    ] })
  ] });
}
function Di({
  active: r,
  onClick: e,
  label: t
}) {
  return /* @__PURE__ */ u(
    "button",
    {
      type: "button",
      onClick: e,
      className: r ? "px-3 py-2 text-sm font-medium -mb-px border-b-2 border-blue-600 text-surface-900 dark:text-surface-50" : "px-3 py-2 text-sm font-medium -mb-px border-b-2 border-transparent text-surface-500 hover:text-surface-900 dark:text-surface-400 dark:hover:text-surface-100",
      children: t
    }
  );
}
function j({ title: r, children: e }) {
  return /* @__PURE__ */ g("section", { className: "card p-4 space-y-3", children: [
    /* @__PURE__ */ u("h3", { className: "text-sm font-semibold text-surface-900 dark:text-surface-50", children: r }),
    e
  ] });
}
function E({ label: r, children: e }) {
  return /* @__PURE__ */ g("div", { children: [
    /* @__PURE__ */ u("label", { className: "label", children: r }),
    e
  ] });
}
function St({
  label: r,
  value: e,
  onChange: t
}) {
  return /* @__PURE__ */ g("label", { className: "flex items-center gap-2 text-sm text-surface-700 dark:text-surface-300 cursor-pointer", children: [
    /* @__PURE__ */ u(
      "input",
      {
        type: "checkbox",
        checked: e,
        onChange: (n) => t(n.target.checked),
        className: "h-4 w-4 rounded border-surface-300 text-blue-600 focus:ring-blue-500"
      }
    ),
    /* @__PURE__ */ u("span", { children: r })
  ] });
}
function ji({
  label: r,
  value: e,
  onChange: t,
  onClear: n
}) {
  const i = !!e;
  return /* @__PURE__ */ g("div", { className: "flex items-center gap-3", children: [
    /* @__PURE__ */ u(
      "input",
      {
        type: "color",
        value: /^#/.test(e) ? e : "#0037b0",
        onChange: (o) => t(o.target.value),
        className: "h-8 w-10 rounded border border-surface-300 dark:border-surface-700 cursor-pointer shrink-0"
      }
    ),
    /* @__PURE__ */ u("span", { className: "flex-1 text-sm text-surface-700 dark:text-surface-300", children: r }),
    /* @__PURE__ */ u("code", { className: "text-xs text-surface-500 tabular-nums", children: e || "default" }),
    /* @__PURE__ */ u(
      "button",
      {
        type: "button",
        onClick: n,
        disabled: !i,
        className: "p-1 rounded text-surface-500 hover:text-surface-900 hover:bg-surface-100 dark:hover:bg-surface-800 disabled:opacity-30 disabled:cursor-not-allowed",
        title: "Clear override",
        "aria-label": "Clear override",
        children: /* @__PURE__ */ u(Ln, { className: "h-3.5 w-3.5" })
      }
    )
  ] });
}
function tn({
  items: r,
  onChange: e
}) {
  function t(o, s) {
    const a = [...r];
    a[o] = { ...a[o], ...s }, e(a);
  }
  function n(o) {
    e(r.filter((s, a) => a !== o));
  }
  function i() {
    e([...r, { icon: "", label: "", href: "" }]);
  }
  return /* @__PURE__ */ g("div", { className: "space-y-2", children: [
    r.length === 0 && /* @__PURE__ */ u("p", { className: "text-xs text-surface-500", children: "No items yet." }),
    r.map((o, s) => /* @__PURE__ */ g(
      "div",
      {
        className: "grid grid-cols-1 sm:grid-cols-[1fr_2fr_3fr_auto] gap-2 items-center p-2 rounded border border-surface-200 dark:border-surface-800",
        children: [
          /* @__PURE__ */ u(
            "input",
            {
              className: "input text-xs",
              placeholder: "Icon",
              value: o.icon,
              onChange: (a) => t(s, { icon: a.target.value })
            }
          ),
          /* @__PURE__ */ u(
            "input",
            {
              className: "input text-xs",
              placeholder: "Label",
              value: o.label,
              onChange: (a) => t(s, { label: a.target.value })
            }
          ),
          /* @__PURE__ */ u(
            "input",
            {
              className: "input text-xs",
              placeholder: "/path/to/page.html",
              value: o.href,
              onChange: (a) => t(s, { href: a.target.value })
            }
          ),
          /* @__PURE__ */ u(
            "button",
            {
              type: "button",
              onClick: () => n(s),
              className: "p-1.5 rounded text-red-600 hover:bg-red-50 dark:hover:bg-red-900/30",
              "aria-label": "Remove item",
              title: "Remove item",
              children: /* @__PURE__ */ u(st, { className: "h-3.5 w-3.5" })
            }
          )
        ]
      },
      s
    )),
    /* @__PURE__ */ g(
      "button",
      {
        type: "button",
        onClick: i,
        className: "btn-secondary text-xs",
        children: [
          /* @__PURE__ */ u(It, { className: "h-3.5 w-3.5" }),
          "Add item"
        ]
      }
    )
  ] });
}
function I(r) {
  this.content = r;
}
I.prototype = {
  constructor: I,
  find: function(r) {
    for (var e = 0; e < this.content.length; e += 2)
      if (this.content[e] === r) return e;
    return -1;
  },
  // :: (string) → ?any
  // Retrieve the value stored under `key`, or return undefined when
  // no such key exists.
  get: function(r) {
    var e = this.find(r);
    return e == -1 ? void 0 : this.content[e + 1];
  },
  // :: (string, any, ?string) → OrderedMap
  // Create a new map by replacing the value of `key` with a new
  // value, or adding a binding to the end of the map. If `newKey` is
  // given, the key of the binding will be replaced with that key.
  update: function(r, e, t) {
    var n = t && t != r ? this.remove(t) : this, i = n.find(r), o = n.content.slice();
    return i == -1 ? o.push(t || r, e) : (o[i + 1] = e, t && (o[i] = t)), new I(o);
  },
  // :: (string) → OrderedMap
  // Return a map with the given key removed, if it existed.
  remove: function(r) {
    var e = this.find(r);
    if (e == -1) return this;
    var t = this.content.slice();
    return t.splice(e, 2), new I(t);
  },
  // :: (string, any) → OrderedMap
  // Add a new key to the start of the map.
  addToStart: function(r, e) {
    return new I([r, e].concat(this.remove(r).content));
  },
  // :: (string, any) → OrderedMap
  // Add a new key to the end of the map.
  addToEnd: function(r, e) {
    var t = this.remove(r).content.slice();
    return t.push(r, e), new I(t);
  },
  // :: (string, string, any) → OrderedMap
  // Add a key after the given key. If `place` is not found, the new
  // key is added to the end.
  addBefore: function(r, e, t) {
    var n = this.remove(e), i = n.content.slice(), o = n.find(r);
    return i.splice(o == -1 ? i.length : o, 0, e, t), new I(i);
  },
  // :: ((key: string, value: any))
  // Call the given function for each key/value pair in the map, in
  // order.
  forEach: function(r) {
    for (var e = 0; e < this.content.length; e += 2)
      r(this.content[e], this.content[e + 1]);
  },
  // :: (union<Object, OrderedMap>) → OrderedMap
  // Create a new map by prepending the keys in this map that don't
  // appear in `map` before the keys in `map`.
  prepend: function(r) {
    return r = I.from(r), r.size ? new I(r.content.concat(this.subtract(r).content)) : this;
  },
  // :: (union<Object, OrderedMap>) → OrderedMap
  // Create a new map by appending the keys in this map that don't
  // appear in `map` after the keys in `map`.
  append: function(r) {
    return r = I.from(r), r.size ? new I(this.subtract(r).content.concat(r.content)) : this;
  },
  // :: (union<Object, OrderedMap>) → OrderedMap
  // Create a map containing all the keys in this map that don't
  // appear in `map`.
  subtract: function(r) {
    var e = this;
    r = I.from(r);
    for (var t = 0; t < r.content.length; t += 2)
      e = e.remove(r.content[t]);
    return e;
  },
  // :: () → Object
  // Turn ordered map into a plain object.
  toObject: function() {
    var r = {};
    return this.forEach(function(e, t) {
      r[e] = t;
    }), r;
  },
  // :: number
  // The amount of keys in this map.
  get size() {
    return this.content.length >> 1;
  }
};
I.from = function(r) {
  if (r instanceof I) return r;
  var e = [];
  if (r) for (var t in r) e.push(t, r[t]);
  return new I(e);
};
function $n(r, e, t) {
  for (let n = 0; ; n++) {
    if (n == r.childCount || n == e.childCount)
      return r.childCount == e.childCount ? null : t;
    let i = r.child(n), o = e.child(n);
    if (i == o) {
      t += i.nodeSize;
      continue;
    }
    if (!i.sameMarkup(o))
      return t;
    if (i.isText && i.text != o.text) {
      for (let s = 0; i.text[s] == o.text[s]; s++)
        t++;
      return t;
    }
    if (i.content.size || o.content.size) {
      let s = $n(i.content, o.content, t + 1);
      if (s != null)
        return s;
    }
    t += i.nodeSize;
  }
}
function Dn(r, e, t, n) {
  for (let i = r.childCount, o = e.childCount; ; ) {
    if (i == 0 || o == 0)
      return i == o ? null : { a: t, b: n };
    let s = r.child(--i), a = e.child(--o), l = s.nodeSize;
    if (s == a) {
      t -= l, n -= l;
      continue;
    }
    if (!s.sameMarkup(a))
      return { a: t, b: n };
    if (s.isText && s.text != a.text) {
      let c = 0, d = Math.min(s.text.length, a.text.length);
      for (; c < d && s.text[s.text.length - c - 1] == a.text[a.text.length - c - 1]; )
        c++, t--, n--;
      return { a: t, b: n };
    }
    if (s.content.size || a.content.size) {
      let c = Dn(s.content, a.content, t - 1, n - 1);
      if (c)
        return c;
    }
    t -= l, n -= l;
  }
}
class x {
  /**
  @internal
  */
  constructor(e, t) {
    if (this.content = e, this.size = t || 0, t == null)
      for (let n = 0; n < e.length; n++)
        this.size += e[n].nodeSize;
  }
  /**
  Invoke a callback for all descendant nodes between the given two
  positions (relative to start of this fragment). Doesn't descend
  into a node when the callback returns `false`.
  */
  nodesBetween(e, t, n, i = 0, o) {
    for (let s = 0, a = 0; a < t; s++) {
      let l = this.content[s], c = a + l.nodeSize;
      if (c > e && n(l, i + a, o || null, s) !== !1 && l.content.size) {
        let d = a + 1;
        l.nodesBetween(Math.max(0, e - d), Math.min(l.content.size, t - d), n, i + d);
      }
      a = c;
    }
  }
  /**
  Call the given callback for every descendant node. `pos` will be
  relative to the start of the fragment. The callback may return
  `false` to prevent traversal of a given node's children.
  */
  descendants(e) {
    this.nodesBetween(0, this.size, e);
  }
  /**
  Extract the text between `from` and `to`. See the same method on
  [`Node`](https://prosemirror.net/docs/ref/#model.Node.textBetween).
  */
  textBetween(e, t, n, i) {
    let o = "", s = !0;
    return this.nodesBetween(e, t, (a, l) => {
      let c = a.isText ? a.text.slice(Math.max(e, l) - l, t - l) : a.isLeaf ? i ? typeof i == "function" ? i(a) : i : a.type.spec.leafText ? a.type.spec.leafText(a) : "" : "";
      a.isBlock && (a.isLeaf && c || a.isTextblock) && n && (s ? s = !1 : o += n), o += c;
    }, 0), o;
  }
  /**
  Create a new fragment containing the combined content of this
  fragment and the other.
  */
  append(e) {
    if (!e.size)
      return this;
    if (!this.size)
      return e;
    let t = this.lastChild, n = e.firstChild, i = this.content.slice(), o = 0;
    for (t.isText && t.sameMarkup(n) && (i[i.length - 1] = t.withText(t.text + n.text), o = 1); o < e.content.length; o++)
      i.push(e.content[o]);
    return new x(i, this.size + e.size);
  }
  /**
  Cut out the sub-fragment between the two given positions.
  */
  cut(e, t = this.size) {
    if (e == 0 && t == this.size)
      return this;
    let n = [], i = 0;
    if (t > e)
      for (let o = 0, s = 0; s < t; o++) {
        let a = this.content[o], l = s + a.nodeSize;
        l > e && ((s < e || l > t) && (a.isText ? a = a.cut(Math.max(0, e - s), Math.min(a.text.length, t - s)) : a = a.cut(Math.max(0, e - s - 1), Math.min(a.content.size, t - s - 1))), n.push(a), i += a.nodeSize), s = l;
      }
    return new x(n, i);
  }
  /**
  @internal
  */
  cutByIndex(e, t) {
    return e == t ? x.empty : e == 0 && t == this.content.length ? this : new x(this.content.slice(e, t));
  }
  /**
  Create a new fragment in which the node at the given index is
  replaced by the given node.
  */
  replaceChild(e, t) {
    let n = this.content[e];
    if (n == t)
      return this;
    let i = this.content.slice(), o = this.size + t.nodeSize - n.nodeSize;
    return i[e] = t, new x(i, o);
  }
  /**
  Create a new fragment by prepending the given node to this
  fragment.
  */
  addToStart(e) {
    return new x([e].concat(this.content), this.size + e.nodeSize);
  }
  /**
  Create a new fragment by appending the given node to this
  fragment.
  */
  addToEnd(e) {
    return new x(this.content.concat(e), this.size + e.nodeSize);
  }
  /**
  Compare this fragment to another one.
  */
  eq(e) {
    if (this.content.length != e.content.length)
      return !1;
    for (let t = 0; t < this.content.length; t++)
      if (!this.content[t].eq(e.content[t]))
        return !1;
    return !0;
  }
  /**
  The first child of the fragment, or `null` if it is empty.
  */
  get firstChild() {
    return this.content.length ? this.content[0] : null;
  }
  /**
  The last child of the fragment, or `null` if it is empty.
  */
  get lastChild() {
    return this.content.length ? this.content[this.content.length - 1] : null;
  }
  /**
  The number of child nodes in this fragment.
  */
  get childCount() {
    return this.content.length;
  }
  /**
  Get the child node at the given index. Raise an error when the
  index is out of range.
  */
  child(e) {
    let t = this.content[e];
    if (!t)
      throw new RangeError("Index " + e + " out of range for " + this);
    return t;
  }
  /**
  Get the child node at the given index, if it exists.
  */
  maybeChild(e) {
    return this.content[e] || null;
  }
  /**
  Call `f` for every child node, passing the node, its offset
  into this parent node, and its index.
  */
  forEach(e) {
    for (let t = 0, n = 0; t < this.content.length; t++) {
      let i = this.content[t];
      e(i, n, t), n += i.nodeSize;
    }
  }
  /**
  Find the first position at which this fragment and another
  fragment differ, or `null` if they are the same.
  */
  findDiffStart(e, t = 0) {
    return $n(this, e, t);
  }
  /**
  Find the first position, searching from the end, at which this
  fragment and the given fragment differ, or `null` if they are
  the same. Since this position will not be the same in both
  nodes, an object with two separate positions is returned.
  */
  findDiffEnd(e, t = this.size, n = e.size) {
    return Dn(this, e, t, n);
  }
  /**
  Find the index and inner offset corresponding to a given relative
  position in this fragment. The result object will be reused
  (overwritten) the next time the function is called. @internal
  */
  findIndex(e) {
    if (e == 0)
      return He(0, e);
    if (e == this.size)
      return He(this.content.length, e);
    if (e > this.size || e < 0)
      throw new RangeError(`Position ${e} outside of fragment (${this})`);
    for (let t = 0, n = 0; ; t++) {
      let i = this.child(t), o = n + i.nodeSize;
      if (o >= e)
        return o == e ? He(t + 1, o) : He(t, n);
      n = o;
    }
  }
  /**
  Return a debugging string that describes this fragment.
  */
  toString() {
    return "<" + this.toStringInner() + ">";
  }
  /**
  @internal
  */
  toStringInner() {
    return this.content.join(", ");
  }
  /**
  Create a JSON-serializeable representation of this fragment.
  */
  toJSON() {
    return this.content.length ? this.content.map((e) => e.toJSON()) : null;
  }
  /**
  Deserialize a fragment from its JSON representation.
  */
  static fromJSON(e, t) {
    if (!t)
      return x.empty;
    if (!Array.isArray(t))
      throw new RangeError("Invalid input for Fragment.fromJSON");
    return new x(t.map(e.nodeFromJSON));
  }
  /**
  Build a fragment from an array of nodes. Ensures that adjacent
  text nodes with the same marks are joined together.
  */
  static fromArray(e) {
    if (!e.length)
      return x.empty;
    let t, n = 0;
    for (let i = 0; i < e.length; i++) {
      let o = e[i];
      n += o.nodeSize, i && o.isText && e[i - 1].sameMarkup(o) ? (t || (t = e.slice(0, i)), t[t.length - 1] = o.withText(t[t.length - 1].text + o.text)) : t && t.push(o);
    }
    return new x(t || e, n);
  }
  /**
  Create a fragment from something that can be interpreted as a
  set of nodes. For `null`, it returns the empty fragment. For a
  fragment, the fragment itself. For a node or array of nodes, a
  fragment containing those nodes.
  */
  static from(e) {
    if (!e)
      return x.empty;
    if (e instanceof x)
      return e;
    if (Array.isArray(e))
      return this.fromArray(e);
    if (e.attrs)
      return new x([e], e.nodeSize);
    throw new RangeError("Can not convert " + e + " to a Fragment" + (e.nodesBetween ? " (looks like multiple versions of prosemirror-model were loaded)" : ""));
  }
}
x.empty = new x([], 0);
const ft = { index: 0, offset: 0 };
function He(r, e) {
  return ft.index = r, ft.offset = e, ft;
}
function Ye(r, e) {
  if (r === e)
    return !0;
  if (!(r && typeof r == "object") || !(e && typeof e == "object"))
    return !1;
  let t = Array.isArray(r);
  if (Array.isArray(e) != t)
    return !1;
  if (t) {
    if (r.length != e.length)
      return !1;
    for (let n = 0; n < r.length; n++)
      if (!Ye(r[n], e[n]))
        return !1;
  } else {
    for (let n in r)
      if (!(n in e) || !Ye(r[n], e[n]))
        return !1;
    for (let n in e)
      if (!(n in r))
        return !1;
  }
  return !0;
}
class N {
  /**
  @internal
  */
  constructor(e, t) {
    this.type = e, this.attrs = t;
  }
  /**
  Given a set of marks, create a new set which contains this one as
  well, in the right position. If this mark is already in the set,
  the set itself is returned. If any marks that are set to be
  [exclusive](https://prosemirror.net/docs/ref/#model.MarkSpec.excludes) with this mark are present,
  those are replaced by this one.
  */
  addToSet(e) {
    let t, n = !1;
    for (let i = 0; i < e.length; i++) {
      let o = e[i];
      if (this.eq(o))
        return e;
      if (this.type.excludes(o.type))
        t || (t = e.slice(0, i));
      else {
        if (o.type.excludes(this.type))
          return e;
        !n && o.type.rank > this.type.rank && (t || (t = e.slice(0, i)), t.push(this), n = !0), t && t.push(o);
      }
    }
    return t || (t = e.slice()), n || t.push(this), t;
  }
  /**
  Remove this mark from the given set, returning a new set. If this
  mark is not in the set, the set itself is returned.
  */
  removeFromSet(e) {
    for (let t = 0; t < e.length; t++)
      if (this.eq(e[t]))
        return e.slice(0, t).concat(e.slice(t + 1));
    return e;
  }
  /**
  Test whether this mark is in the given set of marks.
  */
  isInSet(e) {
    for (let t = 0; t < e.length; t++)
      if (this.eq(e[t]))
        return !0;
    return !1;
  }
  /**
  Test whether this mark has the same type and attributes as
  another mark.
  */
  eq(e) {
    return this == e || this.type == e.type && Ye(this.attrs, e.attrs);
  }
  /**
  Convert this mark to a JSON-serializeable representation.
  */
  toJSON() {
    let e = { type: this.type.name };
    for (let t in this.attrs) {
      e.attrs = this.attrs;
      break;
    }
    return e;
  }
  /**
  Deserialize a mark from JSON.
  */
  static fromJSON(e, t) {
    if (!t)
      throw new RangeError("Invalid input for Mark.fromJSON");
    let n = e.marks[t.type];
    if (!n)
      throw new RangeError(`There is no mark type ${t.type} in this schema`);
    let i = n.create(t.attrs);
    return n.checkAttrs(i.attrs), i;
  }
  /**
  Test whether two sets of marks are identical.
  */
  static sameSet(e, t) {
    if (e == t)
      return !0;
    if (e.length != t.length)
      return !1;
    for (let n = 0; n < e.length; n++)
      if (!e[n].eq(t[n]))
        return !1;
    return !0;
  }
  /**
  Create a properly sorted mark set from null, a single mark, or an
  unsorted array of marks.
  */
  static setFrom(e) {
    if (!e || Array.isArray(e) && e.length == 0)
      return N.none;
    if (e instanceof N)
      return [e];
    let t = e.slice();
    return t.sort((n, i) => n.type.rank - i.type.rank), t;
  }
}
N.none = [];
class Xe extends Error {
}
class w {
  /**
  Create a slice. When specifying a non-zero open depth, you must
  make sure that there are nodes of at least that depth at the
  appropriate side of the fragment—i.e. if the fragment is an
  empty paragraph node, `openStart` and `openEnd` can't be greater
  than 1.
  
  It is not necessary for the content of open nodes to conform to
  the schema's content constraints, though it should be a valid
  start/end/middle for such a node, depending on which sides are
  open.
  */
  constructor(e, t, n) {
    this.content = e, this.openStart = t, this.openEnd = n;
  }
  /**
  The size this slice would add when inserted into a document.
  */
  get size() {
    return this.content.size - this.openStart - this.openEnd;
  }
  /**
  @internal
  */
  insertAt(e, t) {
    let n = Hn(this.content, e + this.openStart, t);
    return n && new w(n, this.openStart, this.openEnd);
  }
  /**
  @internal
  */
  removeBetween(e, t) {
    return new w(jn(this.content, e + this.openStart, t + this.openStart), this.openStart, this.openEnd);
  }
  /**
  Tests whether this slice is equal to another slice.
  */
  eq(e) {
    return this.content.eq(e.content) && this.openStart == e.openStart && this.openEnd == e.openEnd;
  }
  /**
  @internal
  */
  toString() {
    return this.content + "(" + this.openStart + "," + this.openEnd + ")";
  }
  /**
  Convert a slice to a JSON-serializable representation.
  */
  toJSON() {
    if (!this.content.size)
      return null;
    let e = { content: this.content.toJSON() };
    return this.openStart > 0 && (e.openStart = this.openStart), this.openEnd > 0 && (e.openEnd = this.openEnd), e;
  }
  /**
  Deserialize a slice from its JSON representation.
  */
  static fromJSON(e, t) {
    if (!t)
      return w.empty;
    let n = t.openStart || 0, i = t.openEnd || 0;
    if (typeof n != "number" || typeof i != "number")
      throw new RangeError("Invalid input for Slice.fromJSON");
    return new w(x.fromJSON(e, t.content), n, i);
  }
  /**
  Create a slice from a fragment by taking the maximum possible
  open value on both side of the fragment.
  */
  static maxOpen(e, t = !0) {
    let n = 0, i = 0;
    for (let o = e.firstChild; o && !o.isLeaf && (t || !o.type.spec.isolating); o = o.firstChild)
      n++;
    for (let o = e.lastChild; o && !o.isLeaf && (t || !o.type.spec.isolating); o = o.lastChild)
      i++;
    return new w(e, n, i);
  }
}
w.empty = new w(x.empty, 0, 0);
function jn(r, e, t) {
  let { index: n, offset: i } = r.findIndex(e), o = r.maybeChild(n), { index: s, offset: a } = r.findIndex(t);
  if (i == e || o.isText) {
    if (a != t && !r.child(s).isText)
      throw new RangeError("Removing non-flat range");
    return r.cut(0, e).append(r.cut(t));
  }
  if (n != s)
    throw new RangeError("Removing non-flat range");
  return r.replaceChild(n, o.copy(jn(o.content, e - i - 1, t - i - 1)));
}
function Hn(r, e, t, n) {
  let { index: i, offset: o } = r.findIndex(e), s = r.maybeChild(i);
  if (o == e || s.isText)
    return n && !n.canReplace(i, i, t) ? null : r.cut(0, e).append(t).append(r.cut(e));
  let a = Hn(s.content, e - o - 1, t, s);
  return a && r.replaceChild(i, s.copy(a));
}
function Hi(r, e, t) {
  if (t.openStart > r.depth)
    throw new Xe("Inserted content deeper than insertion position");
  if (r.depth - t.openStart != e.depth - t.openEnd)
    throw new Xe("Inconsistent open depths");
  return Un(r, e, t, 0);
}
function Un(r, e, t, n) {
  let i = r.index(n), o = r.node(n);
  if (i == e.index(n) && n < r.depth - t.openStart) {
    let s = Un(r, e, t, n + 1);
    return o.copy(o.content.replaceChild(i, s));
  } else if (t.content.size)
    if (!t.openStart && !t.openEnd && r.depth == n && e.depth == n) {
      let s = r.parent, a = s.content;
      return ae(s, a.cut(0, r.parentOffset).append(t.content).append(a.cut(e.parentOffset)));
    } else {
      let { start: s, end: a } = Ui(t, r);
      return ae(o, Vn(r, s, a, e, n));
    }
  else return ae(o, Qe(r, e, n));
}
function Jn(r, e) {
  if (!e.type.compatibleContent(r.type))
    throw new Xe("Cannot join " + e.type.name + " onto " + r.type.name);
}
function Nt(r, e, t) {
  let n = r.node(t);
  return Jn(n, e.node(t)), n;
}
function se(r, e) {
  let t = e.length - 1;
  t >= 0 && r.isText && r.sameMarkup(e[t]) ? e[t] = r.withText(e[t].text + r.text) : e.push(r);
}
function Ne(r, e, t, n) {
  let i = (e || r).node(t), o = 0, s = e ? e.index(t) : i.childCount;
  r && (o = r.index(t), r.depth > t ? o++ : r.textOffset && (se(r.nodeAfter, n), o++));
  for (let a = o; a < s; a++)
    se(i.child(a), n);
  e && e.depth == t && e.textOffset && se(e.nodeBefore, n);
}
function ae(r, e) {
  return r.type.checkContent(e), r.copy(e);
}
function Vn(r, e, t, n, i) {
  let o = r.depth > i && Nt(r, e, i + 1), s = n.depth > i && Nt(t, n, i + 1), a = [];
  return Ne(null, r, i, a), o && s && e.index(i) == t.index(i) ? (Jn(o, s), se(ae(o, Vn(r, e, t, n, i + 1)), a)) : (o && se(ae(o, Qe(r, e, i + 1)), a), Ne(e, t, i, a), s && se(ae(s, Qe(t, n, i + 1)), a)), Ne(n, null, i, a), new x(a);
}
function Qe(r, e, t) {
  let n = [];
  if (Ne(null, r, t, n), r.depth > t) {
    let i = Nt(r, e, t + 1);
    se(ae(i, Qe(r, e, t + 1)), n);
  }
  return Ne(e, null, t, n), new x(n);
}
function Ui(r, e) {
  let t = e.depth - r.openStart, i = e.node(t).copy(r.content);
  for (let o = t - 1; o >= 0; o--)
    i = e.node(o).copy(x.from(i));
  return {
    start: i.resolveNoCache(r.openStart + t),
    end: i.resolveNoCache(i.content.size - r.openEnd - t)
  };
}
class Ie {
  /**
  @internal
  */
  constructor(e, t, n) {
    this.pos = e, this.path = t, this.parentOffset = n, this.depth = t.length / 3 - 1;
  }
  /**
  @internal
  */
  resolveDepth(e) {
    return e == null ? this.depth : e < 0 ? this.depth + e : e;
  }
  /**
  The parent node that the position points into. Note that even if
  a position points into a text node, that node is not considered
  the parent—text nodes are ‘flat’ in this model, and have no content.
  */
  get parent() {
    return this.node(this.depth);
  }
  /**
  The root node in which the position was resolved.
  */
  get doc() {
    return this.node(0);
  }
  /**
  The ancestor node at the given level. `p.node(p.depth)` is the
  same as `p.parent`.
  */
  node(e) {
    return this.path[this.resolveDepth(e) * 3];
  }
  /**
  The index into the ancestor at the given level. If this points
  at the 3rd node in the 2nd paragraph on the top level, for
  example, `p.index(0)` is 1 and `p.index(1)` is 2.
  */
  index(e) {
    return this.path[this.resolveDepth(e) * 3 + 1];
  }
  /**
  The index pointing after this position into the ancestor at the
  given level.
  */
  indexAfter(e) {
    return e = this.resolveDepth(e), this.index(e) + (e == this.depth && !this.textOffset ? 0 : 1);
  }
  /**
  The (absolute) position at the start of the node at the given
  level.
  */
  start(e) {
    return e = this.resolveDepth(e), e == 0 ? 0 : this.path[e * 3 - 1] + 1;
  }
  /**
  The (absolute) position at the end of the node at the given
  level.
  */
  end(e) {
    return e = this.resolveDepth(e), this.start(e) + this.node(e).content.size;
  }
  /**
  The (absolute) position directly before the wrapping node at the
  given level, or, when `depth` is `this.depth + 1`, the original
  position.
  */
  before(e) {
    if (e = this.resolveDepth(e), !e)
      throw new RangeError("There is no position before the top-level node");
    return e == this.depth + 1 ? this.pos : this.path[e * 3 - 1];
  }
  /**
  The (absolute) position directly after the wrapping node at the
  given level, or the original position when `depth` is `this.depth + 1`.
  */
  after(e) {
    if (e = this.resolveDepth(e), !e)
      throw new RangeError("There is no position after the top-level node");
    return e == this.depth + 1 ? this.pos : this.path[e * 3 - 1] + this.path[e * 3].nodeSize;
  }
  /**
  When this position points into a text node, this returns the
  distance between the position and the start of the text node.
  Will be zero for positions that point between nodes.
  */
  get textOffset() {
    return this.pos - this.path[this.path.length - 1];
  }
  /**
  Get the node directly after the position, if any. If the position
  points into a text node, only the part of that node after the
  position is returned.
  */
  get nodeAfter() {
    let e = this.parent, t = this.index(this.depth);
    if (t == e.childCount)
      return null;
    let n = this.pos - this.path[this.path.length - 1], i = e.child(t);
    return n ? e.child(t).cut(n) : i;
  }
  /**
  Get the node directly before the position, if any. If the
  position points into a text node, only the part of that node
  before the position is returned.
  */
  get nodeBefore() {
    let e = this.index(this.depth), t = this.pos - this.path[this.path.length - 1];
    return t ? this.parent.child(e).cut(0, t) : e == 0 ? null : this.parent.child(e - 1);
  }
  /**
  Get the position at the given index in the parent node at the
  given depth (which defaults to `this.depth`).
  */
  posAtIndex(e, t) {
    t = this.resolveDepth(t);
    let n = this.path[t * 3], i = t == 0 ? 0 : this.path[t * 3 - 1] + 1;
    for (let o = 0; o < e; o++)
      i += n.child(o).nodeSize;
    return i;
  }
  /**
  Get the marks at this position, factoring in the surrounding
  marks' [`inclusive`](https://prosemirror.net/docs/ref/#model.MarkSpec.inclusive) property. If the
  position is at the start of a non-empty node, the marks of the
  node after it (if any) are returned.
  */
  marks() {
    let e = this.parent, t = this.index();
    if (e.content.size == 0)
      return N.none;
    if (this.textOffset)
      return e.child(t).marks;
    let n = e.maybeChild(t - 1), i = e.maybeChild(t);
    if (!n) {
      let a = n;
      n = i, i = a;
    }
    let o = n.marks;
    for (var s = 0; s < o.length; s++)
      o[s].type.spec.inclusive === !1 && (!i || !o[s].isInSet(i.marks)) && (o = o[s--].removeFromSet(o));
    return o;
  }
  /**
  Get the marks after the current position, if any, except those
  that are non-inclusive and not present at position `$end`. This
  is mostly useful for getting the set of marks to preserve after a
  deletion. Will return `null` if this position is at the end of
  its parent node or its parent node isn't a textblock (in which
  case no marks should be preserved).
  */
  marksAcross(e) {
    let t = this.parent.maybeChild(this.index());
    if (!t || !t.isInline)
      return null;
    let n = t.marks, i = e.parent.maybeChild(e.index());
    for (var o = 0; o < n.length; o++)
      n[o].type.spec.inclusive === !1 && (!i || !n[o].isInSet(i.marks)) && (n = n[o--].removeFromSet(n));
    return n;
  }
  /**
  The depth up to which this position and the given (non-resolved)
  position share the same parent nodes.
  */
  sharedDepth(e) {
    for (let t = this.depth; t > 0; t--)
      if (this.start(t) <= e && this.end(t) >= e)
        return t;
    return 0;
  }
  /**
  Returns a range based on the place where this position and the
  given position diverge around block content. If both point into
  the same textblock, for example, a range around that textblock
  will be returned. If they point into different blocks, the range
  around those blocks in their shared ancestor is returned. You can
  pass in an optional predicate that will be called with a parent
  node to see if a range into that parent is acceptable.
  */
  blockRange(e = this, t) {
    if (e.pos < this.pos)
      return e.blockRange(this);
    for (let n = this.depth - (this.parent.inlineContent || this.pos == e.pos ? 1 : 0); n >= 0; n--)
      if (e.pos <= this.end(n) && (!t || t(this.node(n))))
        return new Ze(this, e, n);
    return null;
  }
  /**
  Query whether the given position shares the same parent node.
  */
  sameParent(e) {
    return this.pos - this.parentOffset == e.pos - e.parentOffset;
  }
  /**
  Return the greater of this and the given position.
  */
  max(e) {
    return e.pos > this.pos ? e : this;
  }
  /**
  Return the smaller of this and the given position.
  */
  min(e) {
    return e.pos < this.pos ? e : this;
  }
  /**
  @internal
  */
  toString() {
    let e = "";
    for (let t = 1; t <= this.depth; t++)
      e += (e ? "/" : "") + this.node(t).type.name + "_" + this.index(t - 1);
    return e + ":" + this.parentOffset;
  }
  /**
  @internal
  */
  static resolve(e, t) {
    if (!(t >= 0 && t <= e.content.size))
      throw new RangeError("Position " + t + " out of range");
    let n = [], i = 0, o = t;
    for (let s = e; ; ) {
      let { index: a, offset: l } = s.content.findIndex(o), c = o - l;
      if (n.push(s, a, i + l), !c || (s = s.child(a), s.isText))
        break;
      o = c - 1, i += l + 1;
    }
    return new Ie(t, n, o);
  }
  /**
  @internal
  */
  static resolveCached(e, t) {
    let n = nn.get(e);
    if (n)
      for (let o = 0; o < n.elts.length; o++) {
        let s = n.elts[o];
        if (s.pos == t)
          return s;
      }
    else
      nn.set(e, n = new Ji());
    let i = n.elts[n.i] = Ie.resolve(e, t);
    return n.i = (n.i + 1) % Vi, i;
  }
}
class Ji {
  constructor() {
    this.elts = [], this.i = 0;
  }
}
const Vi = 12, nn = /* @__PURE__ */ new WeakMap();
class Ze {
  /**
  Construct a node range. `$from` and `$to` should point into the
  same node until at least the given `depth`, since a node range
  denotes an adjacent set of nodes in a single parent node.
  */
  constructor(e, t, n) {
    this.$from = e, this.$to = t, this.depth = n;
  }
  /**
  The position at the start of the range.
  */
  get start() {
    return this.$from.before(this.depth + 1);
  }
  /**
  The position at the end of the range.
  */
  get end() {
    return this.$to.after(this.depth + 1);
  }
  /**
  The parent node that the range points into.
  */
  get parent() {
    return this.$from.node(this.depth);
  }
  /**
  The start index of the range in the parent node.
  */
  get startIndex() {
    return this.$from.index(this.depth);
  }
  /**
  The end index of the range in the parent node.
  */
  get endIndex() {
    return this.$to.indexAfter(this.depth);
  }
}
const Wi = /* @__PURE__ */ Object.create(null);
let le = class Ct {
  /**
  @internal
  */
  constructor(e, t, n, i = N.none) {
    this.type = e, this.attrs = t, this.marks = i, this.content = n || x.empty;
  }
  /**
  The array of this node's child nodes.
  */
  get children() {
    return this.content.content;
  }
  /**
  The size of this node, as defined by the integer-based [indexing
  scheme](https://prosemirror.net/docs/guide/#doc.indexing). For text nodes, this is the
  amount of characters. For other leaf nodes, it is one. For
  non-leaf nodes, it is the size of the content plus two (the
  start and end token).
  */
  get nodeSize() {
    return this.isLeaf ? 1 : 2 + this.content.size;
  }
  /**
  The number of children that the node has.
  */
  get childCount() {
    return this.content.childCount;
  }
  /**
  Get the child node at the given index. Raises an error when the
  index is out of range.
  */
  child(e) {
    return this.content.child(e);
  }
  /**
  Get the child node at the given index, if it exists.
  */
  maybeChild(e) {
    return this.content.maybeChild(e);
  }
  /**
  Call `f` for every child node, passing the node, its offset
  into this parent node, and its index.
  */
  forEach(e) {
    this.content.forEach(e);
  }
  /**
  Invoke a callback for all descendant nodes recursively between
  the given two positions that are relative to start of this
  node's content. The callback is invoked with the node, its
  position relative to the original node (method receiver),
  its parent node, and its child index. When the callback returns
  false for a given node, that node's children will not be
  recursed over. The last parameter can be used to specify a
  starting position to count from.
  */
  nodesBetween(e, t, n, i = 0) {
    this.content.nodesBetween(e, t, n, i, this);
  }
  /**
  Call the given callback for every descendant node. Doesn't
  descend into a node when the callback returns `false`.
  */
  descendants(e) {
    this.nodesBetween(0, this.content.size, e);
  }
  /**
  Concatenates all the text nodes found in this fragment and its
  children.
  */
  get textContent() {
    return this.isLeaf && this.type.spec.leafText ? this.type.spec.leafText(this) : this.textBetween(0, this.content.size, "");
  }
  /**
  Get all text between positions `from` and `to`. When
  `blockSeparator` is given, it will be inserted to separate text
  from different block nodes. If `leafText` is given, it'll be
  inserted for every non-text leaf node encountered, otherwise
  [`leafText`](https://prosemirror.net/docs/ref/#model.NodeSpec.leafText) will be used.
  */
  textBetween(e, t, n, i) {
    return this.content.textBetween(e, t, n, i);
  }
  /**
  Returns this node's first child, or `null` if there are no
  children.
  */
  get firstChild() {
    return this.content.firstChild;
  }
  /**
  Returns this node's last child, or `null` if there are no
  children.
  */
  get lastChild() {
    return this.content.lastChild;
  }
  /**
  Test whether two nodes represent the same piece of document.
  */
  eq(e) {
    return this == e || this.sameMarkup(e) && this.content.eq(e.content);
  }
  /**
  Compare the markup (type, attributes, and marks) of this node to
  those of another. Returns `true` if both have the same markup.
  */
  sameMarkup(e) {
    return this.hasMarkup(e.type, e.attrs, e.marks);
  }
  /**
  Check whether this node's markup correspond to the given type,
  attributes, and marks.
  */
  hasMarkup(e, t, n) {
    return this.type == e && Ye(this.attrs, t || e.defaultAttrs || Wi) && N.sameSet(this.marks, n || N.none);
  }
  /**
  Create a new node with the same markup as this node, containing
  the given content (or empty, if no content is given).
  */
  copy(e = null) {
    return e == this.content ? this : new Ct(this.type, this.attrs, e, this.marks);
  }
  /**
  Create a copy of this node, with the given set of marks instead
  of the node's own marks.
  */
  mark(e) {
    return e == this.marks ? this : new Ct(this.type, this.attrs, this.content, e);
  }
  /**
  Create a copy of this node with only the content between the
  given positions. If `to` is not given, it defaults to the end of
  the node.
  */
  cut(e, t = this.content.size) {
    return e == 0 && t == this.content.size ? this : this.copy(this.content.cut(e, t));
  }
  /**
  Cut out the part of the document between the given positions, and
  return it as a `Slice` object.
  */
  slice(e, t = this.content.size, n = !1) {
    if (e == t)
      return w.empty;
    let i = this.resolve(e), o = this.resolve(t), s = n ? 0 : i.sharedDepth(t), a = i.start(s), c = i.node(s).content.cut(i.pos - a, o.pos - a);
    return new w(c, i.depth - s, o.depth - s);
  }
  /**
  Replace the part of the document between the given positions with
  the given slice. The slice must 'fit', meaning its open sides
  must be able to connect to the surrounding content, and its
  content nodes must be valid children for the node they are placed
  into. If any of this is violated, an error of type
  [`ReplaceError`](https://prosemirror.net/docs/ref/#model.ReplaceError) is thrown.
  */
  replace(e, t, n) {
    return Hi(this.resolve(e), this.resolve(t), n);
  }
  /**
  Find the node directly after the given position.
  */
  nodeAt(e) {
    for (let t = this; ; ) {
      let { index: n, offset: i } = t.content.findIndex(e);
      if (t = t.maybeChild(n), !t)
        return null;
      if (i == e || t.isText)
        return t;
      e -= i + 1;
    }
  }
  /**
  Find the (direct) child node after the given offset, if any,
  and return it along with its index and offset relative to this
  node.
  */
  childAfter(e) {
    let { index: t, offset: n } = this.content.findIndex(e);
    return { node: this.content.maybeChild(t), index: t, offset: n };
  }
  /**
  Find the (direct) child node before the given offset, if any,
  and return it along with its index and offset relative to this
  node.
  */
  childBefore(e) {
    if (e == 0)
      return { node: null, index: 0, offset: 0 };
    let { index: t, offset: n } = this.content.findIndex(e);
    if (n < e)
      return { node: this.content.child(t), index: t, offset: n };
    let i = this.content.child(t - 1);
    return { node: i, index: t - 1, offset: n - i.nodeSize };
  }
  /**
  Resolve the given position in the document, returning an
  [object](https://prosemirror.net/docs/ref/#model.ResolvedPos) with information about its context.
  */
  resolve(e) {
    return Ie.resolveCached(this, e);
  }
  /**
  @internal
  */
  resolveNoCache(e) {
    return Ie.resolve(this, e);
  }
  /**
  Test whether a given mark or mark type occurs in this document
  between the two given positions.
  */
  rangeHasMark(e, t, n) {
    let i = !1;
    return t > e && this.nodesBetween(e, t, (o) => (n.isInSet(o.marks) && (i = !0), !i)), i;
  }
  /**
  True when this is a block (non-inline node)
  */
  get isBlock() {
    return this.type.isBlock;
  }
  /**
  True when this is a textblock node, a block node with inline
  content.
  */
  get isTextblock() {
    return this.type.isTextblock;
  }
  /**
  True when this node allows inline content.
  */
  get inlineContent() {
    return this.type.inlineContent;
  }
  /**
  True when this is an inline node (a text node or a node that can
  appear among text).
  */
  get isInline() {
    return this.type.isInline;
  }
  /**
  True when this is a text node.
  */
  get isText() {
    return this.type.isText;
  }
  /**
  True when this is a leaf node.
  */
  get isLeaf() {
    return this.type.isLeaf;
  }
  /**
  True when this is an atom, i.e. when it does not have directly
  editable content. This is usually the same as `isLeaf`, but can
  be configured with the [`atom` property](https://prosemirror.net/docs/ref/#model.NodeSpec.atom)
  on a node's spec (typically used when the node is displayed as
  an uneditable [node view](https://prosemirror.net/docs/ref/#view.NodeView)).
  */
  get isAtom() {
    return this.type.isAtom;
  }
  /**
  Return a string representation of this node for debugging
  purposes.
  */
  toString() {
    if (this.type.spec.toDebugString)
      return this.type.spec.toDebugString(this);
    let e = this.type.name;
    return this.content.size && (e += "(" + this.content.toStringInner() + ")"), Wn(this.marks, e);
  }
  /**
  Get the content match in this node at the given index.
  */
  contentMatchAt(e) {
    let t = this.type.contentMatch.matchFragment(this.content, 0, e);
    if (!t)
      throw new Error("Called contentMatchAt on a node with invalid content");
    return t;
  }
  /**
  Test whether replacing the range between `from` and `to` (by
  child index) with the given replacement fragment (which defaults
  to the empty fragment) would leave the node's content valid. You
  can optionally pass `start` and `end` indices into the
  replacement fragment.
  */
  canReplace(e, t, n = x.empty, i = 0, o = n.childCount) {
    let s = this.contentMatchAt(e).matchFragment(n, i, o), a = s && s.matchFragment(this.content, t);
    if (!a || !a.validEnd)
      return !1;
    for (let l = i; l < o; l++)
      if (!this.type.allowsMarks(n.child(l).marks))
        return !1;
    return !0;
  }
  /**
  Test whether replacing the range `from` to `to` (by index) with
  a node of the given type would leave the node's content valid.
  */
  canReplaceWith(e, t, n, i) {
    if (i && !this.type.allowsMarks(i))
      return !1;
    let o = this.contentMatchAt(e).matchType(n), s = o && o.matchFragment(this.content, t);
    return s ? s.validEnd : !1;
  }
  /**
  Test whether the given node's content could be appended to this
  node. If that node is empty, this will only return true if there
  is at least one node type that can appear in both nodes (to avoid
  merging completely incompatible nodes).
  */
  canAppend(e) {
    return e.content.size ? this.canReplace(this.childCount, this.childCount, e.content) : this.type.compatibleContent(e.type);
  }
  /**
  Check whether this node and its descendants conform to the
  schema, and raise an exception when they do not.
  */
  check() {
    this.type.checkContent(this.content), this.type.checkAttrs(this.attrs);
    let e = N.none;
    for (let t = 0; t < this.marks.length; t++) {
      let n = this.marks[t];
      n.type.checkAttrs(n.attrs), e = n.addToSet(e);
    }
    if (!N.sameSet(e, this.marks))
      throw new RangeError(`Invalid collection of marks for node ${this.type.name}: ${this.marks.map((t) => t.type.name)}`);
    this.content.forEach((t) => t.check());
  }
  /**
  Return a JSON-serializeable representation of this node.
  */
  toJSON() {
    let e = { type: this.type.name };
    for (let t in this.attrs) {
      e.attrs = this.attrs;
      break;
    }
    return this.content.size && (e.content = this.content.toJSON()), this.marks.length && (e.marks = this.marks.map((t) => t.toJSON())), e;
  }
  /**
  Deserialize a node from its JSON representation.
  */
  static fromJSON(e, t) {
    if (!t)
      throw new RangeError("Invalid input for Node.fromJSON");
    let n;
    if (t.marks) {
      if (!Array.isArray(t.marks))
        throw new RangeError("Invalid mark data for Node.fromJSON");
      n = t.marks.map(e.markFromJSON);
    }
    if (t.type == "text") {
      if (typeof t.text != "string")
        throw new RangeError("Invalid text node in JSON");
      return e.text(t.text, n);
    }
    let i = x.fromJSON(e, t.content), o = e.nodeType(t.type).create(t.attrs, i, n);
    return o.type.checkAttrs(o.attrs), o;
  }
};
le.prototype.text = void 0;
class et extends le {
  /**
  @internal
  */
  constructor(e, t, n, i) {
    if (super(e, t, null, i), !n)
      throw new RangeError("Empty text nodes are not allowed");
    this.text = n;
  }
  toString() {
    return this.type.spec.toDebugString ? this.type.spec.toDebugString(this) : Wn(this.marks, JSON.stringify(this.text));
  }
  get textContent() {
    return this.text;
  }
  textBetween(e, t) {
    return this.text.slice(e, t);
  }
  get nodeSize() {
    return this.text.length;
  }
  mark(e) {
    return e == this.marks ? this : new et(this.type, this.attrs, this.text, e);
  }
  withText(e) {
    return e == this.text ? this : new et(this.type, this.attrs, e, this.marks);
  }
  cut(e = 0, t = this.text.length) {
    return e == 0 && t == this.text.length ? this : this.withText(this.text.slice(e, t));
  }
  eq(e) {
    return this.sameMarkup(e) && this.text == e.text;
  }
  toJSON() {
    let e = super.toJSON();
    return e.text = this.text, e;
  }
}
function Wn(r, e) {
  for (let t = r.length - 1; t >= 0; t--)
    e = r[t].type.name + "(" + e + ")";
  return e;
}
class ce {
  /**
  @internal
  */
  constructor(e) {
    this.validEnd = e, this.next = [], this.wrapCache = [];
  }
  /**
  @internal
  */
  static parse(e, t) {
    let n = new qi(e, t);
    if (n.next == null)
      return ce.empty;
    let i = qn(n);
    n.next && n.err("Unexpected trailing text");
    let o = eo(Zi(i));
    return to(o, n), o;
  }
  /**
  Match a node type, returning a match after that node if
  successful.
  */
  matchType(e) {
    for (let t = 0; t < this.next.length; t++)
      if (this.next[t].type == e)
        return this.next[t].next;
    return null;
  }
  /**
  Try to match a fragment. Returns the resulting match when
  successful.
  */
  matchFragment(e, t = 0, n = e.childCount) {
    let i = this;
    for (let o = t; i && o < n; o++)
      i = i.matchType(e.child(o).type);
    return i;
  }
  /**
  @internal
  */
  get inlineContent() {
    return this.next.length != 0 && this.next[0].type.isInline;
  }
  /**
  Get the first matching node type at this match position that can
  be generated.
  */
  get defaultType() {
    for (let e = 0; e < this.next.length; e++) {
      let { type: t } = this.next[e];
      if (!(t.isText || t.hasRequiredAttrs()))
        return t;
    }
    return null;
  }
  /**
  @internal
  */
  compatible(e) {
    for (let t = 0; t < this.next.length; t++)
      for (let n = 0; n < e.next.length; n++)
        if (this.next[t].type == e.next[n].type)
          return !0;
    return !1;
  }
  /**
  Try to match the given fragment, and if that fails, see if it can
  be made to match by inserting nodes in front of it. When
  successful, return a fragment of inserted nodes (which may be
  empty if nothing had to be inserted). When `toEnd` is true, only
  return a fragment if the resulting match goes to the end of the
  content expression.
  */
  fillBefore(e, t = !1, n = 0) {
    let i = [this];
    function o(s, a) {
      let l = s.matchFragment(e, n);
      if (l && (!t || l.validEnd))
        return x.from(a.map((c) => c.createAndFill()));
      for (let c = 0; c < s.next.length; c++) {
        let { type: d, next: p } = s.next[c];
        if (!(d.isText || d.hasRequiredAttrs()) && i.indexOf(p) == -1) {
          i.push(p);
          let f = o(p, a.concat(d));
          if (f)
            return f;
        }
      }
      return null;
    }
    return o(this, []);
  }
  /**
  Find a set of wrapping node types that would allow a node of the
  given type to appear at this position. The result may be empty
  (when it fits directly) and will be null when no such wrapping
  exists.
  */
  findWrapping(e) {
    for (let n = 0; n < this.wrapCache.length; n += 2)
      if (this.wrapCache[n] == e)
        return this.wrapCache[n + 1];
    let t = this.computeWrapping(e);
    return this.wrapCache.push(e, t), t;
  }
  /**
  @internal
  */
  computeWrapping(e) {
    let t = /* @__PURE__ */ Object.create(null), n = [{ match: this, type: null, via: null }];
    for (; n.length; ) {
      let i = n.shift(), o = i.match;
      if (o.matchType(e)) {
        let s = [];
        for (let a = i; a.type; a = a.via)
          s.push(a.type);
        return s.reverse();
      }
      for (let s = 0; s < o.next.length; s++) {
        let { type: a, next: l } = o.next[s];
        !a.isLeaf && !a.hasRequiredAttrs() && !(a.name in t) && (!i.type || l.validEnd) && (n.push({ match: a.contentMatch, type: a, via: i }), t[a.name] = !0);
      }
    }
    return null;
  }
  /**
  The number of outgoing edges this node has in the finite
  automaton that describes the content expression.
  */
  get edgeCount() {
    return this.next.length;
  }
  /**
  Get the _n_​th outgoing edge from this node in the finite
  automaton that describes the content expression.
  */
  edge(e) {
    if (e >= this.next.length)
      throw new RangeError(`There's no ${e}th edge in this content match`);
    return this.next[e];
  }
  /**
  @internal
  */
  toString() {
    let e = [];
    function t(n) {
      e.push(n);
      for (let i = 0; i < n.next.length; i++)
        e.indexOf(n.next[i].next) == -1 && t(n.next[i].next);
    }
    return t(this), e.map((n, i) => {
      let o = i + (n.validEnd ? "*" : " ") + " ";
      for (let s = 0; s < n.next.length; s++)
        o += (s ? ", " : "") + n.next[s].type.name + "->" + e.indexOf(n.next[s].next);
      return o;
    }).join(`
`);
  }
}
ce.empty = new ce(!0);
class qi {
  constructor(e, t) {
    this.string = e, this.nodeTypes = t, this.inline = null, this.pos = 0, this.tokens = e.split(/\s*(?=\b|\W|$)/), this.tokens[this.tokens.length - 1] == "" && this.tokens.pop(), this.tokens[0] == "" && this.tokens.shift();
  }
  get next() {
    return this.tokens[this.pos];
  }
  eat(e) {
    return this.next == e && (this.pos++ || !0);
  }
  err(e) {
    throw new SyntaxError(e + " (in content expression '" + this.string + "')");
  }
}
function qn(r) {
  let e = [];
  do
    e.push(Ki(r));
  while (r.eat("|"));
  return e.length == 1 ? e[0] : { type: "choice", exprs: e };
}
function Ki(r) {
  let e = [];
  do
    e.push(Gi(r));
  while (r.next && r.next != ")" && r.next != "|");
  return e.length == 1 ? e[0] : { type: "seq", exprs: e };
}
function Gi(r) {
  let e = Qi(r);
  for (; ; )
    if (r.eat("+"))
      e = { type: "plus", expr: e };
    else if (r.eat("*"))
      e = { type: "star", expr: e };
    else if (r.eat("?"))
      e = { type: "opt", expr: e };
    else if (r.eat("{"))
      e = Yi(r, e);
    else
      break;
  return e;
}
function rn(r) {
  /\D/.test(r.next) && r.err("Expected number, got '" + r.next + "'");
  let e = Number(r.next);
  return r.pos++, e;
}
function Yi(r, e) {
  let t = rn(r), n = t;
  return r.eat(",") && (r.next != "}" ? n = rn(r) : n = -1), r.eat("}") || r.err("Unclosed braced range"), { type: "range", min: t, max: n, expr: e };
}
function Xi(r, e) {
  let t = r.nodeTypes, n = t[e];
  if (n)
    return [n];
  let i = [];
  for (let o in t) {
    let s = t[o];
    s.isInGroup(e) && i.push(s);
  }
  return i.length == 0 && r.err("No node type or group '" + e + "' found"), i;
}
function Qi(r) {
  if (r.eat("(")) {
    let e = qn(r);
    return r.eat(")") || r.err("Missing closing paren"), e;
  } else if (/\W/.test(r.next))
    r.err("Unexpected token '" + r.next + "'");
  else {
    let e = Xi(r, r.next).map((t) => (r.inline == null ? r.inline = t.isInline : r.inline != t.isInline && r.err("Mixing inline and block content"), { type: "name", value: t }));
    return r.pos++, e.length == 1 ? e[0] : { type: "choice", exprs: e };
  }
}
function Zi(r) {
  let e = [[]];
  return i(o(r, 0), t()), e;
  function t() {
    return e.push([]) - 1;
  }
  function n(s, a, l) {
    let c = { term: l, to: a };
    return e[s].push(c), c;
  }
  function i(s, a) {
    s.forEach((l) => l.to = a);
  }
  function o(s, a) {
    if (s.type == "choice")
      return s.exprs.reduce((l, c) => l.concat(o(c, a)), []);
    if (s.type == "seq")
      for (let l = 0; ; l++) {
        let c = o(s.exprs[l], a);
        if (l == s.exprs.length - 1)
          return c;
        i(c, a = t());
      }
    else if (s.type == "star") {
      let l = t();
      return n(a, l), i(o(s.expr, l), l), [n(l)];
    } else if (s.type == "plus") {
      let l = t();
      return i(o(s.expr, a), l), i(o(s.expr, l), l), [n(l)];
    } else {
      if (s.type == "opt")
        return [n(a)].concat(o(s.expr, a));
      if (s.type == "range") {
        let l = a;
        for (let c = 0; c < s.min; c++) {
          let d = t();
          i(o(s.expr, l), d), l = d;
        }
        if (s.max == -1)
          i(o(s.expr, l), l);
        else
          for (let c = s.min; c < s.max; c++) {
            let d = t();
            n(l, d), i(o(s.expr, l), d), l = d;
          }
        return [n(l)];
      } else {
        if (s.type == "name")
          return [n(a, void 0, s.value)];
        throw new Error("Unknown expr type");
      }
    }
  }
}
function Kn(r, e) {
  return e - r;
}
function on(r, e) {
  let t = [];
  return n(e), t.sort(Kn);
  function n(i) {
    let o = r[i];
    if (o.length == 1 && !o[0].term)
      return n(o[0].to);
    t.push(i);
    for (let s = 0; s < o.length; s++) {
      let { term: a, to: l } = o[s];
      !a && t.indexOf(l) == -1 && n(l);
    }
  }
}
function eo(r) {
  let e = /* @__PURE__ */ Object.create(null);
  return t(on(r, 0));
  function t(n) {
    let i = [];
    n.forEach((s) => {
      r[s].forEach(({ term: a, to: l }) => {
        if (!a)
          return;
        let c;
        for (let d = 0; d < i.length; d++)
          i[d][0] == a && (c = i[d][1]);
        on(r, l).forEach((d) => {
          c || i.push([a, c = []]), c.indexOf(d) == -1 && c.push(d);
        });
      });
    });
    let o = e[n.join(",")] = new ce(n.indexOf(r.length - 1) > -1);
    for (let s = 0; s < i.length; s++) {
      let a = i[s][1].sort(Kn);
      o.next.push({ type: i[s][0], next: e[a.join(",")] || t(a) });
    }
    return o;
  }
}
function to(r, e) {
  for (let t = 0, n = [r]; t < n.length; t++) {
    let i = n[t], o = !i.validEnd, s = [];
    for (let a = 0; a < i.next.length; a++) {
      let { type: l, next: c } = i.next[a];
      s.push(l.name), o && !(l.isText || l.hasRequiredAttrs()) && (o = !1), n.indexOf(c) == -1 && n.push(c);
    }
    o && e.err("Only non-generatable nodes (" + s.join(", ") + ") in a required position (see https://prosemirror.net/docs/guide/#generatable)");
  }
}
function Gn(r) {
  let e = /* @__PURE__ */ Object.create(null);
  for (let t in r) {
    let n = r[t];
    if (!n.hasDefault)
      return null;
    e[t] = n.default;
  }
  return e;
}
function Yn(r, e) {
  let t = /* @__PURE__ */ Object.create(null);
  for (let n in r) {
    let i = e && e[n];
    if (i === void 0) {
      let o = r[n];
      if (o.hasDefault)
        i = o.default;
      else
        throw new RangeError("No value supplied for attribute " + n);
    }
    t[n] = i;
  }
  return t;
}
function Xn(r, e, t, n) {
  for (let i in e)
    if (!(i in r))
      throw new RangeError(`Unsupported attribute ${i} for ${t} of type ${i}`);
  for (let i in r) {
    let o = r[i];
    o.validate && o.validate(e[i]);
  }
}
function Qn(r, e) {
  let t = /* @__PURE__ */ Object.create(null);
  if (e)
    for (let n in e)
      t[n] = new ro(r, n, e[n]);
  return t;
}
class tt {
  /**
  @internal
  */
  constructor(e, t, n) {
    this.name = e, this.schema = t, this.spec = n, this.markSet = null, this.groups = n.group ? n.group.split(" ") : [], this.attrs = Qn(e, n.attrs), this.defaultAttrs = Gn(this.attrs), this.contentMatch = null, this.inlineContent = null, this.isBlock = !(n.inline || e == "text"), this.isText = e == "text";
  }
  /**
  True if this is an inline type.
  */
  get isInline() {
    return !this.isBlock;
  }
  /**
  True if this is a textblock type, a block that contains inline
  content.
  */
  get isTextblock() {
    return this.isBlock && this.inlineContent;
  }
  /**
  True for node types that allow no content.
  */
  get isLeaf() {
    return this.contentMatch == ce.empty;
  }
  /**
  True when this node is an atom, i.e. when it does not have
  directly editable content.
  */
  get isAtom() {
    return this.isLeaf || !!this.spec.atom;
  }
  /**
  Return true when this node type is part of the given
  [group](https://prosemirror.net/docs/ref/#model.NodeSpec.group).
  */
  isInGroup(e) {
    return this.groups.indexOf(e) > -1;
  }
  /**
  The node type's [whitespace](https://prosemirror.net/docs/ref/#model.NodeSpec.whitespace) option.
  */
  get whitespace() {
    return this.spec.whitespace || (this.spec.code ? "pre" : "normal");
  }
  /**
  Tells you whether this node type has any required attributes.
  */
  hasRequiredAttrs() {
    for (let e in this.attrs)
      if (this.attrs[e].isRequired)
        return !0;
    return !1;
  }
  /**
  Indicates whether this node allows some of the same content as
  the given node type.
  */
  compatibleContent(e) {
    return this == e || this.contentMatch.compatible(e.contentMatch);
  }
  /**
  @internal
  */
  computeAttrs(e) {
    return !e && this.defaultAttrs ? this.defaultAttrs : Yn(this.attrs, e);
  }
  /**
  Create a `Node` of this type. The given attributes are
  checked and defaulted (you can pass `null` to use the type's
  defaults entirely, if no required attributes exist). `content`
  may be a `Fragment`, a node, an array of nodes, or
  `null`. Similarly `marks` may be `null` to default to the empty
  set of marks.
  */
  create(e = null, t, n) {
    if (this.isText)
      throw new Error("NodeType.create can't construct text nodes");
    return new le(this, this.computeAttrs(e), x.from(t), N.setFrom(n));
  }
  /**
  Like [`create`](https://prosemirror.net/docs/ref/#model.NodeType.create), but check the given content
  against the node type's content restrictions, and throw an error
  if it doesn't match.
  */
  createChecked(e = null, t, n) {
    return t = x.from(t), this.checkContent(t), new le(this, this.computeAttrs(e), t, N.setFrom(n));
  }
  /**
  Like [`create`](https://prosemirror.net/docs/ref/#model.NodeType.create), but see if it is
  necessary to add nodes to the start or end of the given fragment
  to make it fit the node. If no fitting wrapping can be found,
  return null. Note that, due to the fact that required nodes can
  always be created, this will always succeed if you pass null or
  `Fragment.empty` as content.
  */
  createAndFill(e = null, t, n) {
    if (e = this.computeAttrs(e), t = x.from(t), t.size) {
      let s = this.contentMatch.fillBefore(t);
      if (!s)
        return null;
      t = s.append(t);
    }
    let i = this.contentMatch.matchFragment(t), o = i && i.fillBefore(x.empty, !0);
    return o ? new le(this, e, t.append(o), N.setFrom(n)) : null;
  }
  /**
  Returns true if the given fragment is valid content for this node
  type.
  */
  validContent(e) {
    let t = this.contentMatch.matchFragment(e);
    if (!t || !t.validEnd)
      return !1;
    for (let n = 0; n < e.childCount; n++)
      if (!this.allowsMarks(e.child(n).marks))
        return !1;
    return !0;
  }
  /**
  Throws a RangeError if the given fragment is not valid content for this
  node type.
  @internal
  */
  checkContent(e) {
    if (!this.validContent(e))
      throw new RangeError(`Invalid content for node ${this.name}: ${e.toString().slice(0, 50)}`);
  }
  /**
  @internal
  */
  checkAttrs(e) {
    Xn(this.attrs, e, "node", this.name);
  }
  /**
  Check whether the given mark type is allowed in this node.
  */
  allowsMarkType(e) {
    return this.markSet == null || this.markSet.indexOf(e) > -1;
  }
  /**
  Test whether the given set of marks are allowed in this node.
  */
  allowsMarks(e) {
    if (this.markSet == null)
      return !0;
    for (let t = 0; t < e.length; t++)
      if (!this.allowsMarkType(e[t].type))
        return !1;
    return !0;
  }
  /**
  Removes the marks that are not allowed in this node from the given set.
  */
  allowedMarks(e) {
    if (this.markSet == null)
      return e;
    let t;
    for (let n = 0; n < e.length; n++)
      this.allowsMarkType(e[n].type) ? t && t.push(e[n]) : t || (t = e.slice(0, n));
    return t ? t.length ? t : N.none : e;
  }
  /**
  @internal
  */
  static compile(e, t) {
    let n = /* @__PURE__ */ Object.create(null);
    e.forEach((o, s) => n[o] = new tt(o, t, s));
    let i = t.spec.topNode || "doc";
    if (!n[i])
      throw new RangeError("Schema is missing its top node type ('" + i + "')");
    if (!n.text)
      throw new RangeError("Every schema needs a 'text' type");
    for (let o in n.text.attrs)
      throw new RangeError("The text node type should not have attributes");
    return n;
  }
}
function no(r, e, t) {
  let n = t.split("|");
  return (i) => {
    let o = i === null ? "null" : typeof i;
    if (n.indexOf(o) < 0)
      throw new RangeError(`Expected value of type ${n} for attribute ${e} on type ${r}, got ${o}`);
  };
}
class ro {
  constructor(e, t, n) {
    this.hasDefault = Object.prototype.hasOwnProperty.call(n, "default"), this.default = n.default, this.validate = typeof n.validate == "string" ? no(e, t, n.validate) : n.validate;
  }
  get isRequired() {
    return !this.hasDefault;
  }
}
class Ot {
  /**
  @internal
  */
  constructor(e, t, n, i) {
    this.name = e, this.rank = t, this.schema = n, this.spec = i, this.attrs = Qn(e, i.attrs), this.excluded = null;
    let o = Gn(this.attrs);
    this.instance = o ? new N(this, o) : null;
  }
  /**
  Create a mark of this type. `attrs` may be `null` or an object
  containing only some of the mark's attributes. The others, if
  they have defaults, will be added.
  */
  create(e = null) {
    return !e && this.instance ? this.instance : new N(this, Yn(this.attrs, e));
  }
  /**
  @internal
  */
  static compile(e, t) {
    let n = /* @__PURE__ */ Object.create(null), i = 0;
    return e.forEach((o, s) => n[o] = new Ot(o, i++, t, s)), n;
  }
  /**
  When there is a mark of this type in the given set, a new set
  without it is returned. Otherwise, the input set is returned.
  */
  removeFromSet(e) {
    for (var t = 0; t < e.length; t++)
      e[t].type == this && (e = e.slice(0, t).concat(e.slice(t + 1)), t--);
    return e;
  }
  /**
  Tests whether there is a mark of this type in the given set.
  */
  isInSet(e) {
    for (let t = 0; t < e.length; t++)
      if (e[t].type == this)
        return e[t];
  }
  /**
  @internal
  */
  checkAttrs(e) {
    Xn(this.attrs, e, "mark", this.name);
  }
  /**
  Queries whether a given mark type is
  [excluded](https://prosemirror.net/docs/ref/#model.MarkSpec.excludes) by this one.
  */
  excludes(e) {
    return this.excluded.indexOf(e) > -1;
  }
}
class io {
  /**
  Construct a schema from a schema [specification](https://prosemirror.net/docs/ref/#model.SchemaSpec).
  */
  constructor(e) {
    this.linebreakReplacement = null, this.cached = /* @__PURE__ */ Object.create(null);
    let t = this.spec = {};
    for (let i in e)
      t[i] = e[i];
    t.nodes = I.from(e.nodes), t.marks = I.from(e.marks || {}), this.nodes = tt.compile(this.spec.nodes, this), this.marks = Ot.compile(this.spec.marks, this);
    let n = /* @__PURE__ */ Object.create(null);
    for (let i in this.nodes) {
      if (i in this.marks)
        throw new RangeError(i + " can not be both a node and a mark");
      let o = this.nodes[i], s = o.spec.content || "", a = o.spec.marks;
      if (o.contentMatch = n[s] || (n[s] = ce.parse(s, this.nodes)), o.inlineContent = o.contentMatch.inlineContent, o.spec.linebreakReplacement) {
        if (this.linebreakReplacement)
          throw new RangeError("Multiple linebreak nodes defined");
        if (!o.isInline || !o.isLeaf)
          throw new RangeError("Linebreak replacement nodes must be inline leaf nodes");
        this.linebreakReplacement = o;
      }
      o.markSet = a == "_" ? null : a ? sn(this, a.split(" ")) : a == "" || !o.inlineContent ? [] : null;
    }
    for (let i in this.marks) {
      let o = this.marks[i], s = o.spec.excludes;
      o.excluded = s == null ? [o] : s == "" ? [] : sn(this, s.split(" "));
    }
    this.nodeFromJSON = (i) => le.fromJSON(this, i), this.markFromJSON = (i) => N.fromJSON(this, i), this.topNodeType = this.nodes[this.spec.topNode || "doc"], this.cached.wrappings = /* @__PURE__ */ Object.create(null);
  }
  /**
  Create a node in this schema. The `type` may be a string or a
  `NodeType` instance. Attributes will be extended with defaults,
  `content` may be a `Fragment`, `null`, a `Node`, or an array of
  nodes.
  */
  node(e, t = null, n, i) {
    if (typeof e == "string")
      e = this.nodeType(e);
    else if (e instanceof tt) {
      if (e.schema != this)
        throw new RangeError("Node type from different schema used (" + e.name + ")");
    } else throw new RangeError("Invalid node type: " + e);
    return e.createChecked(t, n, i);
  }
  /**
  Create a text node in the schema. Empty text nodes are not
  allowed.
  */
  text(e, t) {
    let n = this.nodes.text;
    return new et(n, n.defaultAttrs, e, N.setFrom(t));
  }
  /**
  Create a mark with the given type and attributes.
  */
  mark(e, t) {
    return typeof e == "string" && (e = this.marks[e]), e.create(t);
  }
  /**
  @internal
  */
  nodeType(e) {
    let t = this.nodes[e];
    if (!t)
      throw new RangeError("Unknown node type: " + e);
    return t;
  }
}
function sn(r, e) {
  let t = [];
  for (let n = 0; n < e.length; n++) {
    let i = e[n], o = r.marks[i], s = o;
    if (o)
      t.push(o);
    else
      for (let a in r.marks) {
        let l = r.marks[a];
        (i == "_" || l.spec.group && l.spec.group.split(" ").indexOf(i) > -1) && t.push(s = l);
      }
    if (!s)
      throw new SyntaxError("Unknown mark type: '" + e[n] + "'");
  }
  return t;
}
function oo(r) {
  return r.tag != null;
}
function so(r) {
  return r.style != null;
}
class me {
  /**
  Create a parser that targets the given schema, using the given
  parsing rules.
  */
  constructor(e, t) {
    this.schema = e, this.rules = t, this.tags = [], this.styles = [];
    let n = this.matchedStyles = [];
    t.forEach((i) => {
      if (oo(i))
        this.tags.push(i);
      else if (so(i)) {
        let o = /[^=]*/.exec(i.style)[0];
        n.indexOf(o) < 0 && n.push(o), this.styles.push(i);
      }
    }), this.normalizeLists = !this.tags.some((i) => {
      if (!/^(ul|ol)\b/.test(i.tag) || !i.node)
        return !1;
      let o = e.nodes[i.node];
      return o.contentMatch.matchType(o);
    });
  }
  /**
  Parse a document from the content of a DOM node.
  */
  parse(e, t = {}) {
    let n = new ln(this, t, !1);
    return n.addAll(e, N.none, t.from, t.to), n.finish();
  }
  /**
  Parses the content of the given DOM node, like
  [`parse`](https://prosemirror.net/docs/ref/#model.DOMParser.parse), and takes the same set of
  options. But unlike that method, which produces a whole node,
  this one returns a slice that is open at the sides, meaning that
  the schema constraints aren't applied to the start of nodes to
  the left of the input and the end of nodes at the end.
  */
  parseSlice(e, t = {}) {
    let n = new ln(this, t, !0);
    return n.addAll(e, N.none, t.from, t.to), w.maxOpen(n.finish());
  }
  /**
  @internal
  */
  matchTag(e, t, n) {
    for (let i = n ? this.tags.indexOf(n) + 1 : 0; i < this.tags.length; i++) {
      let o = this.tags[i];
      if (co(e, o.tag) && (o.namespace === void 0 || e.namespaceURI == o.namespace) && (!o.context || t.matchesContext(o.context))) {
        if (o.getAttrs) {
          let s = o.getAttrs(e);
          if (s === !1)
            continue;
          o.attrs = s || void 0;
        }
        return o;
      }
    }
  }
  /**
  @internal
  */
  matchStyle(e, t, n, i) {
    for (let o = i ? this.styles.indexOf(i) + 1 : 0; o < this.styles.length; o++) {
      let s = this.styles[o], a = s.style;
      if (!(a.indexOf(e) != 0 || s.context && !n.matchesContext(s.context) || // Test that the style string either precisely matches the prop,
      // or has an '=' sign after the prop, followed by the given
      // value.
      a.length > e.length && (a.charCodeAt(e.length) != 61 || a.slice(e.length + 1) != t))) {
        if (s.getAttrs) {
          let l = s.getAttrs(t);
          if (l === !1)
            continue;
          s.attrs = l || void 0;
        }
        return s;
      }
    }
  }
  /**
  @internal
  */
  static schemaRules(e) {
    let t = [];
    function n(i) {
      let o = i.priority == null ? 50 : i.priority, s = 0;
      for (; s < t.length; s++) {
        let a = t[s];
        if ((a.priority == null ? 50 : a.priority) < o)
          break;
      }
      t.splice(s, 0, i);
    }
    for (let i in e.marks) {
      let o = e.marks[i].spec.parseDOM;
      o && o.forEach((s) => {
        n(s = cn(s)), s.mark || s.ignore || s.clearMark || (s.mark = i);
      });
    }
    for (let i in e.nodes) {
      let o = e.nodes[i].spec.parseDOM;
      o && o.forEach((s) => {
        n(s = cn(s)), s.node || s.ignore || s.mark || (s.node = i);
      });
    }
    return t;
  }
  /**
  Construct a DOM parser using the parsing rules listed in a
  schema's [node specs](https://prosemirror.net/docs/ref/#model.NodeSpec.parseDOM), reordered by
  [priority](https://prosemirror.net/docs/ref/#model.GenericParseRule.priority).
  */
  static fromSchema(e) {
    return e.cached.domParser || (e.cached.domParser = new me(e, me.schemaRules(e)));
  }
}
const Zn = {
  address: !0,
  article: !0,
  aside: !0,
  blockquote: !0,
  canvas: !0,
  dd: !0,
  div: !0,
  dl: !0,
  fieldset: !0,
  figcaption: !0,
  figure: !0,
  footer: !0,
  form: !0,
  h1: !0,
  h2: !0,
  h3: !0,
  h4: !0,
  h5: !0,
  h6: !0,
  header: !0,
  hgroup: !0,
  hr: !0,
  li: !0,
  noscript: !0,
  ol: !0,
  output: !0,
  p: !0,
  pre: !0,
  section: !0,
  table: !0,
  tfoot: !0,
  ul: !0
}, ao = {
  head: !0,
  noscript: !0,
  object: !0,
  script: !0,
  style: !0,
  title: !0
}, er = { ol: !0, ul: !0 }, Oe = 1, Et = 2, Ce = 4;
function an(r, e, t) {
  return e != null ? (e ? Oe : 0) | (e === "full" ? Et : 0) : r && r.whitespace == "pre" ? Oe | Et : t & ~Ce;
}
class Ue {
  constructor(e, t, n, i, o, s) {
    this.type = e, this.attrs = t, this.marks = n, this.solid = i, this.options = s, this.content = [], this.activeMarks = N.none, this.match = o || (s & Ce ? null : e.contentMatch);
  }
  findWrapping(e) {
    if (!this.match) {
      if (!this.type)
        return [];
      let t = this.type.contentMatch.fillBefore(x.from(e));
      if (t)
        this.match = this.type.contentMatch.matchFragment(t);
      else {
        let n = this.type.contentMatch, i;
        return (i = n.findWrapping(e.type)) ? (this.match = n, i) : null;
      }
    }
    return this.match.findWrapping(e.type);
  }
  finish(e) {
    if (!(this.options & Oe)) {
      let n = this.content[this.content.length - 1], i;
      if (n && n.isText && (i = /[ \t\r\n\u000c]+$/.exec(n.text))) {
        let o = n;
        n.text.length == i[0].length ? this.content.pop() : this.content[this.content.length - 1] = o.withText(o.text.slice(0, o.text.length - i[0].length));
      }
    }
    let t = x.from(this.content);
    return !e && this.match && (t = t.append(this.match.fillBefore(x.empty, !0))), this.type ? this.type.create(this.attrs, t, this.marks) : t;
  }
  inlineContext(e) {
    return this.type ? this.type.inlineContent : this.content.length ? this.content[0].isInline : e.parentNode && !Zn.hasOwnProperty(e.parentNode.nodeName.toLowerCase());
  }
}
class ln {
  constructor(e, t, n) {
    this.parser = e, this.options = t, this.isOpen = n, this.open = 0, this.localPreserveWS = !1;
    let i = t.topNode, o, s = an(null, t.preserveWhitespace, 0) | (n ? Ce : 0);
    i ? o = new Ue(i.type, i.attrs, N.none, !0, t.topMatch || i.type.contentMatch, s) : n ? o = new Ue(null, null, N.none, !0, null, s) : o = new Ue(e.schema.topNodeType, null, N.none, !0, null, s), this.nodes = [o], this.find = t.findPositions, this.needsBlock = !1;
  }
  get top() {
    return this.nodes[this.open];
  }
  // Add a DOM node to the content. Text is inserted as text node,
  // otherwise, the node is passed to `addElement` or, if it has a
  // `style` attribute, `addElementWithStyles`.
  addDOM(e, t) {
    e.nodeType == 3 ? this.addTextNode(e, t) : e.nodeType == 1 && this.addElement(e, t);
  }
  addTextNode(e, t) {
    let n = e.nodeValue, i = this.top, o = i.options & Et ? "full" : this.localPreserveWS || (i.options & Oe) > 0, { schema: s } = this.parser;
    if (o === "full" || i.inlineContext(e) || /[^ \t\r\n\u000c]/.test(n)) {
      if (o)
        if (o === "full")
          n = n.replace(/\r\n?/g, `
`);
        else if (s.linebreakReplacement && /[\r\n]/.test(n) && this.top.findWrapping(s.linebreakReplacement.create())) {
          let a = n.split(/\r?\n|\r/);
          for (let l = 0; l < a.length; l++)
            l && this.insertNode(s.linebreakReplacement.create(), t, !0), a[l] && this.insertNode(s.text(a[l]), t, !/\S/.test(a[l]));
          n = "";
        } else
          n = n.replace(/\r?\n|\r/g, " ");
      else if (n = n.replace(/[ \t\r\n\u000c]+/g, " "), /^[ \t\r\n\u000c]/.test(n) && this.open == this.nodes.length - 1) {
        let a = i.content[i.content.length - 1], l = e.previousSibling;
        (!a || l && l.nodeName == "BR" || a.isText && /[ \t\r\n\u000c]$/.test(a.text)) && (n = n.slice(1));
      }
      n && this.insertNode(s.text(n), t, !/\S/.test(n)), this.findInText(e);
    } else
      this.findInside(e);
  }
  // Try to find a handler for the given tag and use that to parse. If
  // none is found, the element's content nodes are added directly.
  addElement(e, t, n) {
    let i = this.localPreserveWS, o = this.top;
    (e.tagName == "PRE" || /pre/.test(e.style && e.style.whiteSpace)) && (this.localPreserveWS = !0);
    let s = e.nodeName.toLowerCase(), a;
    er.hasOwnProperty(s) && this.parser.normalizeLists && lo(e);
    let l = this.options.ruleFromNode && this.options.ruleFromNode(e) || (a = this.parser.matchTag(e, this, n));
    e: if (l ? l.ignore : ao.hasOwnProperty(s))
      this.findInside(e), this.ignoreFallback(e, t);
    else if (!l || l.skip || l.closeParent) {
      l && l.closeParent ? this.open = Math.max(0, this.open - 1) : l && l.skip.nodeType && (e = l.skip);
      let c, d = this.needsBlock;
      if (Zn.hasOwnProperty(s))
        o.content.length && o.content[0].isInline && this.open && (this.open--, o = this.top), c = !0, o.type || (this.needsBlock = !0);
      else if (!e.firstChild) {
        this.leafFallback(e, t);
        break e;
      }
      let p = l && l.skip ? t : this.readStyles(e, t);
      p && this.addAll(e, p), c && this.sync(o), this.needsBlock = d;
    } else {
      let c = this.readStyles(e, t);
      c && this.addElementByRule(e, l, c, l.consuming === !1 ? a : void 0);
    }
    this.localPreserveWS = i;
  }
  // Called for leaf DOM nodes that would otherwise be ignored
  leafFallback(e, t) {
    e.nodeName == "BR" && this.top.type && this.top.type.inlineContent && this.addTextNode(e.ownerDocument.createTextNode(`
`), t);
  }
  // Called for ignored nodes
  ignoreFallback(e, t) {
    e.nodeName == "BR" && (!this.top.type || !this.top.type.inlineContent) && this.findPlace(this.parser.schema.text("-"), t, !0);
  }
  // Run any style parser associated with the node's styles. Either
  // return an updated array of marks, or null to indicate some of the
  // styles had a rule with `ignore` set.
  readStyles(e, t) {
    let n = e.style;
    if (n && n.length)
      for (let i = 0; i < this.parser.matchedStyles.length; i++) {
        let o = this.parser.matchedStyles[i], s = n.getPropertyValue(o);
        if (s)
          for (let a = void 0; ; ) {
            let l = this.parser.matchStyle(o, s, this, a);
            if (!l)
              break;
            if (l.ignore)
              return null;
            if (l.clearMark ? t = t.filter((c) => !l.clearMark(c)) : t = t.concat(this.parser.schema.marks[l.mark].create(l.attrs)), l.consuming === !1)
              a = l;
            else
              break;
          }
      }
    return t;
  }
  // Look up a handler for the given node. If none are found, return
  // false. Otherwise, apply it, use its return value to drive the way
  // the node's content is wrapped, and return true.
  addElementByRule(e, t, n, i) {
    let o, s;
    if (t.node)
      if (s = this.parser.schema.nodes[t.node], s.isLeaf)
        this.insertNode(s.create(t.attrs), n, e.nodeName == "BR") || this.leafFallback(e, n);
      else {
        let l = this.enter(s, t.attrs || null, n, t.preserveWhitespace);
        l && (o = !0, n = l);
      }
    else {
      let l = this.parser.schema.marks[t.mark];
      n = n.concat(l.create(t.attrs));
    }
    let a = this.top;
    if (s && s.isLeaf)
      this.findInside(e);
    else if (i)
      this.addElement(e, n, i);
    else if (t.getContent)
      this.findInside(e), t.getContent(e, this.parser.schema).forEach((l) => this.insertNode(l, n, !1));
    else {
      let l = e;
      typeof t.contentElement == "string" ? l = e.querySelector(t.contentElement) : typeof t.contentElement == "function" ? l = t.contentElement(e) : t.contentElement && (l = t.contentElement), this.findAround(e, l, !0), this.addAll(l, n), this.findAround(e, l, !1);
    }
    o && this.sync(a) && this.open--;
  }
  // Add all child nodes between `startIndex` and `endIndex` (or the
  // whole node, if not given). If `sync` is passed, use it to
  // synchronize after every block element.
  addAll(e, t, n, i) {
    let o = n || 0;
    for (let s = n ? e.childNodes[n] : e.firstChild, a = i == null ? null : e.childNodes[i]; s != a; s = s.nextSibling, ++o)
      this.findAtPoint(e, o), this.addDOM(s, t);
    this.findAtPoint(e, o);
  }
  // Try to find a way to fit the given node type into the current
  // context. May add intermediate wrappers and/or leave non-solid
  // nodes that we're in.
  findPlace(e, t, n) {
    let i, o;
    for (let s = this.open, a = 0; s >= 0; s--) {
      let l = this.nodes[s], c = l.findWrapping(e);
      if (c && (!i || i.length > c.length + a) && (i = c, o = l, !c.length))
        break;
      if (l.solid) {
        if (n)
          break;
        a += 2;
      }
    }
    if (!i)
      return null;
    this.sync(o);
    for (let s = 0; s < i.length; s++)
      t = this.enterInner(i[s], null, t, !1);
    return t;
  }
  // Try to insert the given node, adjusting the context when needed.
  insertNode(e, t, n) {
    if (e.isInline && this.needsBlock && !this.top.type) {
      let o = this.textblockFromContext();
      o && (t = this.enterInner(o, null, t));
    }
    let i = this.findPlace(e, t, n);
    if (i) {
      this.closeExtra();
      let o = this.top;
      o.match && (o.match = o.match.matchType(e.type));
      let s = N.none;
      for (let a of i.concat(e.marks))
        (o.type ? o.type.allowsMarkType(a.type) : dn(a.type, e.type)) && (s = a.addToSet(s));
      return o.content.push(e.mark(s)), !0;
    }
    return !1;
  }
  // Try to start a node of the given type, adjusting the context when
  // necessary.
  enter(e, t, n, i) {
    let o = this.findPlace(e.create(t), n, !1);
    return o && (o = this.enterInner(e, t, n, !0, i)), o;
  }
  // Open a node of the given type
  enterInner(e, t, n, i = !1, o) {
    this.closeExtra();
    let s = this.top;
    s.match = s.match && s.match.matchType(e);
    let a = an(e, o, s.options);
    s.options & Ce && s.content.length == 0 && (a |= Ce);
    let l = N.none;
    return n = n.filter((c) => (s.type ? s.type.allowsMarkType(c.type) : dn(c.type, e)) ? (l = c.addToSet(l), !1) : !0), this.nodes.push(new Ue(e, t, l, i, null, a)), this.open++, n;
  }
  // Make sure all nodes above this.open are finished and added to
  // their parents
  closeExtra(e = !1) {
    let t = this.nodes.length - 1;
    if (t > this.open) {
      for (; t > this.open; t--)
        this.nodes[t - 1].content.push(this.nodes[t].finish(e));
      this.nodes.length = this.open + 1;
    }
  }
  finish() {
    return this.open = 0, this.closeExtra(this.isOpen), this.nodes[0].finish(!!(this.isOpen || this.options.topOpen));
  }
  sync(e) {
    for (let t = this.open; t >= 0; t--) {
      if (this.nodes[t] == e)
        return this.open = t, !0;
      this.localPreserveWS && (this.nodes[t].options |= Oe);
    }
    return !1;
  }
  get currentPos() {
    this.closeExtra();
    let e = 0;
    for (let t = this.open; t >= 0; t--) {
      let n = this.nodes[t].content;
      for (let i = n.length - 1; i >= 0; i--)
        e += n[i].nodeSize;
      t && e++;
    }
    return e;
  }
  findAtPoint(e, t) {
    if (this.find)
      for (let n = 0; n < this.find.length; n++)
        this.find[n].node == e && this.find[n].offset == t && (this.find[n].pos = this.currentPos);
  }
  findInside(e) {
    if (this.find)
      for (let t = 0; t < this.find.length; t++)
        this.find[t].pos == null && e.nodeType == 1 && e.contains(this.find[t].node) && (this.find[t].pos = this.currentPos);
  }
  findAround(e, t, n) {
    if (e != t && this.find)
      for (let i = 0; i < this.find.length; i++)
        this.find[i].pos == null && e.nodeType == 1 && e.contains(this.find[i].node) && t.compareDocumentPosition(this.find[i].node) & (n ? 2 : 4) && (this.find[i].pos = this.currentPos);
  }
  findInText(e) {
    if (this.find)
      for (let t = 0; t < this.find.length; t++)
        this.find[t].node == e && (this.find[t].pos = this.currentPos - (e.nodeValue.length - this.find[t].offset));
  }
  // Determines whether the given context string matches this context.
  matchesContext(e) {
    if (e.indexOf("|") > -1)
      return e.split(/\s*\|\s*/).some(this.matchesContext, this);
    let t = e.split("/"), n = this.options.context, i = !this.isOpen && (!n || n.parent.type == this.nodes[0].type), o = -(n ? n.depth + 1 : 0) + (i ? 0 : 1), s = (a, l) => {
      for (; a >= 0; a--) {
        let c = t[a];
        if (c == "") {
          if (a == t.length - 1 || a == 0)
            continue;
          for (; l >= o; l--)
            if (s(a - 1, l))
              return !0;
          return !1;
        } else {
          let d = l > 0 || l == 0 && i ? this.nodes[l].type : n && l >= o ? n.node(l - o).type : null;
          if (!d || d.name != c && !d.isInGroup(c))
            return !1;
          l--;
        }
      }
      return !0;
    };
    return s(t.length - 1, this.open);
  }
  textblockFromContext() {
    let e = this.options.context;
    if (e)
      for (let t = e.depth; t >= 0; t--) {
        let n = e.node(t).contentMatchAt(e.indexAfter(t)).defaultType;
        if (n && n.isTextblock && n.defaultAttrs)
          return n;
      }
    for (let t in this.parser.schema.nodes) {
      let n = this.parser.schema.nodes[t];
      if (n.isTextblock && n.defaultAttrs)
        return n;
    }
  }
}
function lo(r) {
  for (let e = r.firstChild, t = null; e; e = e.nextSibling) {
    let n = e.nodeType == 1 ? e.nodeName.toLowerCase() : null;
    n && er.hasOwnProperty(n) && t ? (t.appendChild(e), e = t) : n == "li" ? t = e : n && (t = null);
  }
}
function co(r, e) {
  return (r.matches || r.msMatchesSelector || r.webkitMatchesSelector || r.mozMatchesSelector).call(r, e);
}
function cn(r) {
  let e = {};
  for (let t in r)
    e[t] = r[t];
  return e;
}
function dn(r, e) {
  let t = e.schema.nodes;
  for (let n in t) {
    let i = t[n];
    if (!i.allowsMarkType(r))
      continue;
    let o = [], s = (a) => {
      o.push(a);
      for (let l = 0; l < a.edgeCount; l++) {
        let { type: c, next: d } = a.edge(l);
        if (c == e || o.indexOf(d) < 0 && s(d))
          return !0;
      }
    };
    if (s(i.contentMatch))
      return !0;
  }
}
const tr = 65535, nr = Math.pow(2, 16);
function uo(r, e) {
  return r + e * nr;
}
function un(r) {
  return r & tr;
}
function po(r) {
  return (r - (r & tr)) / nr;
}
const rr = 1, ir = 2, qe = 4, or = 8;
class pn {
  /**
  @internal
  */
  constructor(e, t, n) {
    this.pos = e, this.delInfo = t, this.recover = n;
  }
  /**
  Tells you whether the position was deleted, that is, whether the
  step removed the token on the side queried (via the `assoc`)
  argument from the document.
  */
  get deleted() {
    return (this.delInfo & or) > 0;
  }
  /**
  Tells you whether the token before the mapped position was deleted.
  */
  get deletedBefore() {
    return (this.delInfo & (rr | qe)) > 0;
  }
  /**
  True when the token after the mapped position was deleted.
  */
  get deletedAfter() {
    return (this.delInfo & (ir | qe)) > 0;
  }
  /**
  Tells whether any of the steps mapped through deletes across the
  position (including both the token before and after the
  position).
  */
  get deletedAcross() {
    return (this.delInfo & qe) > 0;
  }
}
class D {
  /**
  Create a position map. The modifications to the document are
  represented as an array of numbers, in which each group of three
  represents a modified chunk as `[start, oldSize, newSize]`.
  */
  constructor(e, t = !1) {
    if (this.ranges = e, this.inverted = t, !e.length && D.empty)
      return D.empty;
  }
  /**
  @internal
  */
  recover(e) {
    let t = 0, n = un(e);
    if (!this.inverted)
      for (let i = 0; i < n; i++)
        t += this.ranges[i * 3 + 2] - this.ranges[i * 3 + 1];
    return this.ranges[n * 3] + t + po(e);
  }
  mapResult(e, t = 1) {
    return this._map(e, t, !1);
  }
  map(e, t = 1) {
    return this._map(e, t, !0);
  }
  /**
  @internal
  */
  _map(e, t, n) {
    let i = 0, o = this.inverted ? 2 : 1, s = this.inverted ? 1 : 2;
    for (let a = 0; a < this.ranges.length; a += 3) {
      let l = this.ranges[a] - (this.inverted ? i : 0);
      if (l > e)
        break;
      let c = this.ranges[a + o], d = this.ranges[a + s], p = l + c;
      if (e <= p) {
        let f = c ? e == l ? -1 : e == p ? 1 : t : t, h = l + i + (f < 0 ? 0 : d);
        if (n)
          return h;
        let b = e == (t < 0 ? l : p) ? null : uo(a / 3, e - l), m = e == l ? ir : e == p ? rr : qe;
        return (t < 0 ? e != l : e != p) && (m |= or), new pn(h, m, b);
      }
      i += d - c;
    }
    return n ? e + i : new pn(e + i, 0, null);
  }
  /**
  @internal
  */
  touches(e, t) {
    let n = 0, i = un(t), o = this.inverted ? 2 : 1, s = this.inverted ? 1 : 2;
    for (let a = 0; a < this.ranges.length; a += 3) {
      let l = this.ranges[a] - (this.inverted ? n : 0);
      if (l > e)
        break;
      let c = this.ranges[a + o], d = l + c;
      if (e <= d && a == i * 3)
        return !0;
      n += this.ranges[a + s] - c;
    }
    return !1;
  }
  /**
  Calls the given function on each of the changed ranges included in
  this map.
  */
  forEach(e) {
    let t = this.inverted ? 2 : 1, n = this.inverted ? 1 : 2;
    for (let i = 0, o = 0; i < this.ranges.length; i += 3) {
      let s = this.ranges[i], a = s - (this.inverted ? o : 0), l = s + (this.inverted ? 0 : o), c = this.ranges[i + t], d = this.ranges[i + n];
      e(a, a + c, l, l + d), o += d - c;
    }
  }
  /**
  Create an inverted version of this map. The result can be used to
  map positions in the post-step document to the pre-step document.
  */
  invert() {
    return new D(this.ranges, !this.inverted);
  }
  /**
  @internal
  */
  toString() {
    return (this.inverted ? "-" : "") + JSON.stringify(this.ranges);
  }
  /**
  Create a map that moves all positions by offset `n` (which may be
  negative). This can be useful when applying steps meant for a
  sub-document to a larger document, or vice-versa.
  */
  static offset(e) {
    return e == 0 ? D.empty : new D(e < 0 ? [0, -e, 0] : [0, 0, e]);
  }
}
D.empty = new D([]);
const ht = /* @__PURE__ */ Object.create(null);
class B {
  /**
  Get the step map that represents the changes made by this step,
  and which can be used to transform between positions in the old
  and the new document.
  */
  getMap() {
    return D.empty;
  }
  /**
  Try to merge this step with another one, to be applied directly
  after it. Returns the merged step when possible, null if the
  steps can't be merged.
  */
  merge(e) {
    return null;
  }
  /**
  Deserialize a step from its JSON representation. Will call
  through to the step class' own implementation of this method.
  */
  static fromJSON(e, t) {
    if (!t || !t.stepType)
      throw new RangeError("Invalid input for Step.fromJSON");
    let n = ht[t.stepType];
    if (!n)
      throw new RangeError(`No step type ${t.stepType} defined`);
    return n.fromJSON(e, t);
  }
  /**
  To be able to serialize steps to JSON, each step needs a string
  ID to attach to its JSON representation. Use this method to
  register an ID for your step classes. Try to pick something
  that's unlikely to clash with steps from other modules.
  */
  static jsonID(e, t) {
    if (e in ht)
      throw new RangeError("Duplicate use of step JSON ID " + e);
    return ht[e] = t, t.prototype.jsonID = e, t;
  }
}
class A {
  /**
  @internal
  */
  constructor(e, t) {
    this.doc = e, this.failed = t;
  }
  /**
  Create a successful step result.
  */
  static ok(e) {
    return new A(e, null);
  }
  /**
  Create a failed step result.
  */
  static fail(e) {
    return new A(null, e);
  }
  /**
  Call [`Node.replace`](https://prosemirror.net/docs/ref/#model.Node.replace) with the given
  arguments. Create a successful result if it succeeds, and a
  failed one if it throws a `ReplaceError`.
  */
  static fromReplace(e, t, n, i) {
    try {
      return A.ok(e.replace(t, n, i));
    } catch (o) {
      if (o instanceof Xe)
        return A.fail(o.message);
      throw o;
    }
  }
}
function Rt(r, e, t) {
  let n = [];
  for (let i = 0; i < r.childCount; i++) {
    let o = r.child(i);
    o.content.size && (o = o.copy(Rt(o.content, e, o))), o.isInline && (o = e(o, t, i)), n.push(o);
  }
  return x.fromArray(n);
}
class ne extends B {
  /**
  Create a mark step.
  */
  constructor(e, t, n) {
    super(), this.from = e, this.to = t, this.mark = n;
  }
  apply(e) {
    let t = e.slice(this.from, this.to), n = e.resolve(this.from), i = n.node(n.sharedDepth(this.to)), o = new w(Rt(t.content, (s, a) => !s.isAtom || !a.type.allowsMarkType(this.mark.type) ? s : s.mark(this.mark.addToSet(s.marks)), i), t.openStart, t.openEnd);
    return A.fromReplace(e, this.from, this.to, o);
  }
  invert() {
    return new re(this.from, this.to, this.mark);
  }
  map(e) {
    let t = e.mapResult(this.from, 1), n = e.mapResult(this.to, -1);
    return t.deleted && n.deleted || t.pos >= n.pos ? null : new ne(t.pos, n.pos, this.mark);
  }
  merge(e) {
    return e instanceof ne && e.mark.eq(this.mark) && this.from <= e.to && this.to >= e.from ? new ne(Math.min(this.from, e.from), Math.max(this.to, e.to), this.mark) : null;
  }
  toJSON() {
    return {
      stepType: "addMark",
      mark: this.mark.toJSON(),
      from: this.from,
      to: this.to
    };
  }
  /**
  @internal
  */
  static fromJSON(e, t) {
    if (typeof t.from != "number" || typeof t.to != "number")
      throw new RangeError("Invalid input for AddMarkStep.fromJSON");
    return new ne(t.from, t.to, e.markFromJSON(t.mark));
  }
}
B.jsonID("addMark", ne);
class re extends B {
  /**
  Create a mark-removing step.
  */
  constructor(e, t, n) {
    super(), this.from = e, this.to = t, this.mark = n;
  }
  apply(e) {
    let t = e.slice(this.from, this.to), n = new w(Rt(t.content, (i) => i.mark(this.mark.removeFromSet(i.marks)), e), t.openStart, t.openEnd);
    return A.fromReplace(e, this.from, this.to, n);
  }
  invert() {
    return new ne(this.from, this.to, this.mark);
  }
  map(e) {
    let t = e.mapResult(this.from, 1), n = e.mapResult(this.to, -1);
    return t.deleted && n.deleted || t.pos >= n.pos ? null : new re(t.pos, n.pos, this.mark);
  }
  merge(e) {
    return e instanceof re && e.mark.eq(this.mark) && this.from <= e.to && this.to >= e.from ? new re(Math.min(this.from, e.from), Math.max(this.to, e.to), this.mark) : null;
  }
  toJSON() {
    return {
      stepType: "removeMark",
      mark: this.mark.toJSON(),
      from: this.from,
      to: this.to
    };
  }
  /**
  @internal
  */
  static fromJSON(e, t) {
    if (typeof t.from != "number" || typeof t.to != "number")
      throw new RangeError("Invalid input for RemoveMarkStep.fromJSON");
    return new re(t.from, t.to, e.markFromJSON(t.mark));
  }
}
B.jsonID("removeMark", re);
class ie extends B {
  /**
  Create a node mark step.
  */
  constructor(e, t) {
    super(), this.pos = e, this.mark = t;
  }
  apply(e) {
    let t = e.nodeAt(this.pos);
    if (!t)
      return A.fail("No node at mark step's position");
    let n = t.type.create(t.attrs, null, this.mark.addToSet(t.marks));
    return A.fromReplace(e, this.pos, this.pos + 1, new w(x.from(n), 0, t.isLeaf ? 0 : 1));
  }
  invert(e) {
    let t = e.nodeAt(this.pos);
    if (t) {
      let n = this.mark.addToSet(t.marks);
      if (n.length == t.marks.length) {
        for (let i = 0; i < t.marks.length; i++)
          if (!t.marks[i].isInSet(n))
            return new ie(this.pos, t.marks[i]);
        return new ie(this.pos, this.mark);
      }
    }
    return new Re(this.pos, this.mark);
  }
  map(e) {
    let t = e.mapResult(this.pos, 1);
    return t.deletedAfter ? null : new ie(t.pos, this.mark);
  }
  toJSON() {
    return { stepType: "addNodeMark", pos: this.pos, mark: this.mark.toJSON() };
  }
  /**
  @internal
  */
  static fromJSON(e, t) {
    if (typeof t.pos != "number")
      throw new RangeError("Invalid input for AddNodeMarkStep.fromJSON");
    return new ie(t.pos, e.markFromJSON(t.mark));
  }
}
B.jsonID("addNodeMark", ie);
class Re extends B {
  /**
  Create a mark-removing step.
  */
  constructor(e, t) {
    super(), this.pos = e, this.mark = t;
  }
  apply(e) {
    let t = e.nodeAt(this.pos);
    if (!t)
      return A.fail("No node at mark step's position");
    let n = t.type.create(t.attrs, null, this.mark.removeFromSet(t.marks));
    return A.fromReplace(e, this.pos, this.pos + 1, new w(x.from(n), 0, t.isLeaf ? 0 : 1));
  }
  invert(e) {
    let t = e.nodeAt(this.pos);
    return !t || !this.mark.isInSet(t.marks) ? this : new ie(this.pos, this.mark);
  }
  map(e) {
    let t = e.mapResult(this.pos, 1);
    return t.deletedAfter ? null : new Re(t.pos, this.mark);
  }
  toJSON() {
    return { stepType: "removeNodeMark", pos: this.pos, mark: this.mark.toJSON() };
  }
  /**
  @internal
  */
  static fromJSON(e, t) {
    if (typeof t.pos != "number")
      throw new RangeError("Invalid input for RemoveNodeMarkStep.fromJSON");
    return new Re(t.pos, e.markFromJSON(t.mark));
  }
}
B.jsonID("removeNodeMark", Re);
class L extends B {
  /**
  The given `slice` should fit the 'gap' between `from` and
  `to`—the depths must line up, and the surrounding nodes must be
  able to be joined with the open sides of the slice. When
  `structure` is true, the step will fail if the content between
  from and to is not just a sequence of closing and then opening
  tokens (this is to guard against rebased replace steps
  overwriting something they weren't supposed to).
  */
  constructor(e, t, n, i = !1) {
    super(), this.from = e, this.to = t, this.slice = n, this.structure = i;
  }
  apply(e) {
    return this.structure && _t(e, this.from, this.to) ? A.fail("Structure replace would overwrite content") : A.fromReplace(e, this.from, this.to, this.slice);
  }
  getMap() {
    return new D([this.from, this.to - this.from, this.slice.size]);
  }
  invert(e) {
    return new L(this.from, this.from + this.slice.size, e.slice(this.from, this.to));
  }
  map(e) {
    let t = e.mapResult(this.to, -1), n = this.from == this.to && L.MAP_BIAS < 0 ? t : e.mapResult(this.from, 1);
    return n.deletedAcross && t.deletedAcross ? null : new L(n.pos, Math.max(n.pos, t.pos), this.slice, this.structure);
  }
  merge(e) {
    if (!(e instanceof L) || e.structure || this.structure)
      return null;
    if (this.from + this.slice.size == e.from && !this.slice.openEnd && !e.slice.openStart) {
      let t = this.slice.size + e.slice.size == 0 ? w.empty : new w(this.slice.content.append(e.slice.content), this.slice.openStart, e.slice.openEnd);
      return new L(this.from, this.to + (e.to - e.from), t, this.structure);
    } else if (e.to == this.from && !this.slice.openStart && !e.slice.openEnd) {
      let t = this.slice.size + e.slice.size == 0 ? w.empty : new w(e.slice.content.append(this.slice.content), e.slice.openStart, this.slice.openEnd);
      return new L(e.from, this.to, t, this.structure);
    } else
      return null;
  }
  toJSON() {
    let e = { stepType: "replace", from: this.from, to: this.to };
    return this.slice.size && (e.slice = this.slice.toJSON()), this.structure && (e.structure = !0), e;
  }
  /**
  @internal
  */
  static fromJSON(e, t) {
    if (typeof t.from != "number" || typeof t.to != "number")
      throw new RangeError("Invalid input for ReplaceStep.fromJSON");
    return new L(t.from, t.to, w.fromJSON(e, t.slice), !!t.structure);
  }
}
L.MAP_BIAS = 1;
B.jsonID("replace", L);
class P extends B {
  /**
  Create a replace-around step with the given range and gap.
  `insert` should be the point in the slice into which the content
  of the gap should be moved. `structure` has the same meaning as
  it has in the [`ReplaceStep`](https://prosemirror.net/docs/ref/#transform.ReplaceStep) class.
  */
  constructor(e, t, n, i, o, s, a = !1) {
    super(), this.from = e, this.to = t, this.gapFrom = n, this.gapTo = i, this.slice = o, this.insert = s, this.structure = a;
  }
  apply(e) {
    if (this.structure && (_t(e, this.from, this.gapFrom) || _t(e, this.gapTo, this.to)))
      return A.fail("Structure gap-replace would overwrite content");
    let t = e.slice(this.gapFrom, this.gapTo);
    if (t.openStart || t.openEnd)
      return A.fail("Gap is not a flat range");
    let n = this.slice.insertAt(this.insert, t.content);
    return n ? A.fromReplace(e, this.from, this.to, n) : A.fail("Content does not fit in gap");
  }
  getMap() {
    return new D([
      this.from,
      this.gapFrom - this.from,
      this.insert,
      this.gapTo,
      this.to - this.gapTo,
      this.slice.size - this.insert
    ]);
  }
  invert(e) {
    let t = this.gapTo - this.gapFrom;
    return new P(this.from, this.from + this.slice.size + t, this.from + this.insert, this.from + this.insert + t, e.slice(this.from, this.to).removeBetween(this.gapFrom - this.from, this.gapTo - this.from), this.gapFrom - this.from, this.structure);
  }
  map(e) {
    let t = e.mapResult(this.from, 1), n = e.mapResult(this.to, -1), i = this.from == this.gapFrom ? t.pos : e.map(this.gapFrom, -1), o = this.to == this.gapTo ? n.pos : e.map(this.gapTo, 1);
    return t.deletedAcross && n.deletedAcross || i < t.pos || o > n.pos ? null : new P(t.pos, n.pos, i, o, this.slice, this.insert, this.structure);
  }
  toJSON() {
    let e = {
      stepType: "replaceAround",
      from: this.from,
      to: this.to,
      gapFrom: this.gapFrom,
      gapTo: this.gapTo,
      insert: this.insert
    };
    return this.slice.size && (e.slice = this.slice.toJSON()), this.structure && (e.structure = !0), e;
  }
  /**
  @internal
  */
  static fromJSON(e, t) {
    if (typeof t.from != "number" || typeof t.to != "number" || typeof t.gapFrom != "number" || typeof t.gapTo != "number" || typeof t.insert != "number")
      throw new RangeError("Invalid input for ReplaceAroundStep.fromJSON");
    return new P(t.from, t.to, t.gapFrom, t.gapTo, w.fromJSON(e, t.slice), t.insert, !!t.structure);
  }
}
B.jsonID("replaceAround", P);
function _t(r, e, t) {
  let n = r.resolve(e), i = t - e, o = n.depth;
  for (; i > 0 && o > 0 && n.indexAfter(o) == n.node(o).childCount; )
    o--, i--;
  if (i > 0) {
    let s = n.node(o).maybeChild(n.indexAfter(o));
    for (; i > 0; ) {
      if (!s || s.isLeaf)
        return !0;
      s = s.firstChild, i--;
    }
  }
  return !1;
}
function fo(r, e, t) {
  return (e == 0 || r.canReplace(e, r.childCount)) && (t == r.childCount || r.canReplace(0, t));
}
function xe(r) {
  let t = r.parent.content.cutByIndex(r.startIndex, r.endIndex);
  for (let n = r.depth, i = 0, o = 0; ; --n) {
    let s = r.$from.node(n), a = r.$from.index(n) + i, l = r.$to.indexAfter(n) - o;
    if (n < r.depth && s.canReplace(a, l, t))
      return n;
    if (n == 0 || s.type.spec.isolating || !fo(s, a, l))
      break;
    a && (i = 1), l < s.childCount && (o = 1);
  }
  return null;
}
function sr(r, e, t = null, n = r) {
  let i = ho(r, e), o = i && mo(n, e);
  return o ? i.map(fn).concat({ type: e, attrs: t }).concat(o.map(fn)) : null;
}
function fn(r) {
  return { type: r, attrs: null };
}
function ho(r, e) {
  let { parent: t, startIndex: n, endIndex: i } = r, o = t.contentMatchAt(n).findWrapping(e);
  if (!o)
    return null;
  let s = o.length ? o[0] : e;
  return t.canReplaceWith(n, i, s) ? o : null;
}
function mo(r, e) {
  let { parent: t, startIndex: n, endIndex: i } = r, o = t.child(n), s = e.contentMatch.findWrapping(o.type);
  if (!s)
    return null;
  let l = (s.length ? s[s.length - 1] : e).contentMatch;
  for (let c = n; l && c < i; c++)
    l = l.matchType(t.child(c).type);
  return !l || !l.validEnd ? null : s;
}
function Y(r, e, t = 1, n) {
  let i = r.resolve(e), o = i.depth - t, s = n && n[n.length - 1] || i.parent;
  if (o < 0 || i.parent.type.spec.isolating || !i.parent.canReplace(i.index(), i.parent.childCount) || !s.type.validContent(i.parent.content.cutByIndex(i.index(), i.parent.childCount)))
    return !1;
  for (let c = i.depth - 1, d = t - 2; c > o; c--, d--) {
    let p = i.node(c), f = i.index(c);
    if (p.type.spec.isolating)
      return !1;
    let h = p.content.cutByIndex(f, p.childCount), b = n && n[d + 1];
    b && (h = h.replaceChild(0, b.type.create(b.attrs)));
    let m = n && n[d] || p;
    if (!p.canReplace(f + 1, p.childCount) || !m.type.validContent(h))
      return !1;
  }
  let a = i.indexAfter(o), l = n && n[0];
  return i.node(o).canReplaceWith(a, a, l ? l.type : i.node(o + 1).type);
}
function de(r, e) {
  let t = r.resolve(e), n = t.index();
  return ar(t.nodeBefore, t.nodeAfter) && t.parent.canReplace(n, n + 1);
}
function go(r, e) {
  e.content.size || r.type.compatibleContent(e.type);
  let t = r.contentMatchAt(r.childCount), { linebreakReplacement: n } = r.type.schema;
  for (let i = 0; i < e.childCount; i++) {
    let o = e.child(i), s = o.type == n ? r.type.schema.nodes.text : o.type;
    if (t = t.matchType(s), !t || !r.type.allowsMarks(o.marks))
      return !1;
  }
  return t.validEnd;
}
function ar(r, e) {
  return !!(r && e && !r.isLeaf && go(r, e));
}
function at(r, e, t = -1) {
  let n = r.resolve(e);
  for (let i = n.depth; ; i--) {
    let o, s, a = n.index(i);
    if (i == n.depth ? (o = n.nodeBefore, s = n.nodeAfter) : t > 0 ? (o = n.node(i + 1), a++, s = n.node(i).maybeChild(a)) : (o = n.node(i).maybeChild(a - 1), s = n.node(i + 1)), o && !o.isTextblock && ar(o, s) && n.node(i).canReplace(a, a + 1))
      return e;
    if (i == 0)
      break;
    e = t < 0 ? n.before(i) : n.after(i);
  }
}
function zt(r, e, t = e, n = w.empty) {
  if (e == t && !n.size)
    return null;
  let i = r.resolve(e), o = r.resolve(t);
  return bo(i, o, n) ? new L(e, t, n) : new yo(i, o, n).fit();
}
function bo(r, e, t) {
  return !t.openStart && !t.openEnd && r.start() == e.start() && r.parent.canReplace(r.index(), e.index(), t.content);
}
class yo {
  constructor(e, t, n) {
    this.$from = e, this.$to = t, this.unplaced = n, this.frontier = [], this.placed = x.empty;
    for (let i = 0; i <= e.depth; i++) {
      let o = e.node(i);
      this.frontier.push({
        type: o.type,
        match: o.contentMatchAt(e.indexAfter(i))
      });
    }
    for (let i = e.depth; i > 0; i--)
      this.placed = x.from(e.node(i).copy(this.placed));
  }
  get depth() {
    return this.frontier.length - 1;
  }
  fit() {
    for (; this.unplaced.size; ) {
      let c = this.findFittable();
      c ? this.placeNodes(c) : this.openMore() || this.dropNode();
    }
    let e = this.mustMoveInline(), t = this.placed.size - this.depth - this.$from.depth, n = this.$from, i = this.close(e < 0 ? this.$to : n.doc.resolve(e));
    if (!i)
      return null;
    let o = this.placed, s = n.depth, a = i.depth;
    for (; s && a && o.childCount == 1; )
      o = o.firstChild.content, s--, a--;
    let l = new w(o, s, a);
    return e > -1 ? new P(n.pos, e, this.$to.pos, this.$to.end(), l, t) : l.size || n.pos != this.$to.pos ? new L(n.pos, i.pos, l) : null;
  }
  // Find a position on the start spine of `this.unplaced` that has
  // content that can be moved somewhere on the frontier. Returns two
  // depths, one for the slice and one for the frontier.
  findFittable() {
    let e = this.unplaced.openStart;
    for (let t = this.unplaced.content, n = 0, i = this.unplaced.openEnd; n < e; n++) {
      let o = t.firstChild;
      if (t.childCount > 1 && (i = 0), o.type.spec.isolating && i <= n) {
        e = n;
        break;
      }
      t = o.content;
    }
    for (let t = 1; t <= 2; t++)
      for (let n = t == 1 ? e : this.unplaced.openStart; n >= 0; n--) {
        let i, o = null;
        n ? (o = mt(this.unplaced.content, n - 1).firstChild, i = o.content) : i = this.unplaced.content;
        let s = i.firstChild;
        for (let a = this.depth; a >= 0; a--) {
          let { type: l, match: c } = this.frontier[a], d, p = null;
          if (t == 1 && (s ? c.matchType(s.type) || (p = c.fillBefore(x.from(s), !1)) : o && l.compatibleContent(o.type)))
            return { sliceDepth: n, frontierDepth: a, parent: o, inject: p };
          if (t == 2 && s && (d = c.findWrapping(s.type)))
            return { sliceDepth: n, frontierDepth: a, parent: o, wrap: d };
          if (o && c.matchType(o.type))
            break;
        }
      }
  }
  openMore() {
    let { content: e, openStart: t, openEnd: n } = this.unplaced, i = mt(e, t);
    return !i.childCount || i.firstChild.isLeaf ? !1 : (this.unplaced = new w(e, t + 1, Math.max(n, i.size + t >= e.size - n ? t + 1 : 0)), !0);
  }
  dropNode() {
    let { content: e, openStart: t, openEnd: n } = this.unplaced, i = mt(e, t);
    if (i.childCount <= 1 && t > 0) {
      let o = e.size - t <= t + i.size;
      this.unplaced = new w(we(e, t - 1, 1), t - 1, o ? t - 1 : n);
    } else
      this.unplaced = new w(we(e, t, 1), t, n);
  }
  // Move content from the unplaced slice at `sliceDepth` to the
  // frontier node at `frontierDepth`. Close that frontier node when
  // applicable.
  placeNodes({ sliceDepth: e, frontierDepth: t, parent: n, inject: i, wrap: o }) {
    for (; this.depth > t; )
      this.closeFrontierNode();
    if (o)
      for (let m = 0; m < o.length; m++)
        this.openFrontierNode(o[m]);
    let s = this.unplaced, a = n ? n.content : s.content, l = s.openStart - e, c = 0, d = [], { match: p, type: f } = this.frontier[t];
    if (i) {
      for (let m = 0; m < i.childCount; m++)
        d.push(i.child(m));
      p = p.matchFragment(i);
    }
    let h = a.size + e - (s.content.size - s.openEnd);
    for (; c < a.childCount; ) {
      let m = a.child(c), y = p.matchType(m.type);
      if (!y)
        break;
      c++, (c > 1 || l == 0 || m.content.size) && (p = y, d.push(lr(m.mark(f.allowedMarks(m.marks)), c == 1 ? l : 0, c == a.childCount ? h : -1)));
    }
    let b = c == a.childCount;
    b || (h = -1), this.placed = ke(this.placed, t, x.from(d)), this.frontier[t].match = p, b && h < 0 && n && n.type == this.frontier[this.depth].type && this.frontier.length > 1 && this.closeFrontierNode();
    for (let m = 0, y = a; m < h; m++) {
      let v = y.lastChild;
      this.frontier.push({ type: v.type, match: v.contentMatchAt(v.childCount) }), y = v.content;
    }
    this.unplaced = b ? e == 0 ? w.empty : new w(we(s.content, e - 1, 1), e - 1, h < 0 ? s.openEnd : e - 1) : new w(we(s.content, e, c), s.openStart, s.openEnd);
  }
  mustMoveInline() {
    if (!this.$to.parent.isTextblock)
      return -1;
    let e = this.frontier[this.depth], t;
    if (!e.type.isTextblock || !gt(this.$to, this.$to.depth, e.type, e.match, !1) || this.$to.depth == this.depth && (t = this.findCloseLevel(this.$to)) && t.depth == this.depth)
      return -1;
    let { depth: n } = this.$to, i = this.$to.after(n);
    for (; n > 1 && i == this.$to.end(--n); )
      ++i;
    return i;
  }
  findCloseLevel(e) {
    e: for (let t = Math.min(this.depth, e.depth); t >= 0; t--) {
      let { match: n, type: i } = this.frontier[t], o = t < e.depth && e.end(t + 1) == e.pos + (e.depth - (t + 1)), s = gt(e, t, i, n, o);
      if (s) {
        for (let a = t - 1; a >= 0; a--) {
          let { match: l, type: c } = this.frontier[a], d = gt(e, a, c, l, !0);
          if (!d || d.childCount)
            continue e;
        }
        return { depth: t, fit: s, move: o ? e.doc.resolve(e.after(t + 1)) : e };
      }
    }
  }
  close(e) {
    let t = this.findCloseLevel(e);
    if (!t)
      return null;
    for (; this.depth > t.depth; )
      this.closeFrontierNode();
    t.fit.childCount && (this.placed = ke(this.placed, t.depth, t.fit)), e = t.move;
    for (let n = t.depth + 1; n <= e.depth; n++) {
      let i = e.node(n), o = i.type.contentMatch.fillBefore(i.content, !0, e.index(n));
      this.openFrontierNode(i.type, i.attrs, o);
    }
    return e;
  }
  openFrontierNode(e, t = null, n) {
    let i = this.frontier[this.depth];
    i.match = i.match.matchType(e), this.placed = ke(this.placed, this.depth, x.from(e.create(t, n))), this.frontier.push({ type: e, match: e.contentMatch });
  }
  closeFrontierNode() {
    let t = this.frontier.pop().match.fillBefore(x.empty, !0);
    t.childCount && (this.placed = ke(this.placed, this.frontier.length, t));
  }
}
function we(r, e, t) {
  return e == 0 ? r.cutByIndex(t, r.childCount) : r.replaceChild(0, r.firstChild.copy(we(r.firstChild.content, e - 1, t)));
}
function ke(r, e, t) {
  return e == 0 ? r.append(t) : r.replaceChild(r.childCount - 1, r.lastChild.copy(ke(r.lastChild.content, e - 1, t)));
}
function mt(r, e) {
  for (let t = 0; t < e; t++)
    r = r.firstChild.content;
  return r;
}
function lr(r, e, t) {
  if (e <= 0)
    return r;
  let n = r.content;
  return e > 1 && (n = n.replaceChild(0, lr(n.firstChild, e - 1, n.childCount == 1 ? t - 1 : 0))), e > 0 && (n = r.type.contentMatch.fillBefore(n).append(n), t <= 0 && (n = n.append(r.type.contentMatch.matchFragment(n).fillBefore(x.empty, !0)))), r.copy(n);
}
function gt(r, e, t, n, i) {
  let o = r.node(e), s = i ? r.indexAfter(e) : r.index(e);
  if (s == o.childCount && !t.compatibleContent(o.type))
    return null;
  let a = n.fillBefore(o.content, !0, s);
  return a && !xo(t, o.content, s) ? a : null;
}
function xo(r, e, t) {
  for (let n = t; n < e.childCount; n++)
    if (!r.allowsMarks(e.child(n).marks))
      return !0;
  return !1;
}
class Ee extends B {
  /**
  Construct an attribute step.
  */
  constructor(e, t, n) {
    super(), this.pos = e, this.attr = t, this.value = n;
  }
  apply(e) {
    let t = e.nodeAt(this.pos);
    if (!t)
      return A.fail("No node at attribute step's position");
    let n = /* @__PURE__ */ Object.create(null);
    for (let o in t.attrs)
      n[o] = t.attrs[o];
    n[this.attr] = this.value;
    let i = t.type.create(n, null, t.marks);
    return A.fromReplace(e, this.pos, this.pos + 1, new w(x.from(i), 0, t.isLeaf ? 0 : 1));
  }
  getMap() {
    return D.empty;
  }
  invert(e) {
    return new Ee(this.pos, this.attr, e.nodeAt(this.pos).attrs[this.attr]);
  }
  map(e) {
    let t = e.mapResult(this.pos, 1);
    return t.deletedAfter ? null : new Ee(t.pos, this.attr, this.value);
  }
  toJSON() {
    return { stepType: "attr", pos: this.pos, attr: this.attr, value: this.value };
  }
  static fromJSON(e, t) {
    if (typeof t.pos != "number" || typeof t.attr != "string")
      throw new RangeError("Invalid input for AttrStep.fromJSON");
    return new Ee(t.pos, t.attr, t.value);
  }
}
B.jsonID("attr", Ee);
class nt extends B {
  /**
  Construct an attribute step.
  */
  constructor(e, t) {
    super(), this.attr = e, this.value = t;
  }
  apply(e) {
    let t = /* @__PURE__ */ Object.create(null);
    for (let i in e.attrs)
      t[i] = e.attrs[i];
    t[this.attr] = this.value;
    let n = e.type.create(t, e.content, e.marks);
    return A.ok(n);
  }
  getMap() {
    return D.empty;
  }
  invert(e) {
    return new nt(this.attr, e.attrs[this.attr]);
  }
  map(e) {
    return this;
  }
  toJSON() {
    return { stepType: "docAttr", attr: this.attr, value: this.value };
  }
  static fromJSON(e, t) {
    if (typeof t.attr != "string")
      throw new RangeError("Invalid input for DocAttrStep.fromJSON");
    return new nt(t.attr, t.value);
  }
}
B.jsonID("docAttr", nt);
let ze = class extends Error {
};
ze = function r(e) {
  let t = Error.call(this, e);
  return t.__proto__ = r.prototype, t;
};
ze.prototype = Object.create(Error.prototype);
ze.prototype.constructor = ze;
ze.prototype.name = "TransformError";
const bt = /* @__PURE__ */ Object.create(null);
class k {
  /**
  Initialize a selection with the head and anchor and ranges. If no
  ranges are given, constructs a single range across `$anchor` and
  `$head`.
  */
  constructor(e, t, n) {
    this.$anchor = e, this.$head = t, this.ranges = n || [new vo(e.min(t), e.max(t))];
  }
  /**
  The selection's anchor, as an unresolved position.
  */
  get anchor() {
    return this.$anchor.pos;
  }
  /**
  The selection's head.
  */
  get head() {
    return this.$head.pos;
  }
  /**
  The lower bound of the selection's main range.
  */
  get from() {
    return this.$from.pos;
  }
  /**
  The upper bound of the selection's main range.
  */
  get to() {
    return this.$to.pos;
  }
  /**
  The resolved lower  bound of the selection's main range.
  */
  get $from() {
    return this.ranges[0].$from;
  }
  /**
  The resolved upper bound of the selection's main range.
  */
  get $to() {
    return this.ranges[0].$to;
  }
  /**
  Indicates whether the selection contains any content.
  */
  get empty() {
    let e = this.ranges;
    for (let t = 0; t < e.length; t++)
      if (e[t].$from.pos != e[t].$to.pos)
        return !1;
    return !0;
  }
  /**
  Get the content of this selection as a slice.
  */
  content() {
    return this.$from.doc.slice(this.from, this.to, !0);
  }
  /**
  Replace the selection with a slice or, if no slice is given,
  delete the selection. Will append to the given transaction.
  */
  replace(e, t = w.empty) {
    let n = t.content.lastChild, i = null;
    for (let a = 0; a < t.openEnd; a++)
      i = n, n = n.lastChild;
    let o = e.steps.length, s = this.ranges;
    for (let a = 0; a < s.length; a++) {
      let { $from: l, $to: c } = s[a], d = e.mapping.slice(o);
      e.replaceRange(d.map(l.pos), d.map(c.pos), a ? w.empty : t), a == 0 && gn(e, o, (n ? n.isInline : i && i.isTextblock) ? -1 : 1);
    }
  }
  /**
  Replace the selection with the given node, appending the changes
  to the given transaction.
  */
  replaceWith(e, t) {
    let n = e.steps.length, i = this.ranges;
    for (let o = 0; o < i.length; o++) {
      let { $from: s, $to: a } = i[o], l = e.mapping.slice(n), c = l.map(s.pos), d = l.map(a.pos);
      o ? e.deleteRange(c, d) : (e.replaceRangeWith(c, d, t), gn(e, n, t.isInline ? -1 : 1));
    }
  }
  /**
  Find a valid cursor or leaf node selection starting at the given
  position and searching back if `dir` is negative, and forward if
  positive. When `textOnly` is true, only consider cursor
  selections. Will return null when no valid selection position is
  found.
  */
  static findFrom(e, t, n = !1) {
    let i = e.parent.inlineContent ? new C(e) : fe(e.node(0), e.parent, e.pos, e.index(), t, n);
    if (i)
      return i;
    for (let o = e.depth - 1; o >= 0; o--) {
      let s = t < 0 ? fe(e.node(0), e.node(o), e.before(o + 1), e.index(o), t, n) : fe(e.node(0), e.node(o), e.after(o + 1), e.index(o) + 1, t, n);
      if (s)
        return s;
    }
    return null;
  }
  /**
  Find a valid cursor or leaf node selection near the given
  position. Searches forward first by default, but if `bias` is
  negative, it will search backwards first.
  */
  static near(e, t = 1) {
    return this.findFrom(e, t) || this.findFrom(e, -t) || new H(e.node(0));
  }
  /**
  Find the cursor or leaf node selection closest to the start of
  the given document. Will return an
  [`AllSelection`](https://prosemirror.net/docs/ref/#state.AllSelection) if no valid position
  exists.
  */
  static atStart(e) {
    return fe(e, e, 0, 0, 1) || new H(e);
  }
  /**
  Find the cursor or leaf node selection closest to the end of the
  given document.
  */
  static atEnd(e) {
    return fe(e, e, e.content.size, e.childCount, -1) || new H(e);
  }
  /**
  Deserialize the JSON representation of a selection. Must be
  implemented for custom classes (as a static class method).
  */
  static fromJSON(e, t) {
    if (!t || !t.type)
      throw new RangeError("Invalid input for Selection.fromJSON");
    let n = bt[t.type];
    if (!n)
      throw new RangeError(`No selection type ${t.type} defined`);
    return n.fromJSON(e, t);
  }
  /**
  To be able to deserialize selections from JSON, custom selection
  classes must register themselves with an ID string, so that they
  can be disambiguated. Try to pick something that's unlikely to
  clash with classes from other modules.
  */
  static jsonID(e, t) {
    if (e in bt)
      throw new RangeError("Duplicate use of selection JSON ID " + e);
    return bt[e] = t, t.prototype.jsonID = e, t;
  }
  /**
  Get a [bookmark](https://prosemirror.net/docs/ref/#state.SelectionBookmark) for this selection,
  which is a value that can be mapped without having access to a
  current document, and later resolved to a real selection for a
  given document again. (This is used mostly by the history to
  track and restore old selections.) The default implementation of
  this method just converts the selection to a text selection and
  returns the bookmark for that.
  */
  getBookmark() {
    return C.between(this.$anchor, this.$head).getBookmark();
  }
}
k.prototype.visible = !0;
class vo {
  /**
  Create a range.
  */
  constructor(e, t) {
    this.$from = e, this.$to = t;
  }
}
let hn = !1;
function mn(r) {
  !hn && !r.parent.inlineContent && (hn = !0, console.warn("TextSelection endpoint not pointing into a node with inline content (" + r.parent.type.name + ")"));
}
class C extends k {
  /**
  Construct a text selection between the given points.
  */
  constructor(e, t = e) {
    mn(e), mn(t), super(e, t);
  }
  /**
  Returns a resolved position if this is a cursor selection (an
  empty text selection), and null otherwise.
  */
  get $cursor() {
    return this.$anchor.pos == this.$head.pos ? this.$head : null;
  }
  map(e, t) {
    let n = e.resolve(t.map(this.head));
    if (!n.parent.inlineContent)
      return k.near(n);
    let i = e.resolve(t.map(this.anchor));
    return new C(i.parent.inlineContent ? i : n, n);
  }
  replace(e, t = w.empty) {
    if (super.replace(e, t), t == w.empty) {
      let n = this.$from.marksAcross(this.$to);
      n && e.ensureMarks(n);
    }
  }
  eq(e) {
    return e instanceof C && e.anchor == this.anchor && e.head == this.head;
  }
  getBookmark() {
    return new lt(this.anchor, this.head);
  }
  toJSON() {
    return { type: "text", anchor: this.anchor, head: this.head };
  }
  /**
  @internal
  */
  static fromJSON(e, t) {
    if (typeof t.anchor != "number" || typeof t.head != "number")
      throw new RangeError("Invalid input for TextSelection.fromJSON");
    return new C(e.resolve(t.anchor), e.resolve(t.head));
  }
  /**
  Create a text selection from non-resolved positions.
  */
  static create(e, t, n = t) {
    let i = e.resolve(t);
    return new this(i, n == t ? i : e.resolve(n));
  }
  /**
  Return a text selection that spans the given positions or, if
  they aren't text positions, find a text selection near them.
  `bias` determines whether the method searches forward (default)
  or backwards (negative number) first. Will fall back to calling
  [`Selection.near`](https://prosemirror.net/docs/ref/#state.Selection^near) when the document
  doesn't contain a valid text position.
  */
  static between(e, t, n) {
    let i = e.pos - t.pos;
    if ((!n || i) && (n = i >= 0 ? 1 : -1), !t.parent.inlineContent) {
      let o = k.findFrom(t, n, !0) || k.findFrom(t, -n, !0);
      if (o)
        t = o.$head;
      else
        return k.near(t, n);
    }
    return e.parent.inlineContent || (i == 0 ? e = t : (e = (k.findFrom(e, -n, !0) || k.findFrom(e, n, !0)).$anchor, e.pos < t.pos != i < 0 && (e = t))), new C(e, t);
  }
}
k.jsonID("text", C);
class lt {
  constructor(e, t) {
    this.anchor = e, this.head = t;
  }
  map(e) {
    return new lt(e.map(this.anchor), e.map(this.head));
  }
  resolve(e) {
    return C.between(e.resolve(this.anchor), e.resolve(this.head));
  }
}
class S extends k {
  /**
  Create a node selection. Does not verify the validity of its
  argument.
  */
  constructor(e) {
    let t = e.nodeAfter, n = e.node(0).resolve(e.pos + t.nodeSize);
    super(e, n), this.node = t;
  }
  map(e, t) {
    let { deleted: n, pos: i } = t.mapResult(this.anchor), o = e.resolve(i);
    return n ? k.near(o) : new S(o);
  }
  content() {
    return new w(x.from(this.node), 0, 0);
  }
  eq(e) {
    return e instanceof S && e.anchor == this.anchor;
  }
  toJSON() {
    return { type: "node", anchor: this.anchor };
  }
  getBookmark() {
    return new Bt(this.anchor);
  }
  /**
  @internal
  */
  static fromJSON(e, t) {
    if (typeof t.anchor != "number")
      throw new RangeError("Invalid input for NodeSelection.fromJSON");
    return new S(e.resolve(t.anchor));
  }
  /**
  Create a node selection from non-resolved positions.
  */
  static create(e, t) {
    return new S(e.resolve(t));
  }
  /**
  Determines whether the given node may be selected as a node
  selection.
  */
  static isSelectable(e) {
    return !e.isText && e.type.spec.selectable !== !1;
  }
}
S.prototype.visible = !1;
k.jsonID("node", S);
class Bt {
  constructor(e) {
    this.anchor = e;
  }
  map(e) {
    let { deleted: t, pos: n } = e.mapResult(this.anchor);
    return t ? new lt(n, n) : new Bt(n);
  }
  resolve(e) {
    let t = e.resolve(this.anchor), n = t.nodeAfter;
    return n && S.isSelectable(n) ? new S(t) : k.near(t);
  }
}
class H extends k {
  /**
  Create an all-selection over the given document.
  */
  constructor(e) {
    super(e.resolve(0), e.resolve(e.content.size));
  }
  replace(e, t = w.empty) {
    if (t == w.empty) {
      e.delete(0, e.doc.content.size);
      let n = k.atStart(e.doc);
      n.eq(e.selection) || e.setSelection(n);
    } else
      super.replace(e, t);
  }
  toJSON() {
    return { type: "all" };
  }
  /**
  @internal
  */
  static fromJSON(e) {
    return new H(e);
  }
  map(e) {
    return new H(e);
  }
  eq(e) {
    return e instanceof H;
  }
  getBookmark() {
    return wo;
  }
}
k.jsonID("all", H);
const wo = {
  map() {
    return this;
  },
  resolve(r) {
    return new H(r);
  }
};
function fe(r, e, t, n, i, o = !1) {
  if (e.inlineContent)
    return C.create(r, t);
  for (let s = n - (i > 0 ? 0 : 1); i > 0 ? s < e.childCount : s >= 0; s += i) {
    let a = e.child(s);
    if (a.isAtom) {
      if (!o && S.isSelectable(a))
        return S.create(r, t - (i < 0 ? a.nodeSize : 0));
    } else {
      let l = fe(r, a, t + i, i < 0 ? a.childCount : 0, i, o);
      if (l)
        return l;
    }
    t += a.nodeSize * i;
  }
  return null;
}
function gn(r, e, t) {
  let n = r.steps.length - 1;
  if (n < e)
    return;
  let i = r.steps[n];
  if (!(i instanceof L || i instanceof P))
    return;
  let o = r.mapping.maps[n], s;
  o.forEach((a, l, c, d) => {
    s == null && (s = d);
  }), r.setSelection(k.near(r.doc.resolve(s), t));
}
function bn(r, e) {
  return !e || !r ? r : r.bind(e);
}
class Je {
  constructor(e, t, n) {
    this.name = e, this.init = bn(t.init, n), this.apply = bn(t.apply, n);
  }
}
new Je("doc", {
  init(r) {
    return r.doc || r.schema.topNodeType.createAndFill();
  },
  apply(r) {
    return r.doc;
  }
}), new Je("selection", {
  init(r, e) {
    return r.selection || k.atStart(e.doc);
  },
  apply(r) {
    return r.selection;
  }
}), new Je("storedMarks", {
  init(r) {
    return r.storedMarks || null;
  },
  apply(r, e, t, n) {
    return n.selection.$cursor ? r.storedMarks : null;
  }
}), new Je("scrollToSelection", {
  init() {
    return 0;
  },
  apply(r, e) {
    return r.scrolledIntoView ? e + 1 : e;
  }
});
function cr(r, e, t) {
  for (let n in r) {
    let i = r[n];
    i instanceof Function ? i = i.bind(e) : n == "handleDOMEvents" && (i = cr(i, e, {})), t[n] = i;
  }
  return t;
}
class ue {
  /**
  Create a plugin.
  */
  constructor(e) {
    this.spec = e, this.props = {}, e.props && cr(e.props, this, this.props), this.key = e.key ? e.key.key : dr("plugin");
  }
  /**
  Extract the plugin's state field from an editor state.
  */
  getState(e) {
    return e[this.key];
  }
}
const yt = /* @__PURE__ */ Object.create(null);
function dr(r) {
  return r in yt ? r + "$" + ++yt[r] : (yt[r] = 0, r + "$");
}
class pe {
  /**
  Create a plugin key.
  */
  constructor(e = "key") {
    this.key = dr(e);
  }
  /**
  Get the active plugin with this key, if any, from an editor
  state.
  */
  get(e) {
    return e.config.pluginsByKey[this.key];
  }
  /**
  Get the plugin's state from an editor state.
  */
  getState(e) {
    return e[this.key];
  }
}
const Ft = (r, e) => r.selection.empty ? !1 : (e && e(r.tr.deleteSelection().scrollIntoView()), !0);
function ur(r, e) {
  let { $cursor: t } = r.selection;
  return !t || (e ? !e.endOfTextblock("backward", r) : t.parentOffset > 0) ? null : t;
}
const pr = (r, e, t) => {
  let n = ur(r, t);
  if (!n)
    return !1;
  let i = Lt(n);
  if (!i) {
    let s = n.blockRange(), a = s && xe(s);
    return a == null ? !1 : (e && e(r.tr.lift(s, a).scrollIntoView()), !0);
  }
  let o = i.nodeBefore;
  if (wr(r, i, e, -1))
    return !0;
  if (n.parent.content.size == 0 && (be(o, "end") || S.isSelectable(o)))
    for (let s = n.depth; ; s--) {
      let a = zt(r.doc, n.before(s), n.after(s), w.empty);
      if (a && a.slice.size < a.to - a.from) {
        if (e) {
          let l = r.tr.step(a);
          l.setSelection(be(o, "end") ? k.findFrom(l.doc.resolve(l.mapping.map(i.pos, -1)), -1) : S.create(l.doc, i.pos - o.nodeSize)), e(l.scrollIntoView());
        }
        return !0;
      }
      if (s == 1 || n.node(s - 1).childCount > 1)
        break;
    }
  return o.isAtom && i.depth == n.depth - 1 ? (e && e(r.tr.delete(i.pos - o.nodeSize, i.pos).scrollIntoView()), !0) : !1;
}, ko = (r, e, t) => {
  let n = ur(r, t);
  if (!n)
    return !1;
  let i = Lt(n);
  return i ? fr(r, i, e) : !1;
}, So = (r, e, t) => {
  let n = mr(r, t);
  if (!n)
    return !1;
  let i = Pt(n);
  return i ? fr(r, i, e) : !1;
};
function fr(r, e, t) {
  let n = e.nodeBefore, i = n, o = e.pos - 1;
  for (; !i.isTextblock; o--) {
    if (i.type.spec.isolating)
      return !1;
    let d = i.lastChild;
    if (!d)
      return !1;
    i = d;
  }
  let s = e.nodeAfter, a = s, l = e.pos + 1;
  for (; !a.isTextblock; l++) {
    if (a.type.spec.isolating)
      return !1;
    let d = a.firstChild;
    if (!d)
      return !1;
    a = d;
  }
  let c = zt(r.doc, o, l, w.empty);
  if (!c || c.from != o || c instanceof L && c.slice.size >= l - o)
    return !1;
  if (t) {
    let d = r.tr.step(c);
    d.setSelection(C.create(d.doc, o)), t(d.scrollIntoView());
  }
  return !0;
}
function be(r, e, t = !1) {
  for (let n = r; n; n = e == "start" ? n.firstChild : n.lastChild) {
    if (n.isTextblock)
      return !0;
    if (t && n.childCount != 1)
      return !1;
  }
  return !1;
}
const hr = (r, e, t) => {
  let { $head: n, empty: i } = r.selection, o = n;
  if (!i)
    return !1;
  if (n.parent.isTextblock) {
    if (t ? !t.endOfTextblock("backward", r) : n.parentOffset > 0)
      return !1;
    o = Lt(n);
  }
  let s = o && o.nodeBefore;
  return !s || !S.isSelectable(s) ? !1 : (e && e(r.tr.setSelection(S.create(r.doc, o.pos - s.nodeSize)).scrollIntoView()), !0);
};
function Lt(r) {
  if (!r.parent.type.spec.isolating)
    for (let e = r.depth - 1; e >= 0; e--) {
      if (r.index(e) > 0)
        return r.doc.resolve(r.before(e + 1));
      if (r.node(e).type.spec.isolating)
        break;
    }
  return null;
}
function mr(r, e) {
  let { $cursor: t } = r.selection;
  return !t || (e ? !e.endOfTextblock("forward", r) : t.parentOffset < t.parent.content.size) ? null : t;
}
const gr = (r, e, t) => {
  let n = mr(r, t);
  if (!n)
    return !1;
  let i = Pt(n);
  if (!i)
    return !1;
  let o = i.nodeAfter;
  if (wr(r, i, e, 1))
    return !0;
  if (n.parent.content.size == 0 && (be(o, "start") || S.isSelectable(o))) {
    let s = zt(r.doc, n.before(), n.after(), w.empty);
    if (s && s.slice.size < s.to - s.from) {
      if (e) {
        let a = r.tr.step(s);
        a.setSelection(be(o, "start") ? k.findFrom(a.doc.resolve(a.mapping.map(i.pos)), 1) : S.create(a.doc, a.mapping.map(i.pos))), e(a.scrollIntoView());
      }
      return !0;
    }
  }
  return o.isAtom && i.depth == n.depth - 1 ? (e && e(r.tr.delete(i.pos, i.pos + o.nodeSize).scrollIntoView()), !0) : !1;
}, br = (r, e, t) => {
  let { $head: n, empty: i } = r.selection, o = n;
  if (!i)
    return !1;
  if (n.parent.isTextblock) {
    if (t ? !t.endOfTextblock("forward", r) : n.parentOffset < n.parent.content.size)
      return !1;
    o = Pt(n);
  }
  let s = o && o.nodeAfter;
  return !s || !S.isSelectable(s) ? !1 : (e && e(r.tr.setSelection(S.create(r.doc, o.pos)).scrollIntoView()), !0);
};
function Pt(r) {
  if (!r.parent.type.spec.isolating)
    for (let e = r.depth - 1; e >= 0; e--) {
      let t = r.node(e);
      if (r.index(e) + 1 < t.childCount)
        return r.doc.resolve(r.after(e + 1));
      if (t.type.spec.isolating)
        break;
    }
  return null;
}
const No = (r, e) => {
  let t = r.selection, n = t instanceof S, i;
  if (n) {
    if (t.node.isTextblock || !de(r.doc, t.from))
      return !1;
    i = t.from;
  } else if (i = at(r.doc, t.from, -1), i == null)
    return !1;
  if (e) {
    let o = r.tr.join(i);
    n && o.setSelection(S.create(o.doc, i - r.doc.resolve(i).nodeBefore.nodeSize)), e(o.scrollIntoView());
  }
  return !0;
}, Co = (r, e) => {
  let t = r.selection, n;
  if (t instanceof S) {
    if (t.node.isTextblock || !de(r.doc, t.to))
      return !1;
    n = t.to;
  } else if (n = at(r.doc, t.to, 1), n == null)
    return !1;
  return e && e(r.tr.join(n).scrollIntoView()), !0;
}, Eo = (r, e) => {
  let { $from: t, $to: n } = r.selection, i = t.blockRange(n), o = i && xe(i);
  return o == null ? !1 : (e && e(r.tr.lift(i, o).scrollIntoView()), !0);
}, yr = (r, e) => {
  let { $head: t, $anchor: n } = r.selection;
  return !t.parent.type.spec.code || !t.sameParent(n) ? !1 : (e && e(r.tr.insertText(`
`).scrollIntoView()), !0);
};
function $t(r) {
  for (let e = 0; e < r.edgeCount; e++) {
    let { type: t } = r.edge(e);
    if (t.isTextblock && !t.hasRequiredAttrs())
      return t;
  }
  return null;
}
const _o = (r, e) => {
  let { $head: t, $anchor: n } = r.selection;
  if (!t.parent.type.spec.code || !t.sameParent(n))
    return !1;
  let i = t.node(-1), o = t.indexAfter(-1), s = $t(i.contentMatchAt(o));
  if (!s || !i.canReplaceWith(o, o, s))
    return !1;
  if (e) {
    let a = t.after(), l = r.tr.replaceWith(a, a, s.createAndFill());
    l.setSelection(k.near(l.doc.resolve(a), 1)), e(l.scrollIntoView());
  }
  return !0;
}, xr = (r, e) => {
  let t = r.selection, { $from: n, $to: i } = t;
  if (t instanceof H || n.parent.inlineContent || i.parent.inlineContent)
    return !1;
  let o = $t(i.parent.contentMatchAt(i.indexAfter()));
  if (!o || !o.isTextblock)
    return !1;
  if (e) {
    let s = (!n.parentOffset && i.index() < i.parent.childCount ? n : i).pos, a = r.tr.insert(s, o.createAndFill());
    a.setSelection(C.create(a.doc, s + 1)), e(a.scrollIntoView());
  }
  return !0;
}, vr = (r, e) => {
  let { $cursor: t } = r.selection;
  if (!t || t.parent.content.size)
    return !1;
  if (t.depth > 1 && t.after() != t.end(-1)) {
    let o = t.before();
    if (Y(r.doc, o))
      return e && e(r.tr.split(o).scrollIntoView()), !0;
  }
  let n = t.blockRange(), i = n && xe(n);
  return i == null ? !1 : (e && e(r.tr.lift(n, i).scrollIntoView()), !0);
};
function Mo(r) {
  return (e, t) => {
    let { $from: n, $to: i } = e.selection;
    if (e.selection instanceof S && e.selection.node.isBlock)
      return !n.parentOffset || !Y(e.doc, n.pos) ? !1 : (t && t(e.tr.split(n.pos).scrollIntoView()), !0);
    if (!n.depth)
      return !1;
    let o = [], s, a, l = !1, c = !1;
    for (let h = n.depth; ; h--)
      if (n.node(h).isBlock) {
        l = n.end(h) == n.pos + (n.depth - h), c = n.start(h) == n.pos - (n.depth - h), a = $t(n.node(h - 1).contentMatchAt(n.indexAfter(h - 1))), o.unshift(l && a ? { type: a } : null), s = h;
        break;
      } else {
        if (h == 1)
          return !1;
        o.unshift(null);
      }
    let d = e.tr;
    (e.selection instanceof C || e.selection instanceof H) && d.deleteSelection();
    let p = d.mapping.map(n.pos), f = Y(d.doc, p, o.length, o);
    if (f || (o[0] = a ? { type: a } : null, f = Y(d.doc, p, o.length, o)), !f)
      return !1;
    if (d.split(p, o.length, o), !l && c && n.node(s).type != a) {
      let h = d.mapping.map(n.before(s)), b = d.doc.resolve(h);
      a && n.node(s - 1).canReplaceWith(b.index(), b.index() + 1, a) && d.setNodeMarkup(d.mapping.map(n.before(s)), a);
    }
    return t && t(d.scrollIntoView()), !0;
  };
}
const Ao = Mo(), To = (r, e) => {
  let { $from: t, to: n } = r.selection, i, o = t.sharedDepth(n);
  return o == 0 ? !1 : (i = t.before(o), e && e(r.tr.setSelection(S.create(r.doc, i))), !0);
};
function Io(r, e, t) {
  let n = e.nodeBefore, i = e.nodeAfter, o = e.index();
  return !n || !i || !n.type.compatibleContent(i.type) ? !1 : !n.content.size && e.parent.canReplace(o - 1, o) ? (t && t(r.tr.delete(e.pos - n.nodeSize, e.pos).scrollIntoView()), !0) : !e.parent.canReplace(o, o + 1) || !(i.isTextblock || de(r.doc, e.pos)) ? !1 : (t && t(r.tr.join(e.pos).scrollIntoView()), !0);
}
function wr(r, e, t, n) {
  let i = e.nodeBefore, o = e.nodeAfter, s, a, l = i.type.spec.isolating || o.type.spec.isolating;
  if (!l && Io(r, e, t))
    return !0;
  let c = !l && e.parent.canReplace(e.index(), e.index() + 1);
  if (c && (s = (a = i.contentMatchAt(i.childCount)).findWrapping(o.type)) && a.matchType(s[0] || o.type).validEnd) {
    if (t) {
      let h = e.pos + o.nodeSize, b = x.empty;
      for (let v = s.length - 1; v >= 0; v--)
        b = x.from(s[v].create(null, b));
      b = x.from(i.copy(b));
      let m = r.tr.step(new P(e.pos - 1, h, e.pos, h, new w(b, 1, 0), s.length, !0)), y = m.doc.resolve(h + 2 * s.length);
      y.nodeAfter && y.nodeAfter.type == i.type && de(m.doc, y.pos) && m.join(y.pos), t(m.scrollIntoView());
    }
    return !0;
  }
  let d = o.type.spec.isolating || n > 0 && l ? null : k.findFrom(e, 1), p = d && d.$from.blockRange(d.$to), f = p && xe(p);
  if (f != null && f >= e.depth)
    return t && t(r.tr.lift(p, f).scrollIntoView()), !0;
  if (c && be(o, "start", !0) && be(i, "end")) {
    let h = i, b = [];
    for (; b.push(h), !h.isTextblock; )
      h = h.lastChild;
    let m = o, y = 1;
    for (; !m.isTextblock; m = m.firstChild)
      y++;
    if (h.canReplace(h.childCount, h.childCount, m.content)) {
      if (t) {
        let v = x.empty;
        for (let _ = b.length - 1; _ >= 0; _--)
          v = x.from(b[_].copy(v));
        let M = r.tr.step(new P(e.pos - b.length, e.pos + o.nodeSize, e.pos + y, e.pos + o.nodeSize - y, new w(v, b.length, 0), 0, !0));
        t(M.scrollIntoView());
      }
      return !0;
    }
  }
  return !1;
}
function kr(r) {
  return function(e, t) {
    let n = e.selection, i = r < 0 ? n.$from : n.$to, o = i.depth;
    for (; i.node(o).isInline; ) {
      if (!o)
        return !1;
      o--;
    }
    return i.node(o).isTextblock ? (t && t(e.tr.setSelection(C.create(e.doc, r < 0 ? i.start(o) : i.end(o)))), !0) : !1;
  };
}
const Oo = kr(-1), Ro = kr(1);
function zo(r, e = null) {
  return function(t, n) {
    let { $from: i, $to: o } = t.selection, s = i.blockRange(o), a = s && sr(s, r, e);
    return a ? (n && n(t.tr.wrap(s, a).scrollIntoView()), !0) : !1;
  };
}
function yn(r, e = null) {
  return function(t, n) {
    let i = !1;
    for (let o = 0; o < t.selection.ranges.length && !i; o++) {
      let { $from: { pos: s }, $to: { pos: a } } = t.selection.ranges[o];
      t.doc.nodesBetween(s, a, (l, c) => {
        if (i)
          return !1;
        if (!(!l.isTextblock || l.hasMarkup(r, e)))
          if (l.type == r)
            i = !0;
          else {
            let d = t.doc.resolve(c), p = d.index();
            i = d.parent.canReplaceWith(p, p + 1, r);
          }
      });
    }
    if (!i)
      return !1;
    if (n) {
      let o = t.tr;
      for (let s = 0; s < t.selection.ranges.length; s++) {
        let { $from: { pos: a }, $to: { pos: l } } = t.selection.ranges[s];
        o.setBlockType(a, l, r, e);
      }
      n(o.scrollIntoView());
    }
    return !0;
  };
}
function Dt(...r) {
  return function(e, t, n) {
    for (let i = 0; i < r.length; i++)
      if (r[i](e, t, n))
        return !0;
    return !1;
  };
}
Dt(Ft, pr, hr);
Dt(Ft, gr, br);
Dt(yr, xr, vr, Ao);
typeof navigator < "u" ? /Mac|iP(hone|[oa]d)/.test(navigator.platform) : typeof os < "u" && os.platform && os.platform() == "darwin";
function Bo(r, e = null) {
  return function(t, n) {
    let { $from: i, $to: o } = t.selection, s = i.blockRange(o);
    if (!s)
      return !1;
    let a = n ? t.tr : null;
    return Fo(a, s, r, e) ? (n && n(a.scrollIntoView()), !0) : !1;
  };
}
function Fo(r, e, t, n = null) {
  let i = !1, o = e, s = e.$from.doc;
  if (e.depth >= 2 && e.$from.node(e.depth - 1).type.compatibleContent(t) && e.startIndex == 0) {
    if (e.$from.index(e.depth - 1) == 0)
      return !1;
    let l = s.resolve(e.start - 2);
    o = new Ze(l, l, e.depth), e.endIndex < e.parent.childCount && (e = new Ze(e.$from, s.resolve(e.$to.end(e.depth)), e.depth)), i = !0;
  }
  let a = sr(o, t, n, e);
  return a ? (r && Lo(r, e, a, i, t), !0) : !1;
}
function Lo(r, e, t, n, i) {
  let o = x.empty;
  for (let d = t.length - 1; d >= 0; d--)
    o = x.from(t[d].type.create(t[d].attrs, o));
  r.step(new P(e.start - (n ? 2 : 0), e.end, e.start, e.end, new w(o, 0, 0), t.length, !0));
  let s = 0;
  for (let d = 0; d < t.length; d++)
    t[d].type == i && (s = d + 1);
  let a = t.length - s, l = e.start + t.length - (n ? 2 : 0), c = e.parent;
  for (let d = e.startIndex, p = e.endIndex, f = !0; d < p; d++, f = !1)
    !f && Y(r.doc, l, a) && (r.split(l, a), l += 2 * a), l += c.child(d).nodeSize;
  return r;
}
function Po(r) {
  return function(e, t) {
    let { $from: n, $to: i } = e.selection, o = n.blockRange(i, (s) => s.childCount > 0 && s.firstChild.type == r);
    return o ? t ? n.node(o.depth - 1).type == r ? $o(e, t, r, o) : Do(e, t, o) : !0 : !1;
  };
}
function $o(r, e, t, n) {
  let i = r.tr, o = n.end, s = n.$to.end(n.depth);
  o < s && (i.step(new P(o - 1, s, o, s, new w(x.from(t.create(null, n.parent.copy())), 1, 0), 1, !0)), n = new Ze(i.doc.resolve(n.$from.pos), i.doc.resolve(s), n.depth));
  const a = xe(n);
  if (a == null)
    return !1;
  i.lift(n, a);
  let l = i.doc.resolve(i.mapping.map(o, -1) - 1);
  return de(i.doc, l.pos) && l.nodeBefore.type == l.nodeAfter.type && i.join(l.pos), e(i.scrollIntoView()), !0;
}
function Do(r, e, t) {
  let n = r.tr, i = t.parent;
  for (let h = t.end, b = t.endIndex - 1, m = t.startIndex; b > m; b--)
    h -= i.child(b).nodeSize, n.delete(h - 1, h + 1);
  let o = n.doc.resolve(t.start), s = o.nodeAfter;
  if (n.mapping.map(t.end) != t.start + o.nodeAfter.nodeSize)
    return !1;
  let a = t.startIndex == 0, l = t.endIndex == i.childCount, c = o.node(-1), d = o.index(-1);
  if (!c.canReplace(d + (a ? 0 : 1), d + 1, s.content.append(l ? x.empty : x.from(i))))
    return !1;
  let p = o.pos, f = p + s.nodeSize;
  return n.step(new P(p - (a ? 1 : 0), f + (l ? 1 : 0), p + 1, f - 1, new w((a ? x.empty : x.from(i.copy(x.empty))).append(l ? x.empty : x.from(i.copy(x.empty))), a ? 0 : 1, l ? 0 : 1), a ? 0 : 1)), e(n.scrollIntoView()), !0;
}
function jo(r) {
  return function(e, t) {
    let { $from: n, $to: i } = e.selection, o = n.blockRange(i, (c) => c.childCount > 0 && c.firstChild.type == r);
    if (!o)
      return !1;
    let s = o.startIndex;
    if (s == 0)
      return !1;
    let a = o.parent, l = a.child(s - 1);
    if (l.type != r)
      return !1;
    if (t) {
      let c = l.lastChild && l.lastChild.type == a.type, d = x.from(c ? r.create() : null), p = new w(x.from(r.create(null, x.from(a.type.create(null, d)))), c ? 3 : 1, 0), f = o.start, h = o.end;
      t(e.tr.step(new P(f - (c ? 3 : 1), h, f, h, p, 1, !0)).scrollIntoView());
    }
    return !0;
  };
}
function Sr(r) {
  const { state: e, transaction: t } = r;
  let { selection: n } = t, { doc: i } = t, { storedMarks: o } = t;
  return {
    ...e,
    apply: e.apply.bind(e),
    applyTransaction: e.applyTransaction.bind(e),
    plugins: e.plugins,
    schema: e.schema,
    reconfigure: e.reconfigure.bind(e),
    toJSON: e.toJSON.bind(e),
    get storedMarks() {
      return o;
    },
    get selection() {
      return n;
    },
    get doc() {
      return i;
    },
    get tr() {
      return n = t.selection, i = t.doc, o = t.storedMarks, t;
    }
  };
}
class Ho {
  constructor(e) {
    this.editor = e.editor, this.rawCommands = this.editor.extensionManager.commands, this.customState = e.state;
  }
  get hasCustomState() {
    return !!this.customState;
  }
  get state() {
    return this.customState || this.editor.state;
  }
  get commands() {
    const { rawCommands: e, editor: t, state: n } = this, { view: i } = t, { tr: o } = n, s = this.buildProps(o);
    return Object.fromEntries(Object.entries(e).map(([a, l]) => [a, (...d) => {
      const p = l(...d)(s);
      return !o.getMeta("preventDispatch") && !this.hasCustomState && i.dispatch(o), p;
    }]));
  }
  get chain() {
    return () => this.createChain();
  }
  get can() {
    return () => this.createCan();
  }
  createChain(e, t = !0) {
    const { rawCommands: n, editor: i, state: o } = this, { view: s } = i, a = [], l = !!e, c = e || o.tr, d = () => (!l && t && !c.getMeta("preventDispatch") && !this.hasCustomState && s.dispatch(c), a.every((f) => f === !0)), p = {
      ...Object.fromEntries(Object.entries(n).map(([f, h]) => [f, (...m) => {
        const y = this.buildProps(c, t), v = h(...m)(y);
        return a.push(v), p;
      }])),
      run: d
    };
    return p;
  }
  createCan(e) {
    const { rawCommands: t, state: n } = this, i = !1, o = e || n.tr, s = this.buildProps(o, i);
    return {
      ...Object.fromEntries(Object.entries(t).map(([l, c]) => [l, (...d) => c(...d)({ ...s, dispatch: void 0 })])),
      chain: () => this.createChain(o, i)
    };
  }
  buildProps(e, t = !0) {
    const { rawCommands: n, editor: i, state: o } = this, { view: s } = i, a = {
      tr: e,
      editor: i,
      view: s,
      state: Sr({
        state: o,
        transaction: e
      }),
      dispatch: t ? () => {
      } : void 0,
      chain: () => this.createChain(e, t),
      can: () => this.createCan(e),
      get commands() {
        return Object.fromEntries(Object.entries(n).map(([l, c]) => [l, (...d) => c(...d)(a)]));
      }
    };
    return a;
  }
}
function V(r, e, t) {
  return r.config[e] === void 0 && r.parent ? V(r.parent, e, t) : typeof r.config[e] == "function" ? r.config[e].bind({
    ...t,
    parent: r.parent ? V(r.parent, e, t) : null
  }) : r.config[e];
}
function Uo(r) {
  const e = r.filter((i) => i.type === "extension"), t = r.filter((i) => i.type === "node"), n = r.filter((i) => i.type === "mark");
  return {
    baseExtensions: e,
    nodeExtensions: t,
    markExtensions: n
  };
}
function z(r, e) {
  if (typeof r == "string") {
    if (!e.nodes[r])
      throw Error(`There is no node type named '${r}'. Maybe you forgot to add the extension?`);
    return e.nodes[r];
  }
  return r;
}
function Nr(...r) {
  return r.filter((e) => !!e).reduce((e, t) => {
    const n = { ...e };
    return Object.entries(t).forEach(([i, o]) => {
      if (!n[i]) {
        n[i] = o;
        return;
      }
      if (i === "class") {
        const a = o ? String(o).split(" ") : [], l = n[i] ? n[i].split(" ") : [], c = a.filter((d) => !l.includes(d));
        n[i] = [...l, ...c].join(" ");
      } else if (i === "style") {
        const a = o ? o.split(";").map((d) => d.trim()).filter(Boolean) : [], l = n[i] ? n[i].split(";").map((d) => d.trim()).filter(Boolean) : [], c = /* @__PURE__ */ new Map();
        l.forEach((d) => {
          const [p, f] = d.split(":").map((h) => h.trim());
          c.set(p, f);
        }), a.forEach((d) => {
          const [p, f] = d.split(":").map((h) => h.trim());
          c.set(p, f);
        }), n[i] = Array.from(c.entries()).map(([d, p]) => `${d}: ${p}`).join("; ");
      } else
        n[i] = o;
    }), n;
  }, {});
}
function Jo(r, e) {
  return e.filter((t) => t.type === r.type.name).filter((t) => t.attribute.rendered).map((t) => t.attribute.renderHTML ? t.attribute.renderHTML(r.attrs) || {} : {
    [t.name]: r.attrs[t.name]
  }).reduce((t, n) => Nr(t, n), {});
}
function Vo(r) {
  return typeof r == "function";
}
function G(r, e = void 0, ...t) {
  return Vo(r) ? e ? r.bind(e)(...t) : r(...t) : r;
}
function Wo(r) {
  return Object.prototype.toString.call(r) === "[object RegExp]";
}
function qo(r) {
  return Object.prototype.toString.call(r).slice(8, -1);
}
function Ve(r) {
  return qo(r) !== "Object" ? !1 : r.constructor === Object && Object.getPrototypeOf(r) === Object.prototype;
}
function jt(r, e) {
  const t = { ...r };
  return Ve(r) && Ve(e) && Object.keys(e).forEach((n) => {
    Ve(e[n]) && Ve(r[n]) ? t[n] = jt(r[n], e[n]) : t[n] = e[n];
  }), t;
}
class W {
  constructor(e = {}) {
    this.type = "extension", this.name = "extension", this.parent = null, this.child = null, this.config = {
      name: this.name,
      defaultOptions: {}
    }, this.config = {
      ...this.config,
      ...e
    }, this.name = this.config.name, e.defaultOptions && Object.keys(e.defaultOptions).length > 0 && console.warn(`[tiptap warn]: BREAKING CHANGE: "defaultOptions" is deprecated. Please use "addOptions" instead. Found in extension: "${this.name}".`), this.options = this.config.defaultOptions, this.config.addOptions && (this.options = G(V(this, "addOptions", {
      name: this.name
    }))), this.storage = G(V(this, "addStorage", {
      name: this.name,
      options: this.options
    })) || {};
  }
  static create(e = {}) {
    return new W(e);
  }
  configure(e = {}) {
    const t = this.extend({
      ...this.config,
      addOptions: () => jt(this.options, e)
    });
    return t.name = this.name, t.parent = this.parent, t;
  }
  extend(e = {}) {
    const t = new W({ ...this.config, ...e });
    return t.parent = this, this.child = t, t.name = e.name ? e.name : t.parent.name, e.defaultOptions && Object.keys(e.defaultOptions).length > 0 && console.warn(`[tiptap warn]: BREAKING CHANGE: "defaultOptions" is deprecated. Please use "addOptions" instead. Found in extension: "${t.name}".`), t.options = G(V(t, "addOptions", {
      name: t.name
    })), t.storage = G(V(t, "addStorage", {
      name: t.name,
      options: t.options
    })), t;
  }
}
function Ko(r, e, t) {
  const { from: n, to: i } = e, { blockSeparator: o = `

`, textSerializers: s = {} } = t || {};
  let a = "";
  return r.nodesBetween(n, i, (l, c, d, p) => {
    var f;
    l.isBlock && c > n && (a += o);
    const h = s == null ? void 0 : s[l.type.name];
    if (h)
      return d && (a += h({
        node: l,
        pos: c,
        parent: d,
        index: p,
        range: e
      })), !1;
    l.isText && (a += (f = l == null ? void 0 : l.text) === null || f === void 0 ? void 0 : f.slice(Math.max(n, c) - c, i - c));
  }), a;
}
function Go(r) {
  return Object.fromEntries(Object.entries(r.nodes).filter(([, e]) => e.spec.toText).map(([e, t]) => [e, t.spec.toText]));
}
W.create({
  name: "clipboardTextSerializer",
  addOptions() {
    return {
      blockSeparator: void 0
    };
  },
  addProseMirrorPlugins() {
    return [
      new ue({
        key: new pe("clipboardTextSerializer"),
        props: {
          clipboardTextSerializer: () => {
            const { editor: r } = this, { state: e, schema: t } = r, { doc: n, selection: i } = e, { ranges: o } = i, s = Math.min(...o.map((d) => d.$from.pos)), a = Math.max(...o.map((d) => d.$to.pos)), l = Go(t);
            return Ko(n, { from: s, to: a }, {
              ...this.options.blockSeparator !== void 0 ? { blockSeparator: this.options.blockSeparator } : {},
              textSerializers: l
            });
          }
        }
      })
    ];
  }
});
const Yo = () => ({ editor: r, view: e }) => (requestAnimationFrame(() => {
  var t;
  r.isDestroyed || (e.dom.blur(), (t = window == null ? void 0 : window.getSelection()) === null || t === void 0 || t.removeAllRanges());
}), !0), Xo = (r = !1) => ({ commands: e }) => e.setContent("", r), Qo = () => ({ state: r, tr: e, dispatch: t }) => {
  const { selection: n } = e, { ranges: i } = n;
  return t && i.forEach(({ $from: o, $to: s }) => {
    r.doc.nodesBetween(o.pos, s.pos, (a, l) => {
      if (a.type.isText)
        return;
      const { doc: c, mapping: d } = e, p = c.resolve(d.map(l)), f = c.resolve(d.map(l + a.nodeSize)), h = p.blockRange(f);
      if (!h)
        return;
      const b = xe(h);
      if (a.type.isTextblock) {
        const { defaultType: m } = p.parent.contentMatchAt(p.index());
        e.setNodeMarkup(h.start, m);
      }
      (b || b === 0) && e.lift(h, b);
    });
  }), !0;
}, Zo = (r) => (e) => r(e), es = () => ({ state: r, dispatch: e }) => xr(r, e), ts = (r, e) => ({ editor: t, tr: n }) => {
  const { state: i } = t, o = i.doc.slice(r.from, r.to);
  n.deleteRange(r.from, r.to);
  const s = n.mapping.map(e);
  return n.insert(s, o.content), n.setSelection(new C(n.doc.resolve(Math.max(s - 1, 0)))), !0;
}, ns = () => ({ tr: r, dispatch: e }) => {
  const { selection: t } = r, n = t.$anchor.node();
  if (n.content.size > 0)
    return !1;
  const i = r.selection.$anchor;
  for (let o = i.depth; o > 0; o -= 1)
    if (i.node(o).type === n.type) {
      if (e) {
        const a = i.before(o), l = i.after(o);
        r.delete(a, l).scrollIntoView();
      }
      return !0;
    }
  return !1;
}, rs = (r) => ({ tr: e, state: t, dispatch: n }) => {
  const i = z(r, t.schema), o = e.selection.$anchor;
  for (let s = o.depth; s > 0; s -= 1)
    if (o.node(s).type === i) {
      if (n) {
        const l = o.before(s), c = o.after(s);
        e.delete(l, c).scrollIntoView();
      }
      return !0;
    }
  return !1;
}, is = (r) => ({ tr: e, dispatch: t }) => {
  const { from: n, to: i } = r;
  return t && e.delete(n, i), !0;
}, ss = () => ({ state: r, dispatch: e }) => Ft(r, e), as = () => ({ commands: r }) => r.keyboardShortcut("Enter"), ls = () => ({ state: r, dispatch: e }) => _o(r, e);
function rt(r, e, t = { strict: !0 }) {
  const n = Object.keys(e);
  return n.length ? n.every((i) => t.strict ? e[i] === r[i] : Wo(e[i]) ? e[i].test(r[i]) : e[i] === r[i]) : !0;
}
function Cr(r, e, t = {}) {
  return r.find((n) => n.type === e && rt(
    // Only check equality for the attributes that are provided
    Object.fromEntries(Object.keys(t).map((i) => [i, n.attrs[i]])),
    t
  ));
}
function xn(r, e, t = {}) {
  return !!Cr(r, e, t);
}
function Er(r, e, t) {
  var n;
  if (!r || !e)
    return;
  let i = r.parent.childAfter(r.parentOffset);
  if ((!i.node || !i.node.marks.some((d) => d.type === e)) && (i = r.parent.childBefore(r.parentOffset)), !i.node || !i.node.marks.some((d) => d.type === e) || (t = t || ((n = i.node.marks[0]) === null || n === void 0 ? void 0 : n.attrs), !Cr([...i.node.marks], e, t)))
    return;
  let s = i.index, a = r.start() + i.offset, l = s + 1, c = a + i.node.nodeSize;
  for (; s > 0 && xn([...r.parent.child(s - 1).marks], e, t); )
    s -= 1, a -= r.parent.child(s).nodeSize;
  for (; l < r.parent.childCount && xn([...r.parent.child(l).marks], e, t); )
    c += r.parent.child(l).nodeSize, l += 1;
  return {
    from: a,
    to: c
  };
}
function te(r, e) {
  if (typeof r == "string") {
    if (!e.marks[r])
      throw Error(`There is no mark type named '${r}'. Maybe you forgot to add the extension?`);
    return e.marks[r];
  }
  return r;
}
const cs = (r, e = {}) => ({ tr: t, state: n, dispatch: i }) => {
  const o = te(r, n.schema), { doc: s, selection: a } = t, { $from: l, from: c, to: d } = a;
  if (i) {
    const p = Er(l, o, e);
    if (p && p.from <= c && p.to >= d) {
      const f = C.create(s, p.from, p.to);
      t.setSelection(f);
    }
  }
  return !0;
}, ds = (r) => (e) => {
  const t = typeof r == "function" ? r(e) : r;
  for (let n = 0; n < t.length; n += 1)
    if (t[n](e))
      return !0;
  return !1;
};
function _r(r) {
  return r instanceof C;
}
function oe(r = 0, e = 0, t = 0) {
  return Math.min(Math.max(r, e), t);
}
function us(r, e = null) {
  if (!e)
    return null;
  const t = k.atStart(r), n = k.atEnd(r);
  if (e === "start" || e === !0)
    return t;
  if (e === "end")
    return n;
  const i = t.from, o = n.to;
  return e === "all" ? C.create(r, oe(0, i, o), oe(r.content.size, i, o)) : C.create(r, oe(e, i, o), oe(e, i, o));
}
function Mt() {
  return navigator.platform === "Android" || /android/i.test(navigator.userAgent);
}
function Be() {
  return [
    "iPad Simulator",
    "iPhone Simulator",
    "iPod Simulator",
    "iPad",
    "iPhone",
    "iPod"
  ].includes(navigator.platform) || navigator.userAgent.includes("Mac") && "ontouchend" in document;
}
function ps() {
  return typeof navigator < "u" ? /^((?!chrome|android).)*safari/i.test(navigator.userAgent) : !1;
}
const fs = (r = null, e = {}) => ({ editor: t, view: n, tr: i, dispatch: o }) => {
  e = {
    scrollIntoView: !0,
    ...e
  };
  const s = () => {
    (Be() || Mt()) && n.dom.focus(), requestAnimationFrame(() => {
      t.isDestroyed || (n.focus(), ps() && !Be() && !Mt() && n.dom.focus({ preventScroll: !0 }));
    });
  };
  if (n.hasFocus() && r === null || r === !1)
    return !0;
  if (o && r === null && !_r(t.state.selection))
    return s(), !0;
  const a = us(i.doc, r) || t.state.selection, l = t.state.selection.eq(a);
  return o && (l || i.setSelection(a), l && i.storedMarks && i.setStoredMarks(i.storedMarks), s()), !0;
}, hs = (r, e) => (t) => r.every((n, i) => e(n, { ...t, index: i })), ms = (r, e) => ({ tr: t, commands: n }) => n.insertContentAt({ from: t.selection.from, to: t.selection.to }, r, e), Mr = (r) => {
  const e = r.childNodes;
  for (let t = e.length - 1; t >= 0; t -= 1) {
    const n = e[t];
    n.nodeType === 3 && n.nodeValue && /^(\n\s\s|\n)$/.test(n.nodeValue) ? r.removeChild(n) : n.nodeType === 1 && Mr(n);
  }
  return r;
};
function We(r) {
  const e = `<body>${r}</body>`, t = new window.DOMParser().parseFromString(e, "text/html").body;
  return Mr(t);
}
function Fe(r, e, t) {
  if (r instanceof le || r instanceof x)
    return r;
  t = {
    slice: !0,
    parseOptions: {},
    ...t
  };
  const n = typeof r == "object" && r !== null, i = typeof r == "string";
  if (n)
    try {
      if (Array.isArray(r) && r.length > 0)
        return x.fromArray(r.map((a) => e.nodeFromJSON(a)));
      const s = e.nodeFromJSON(r);
      return t.errorOnInvalidContent && s.check(), s;
    } catch (o) {
      if (t.errorOnInvalidContent)
        throw new Error("[tiptap error]: Invalid JSON content", { cause: o });
      return console.warn("[tiptap warn]: Invalid content.", "Passed value:", r, "Error:", o), Fe("", e, t);
    }
  if (i) {
    if (t.errorOnInvalidContent) {
      let s = !1, a = "";
      const l = new io({
        topNode: e.spec.topNode,
        marks: e.spec.marks,
        // Prosemirror's schemas are executed such that: the last to execute, matches last
        // This means that we can add a catch-all node at the end of the schema to catch any content that we don't know how to handle
        nodes: e.spec.nodes.append({
          __tiptap__private__unknown__catch__all__node: {
            content: "inline*",
            group: "block",
            parseDOM: [
              {
                tag: "*",
                getAttrs: (c) => (s = !0, a = typeof c == "string" ? c : c.outerHTML, null)
              }
            ]
          }
        })
      });
      if (t.slice ? me.fromSchema(l).parseSlice(We(r), t.parseOptions) : me.fromSchema(l).parse(We(r), t.parseOptions), t.errorOnInvalidContent && s)
        throw new Error("[tiptap error]: Invalid HTML content", { cause: new Error(`Invalid element found: ${a}`) });
    }
    const o = me.fromSchema(e);
    return t.slice ? o.parseSlice(We(r), t.parseOptions).content : o.parse(We(r), t.parseOptions);
  }
  return Fe("", e, t);
}
function gs(r, e, t) {
  const n = r.steps.length - 1;
  if (n < e)
    return;
  const i = r.steps[n];
  if (!(i instanceof L || i instanceof P))
    return;
  const o = r.mapping.maps[n];
  let s = 0;
  o.forEach((a, l, c, d) => {
    s === 0 && (s = d);
  }), r.setSelection(k.near(r.doc.resolve(s), t));
}
const bs = (r) => !("type" in r), ys = (r, e, t) => ({ tr: n, dispatch: i, editor: o }) => {
  var s;
  if (i) {
    t = {
      parseOptions: o.options.parseOptions,
      updateSelection: !0,
      applyInputRules: !1,
      applyPasteRules: !1,
      ...t
    };
    let a;
    const l = (y) => {
      o.emit("contentError", {
        editor: o,
        error: y,
        disableCollaboration: () => {
          o.storage.collaboration && (o.storage.collaboration.isDisabled = !0);
        }
      });
    }, c = {
      preserveWhitespace: "full",
      ...t.parseOptions
    };
    if (!t.errorOnInvalidContent && !o.options.enableContentCheck && o.options.emitContentError)
      try {
        Fe(e, o.schema, {
          parseOptions: c,
          errorOnInvalidContent: !0
        });
      } catch (y) {
        l(y);
      }
    try {
      a = Fe(e, o.schema, {
        parseOptions: c,
        errorOnInvalidContent: (s = t.errorOnInvalidContent) !== null && s !== void 0 ? s : o.options.enableContentCheck
      });
    } catch (y) {
      return l(y), !1;
    }
    let { from: d, to: p } = typeof r == "number" ? { from: r, to: r } : { from: r.from, to: r.to }, f = !0, h = !0;
    if ((bs(a) ? a : [a]).forEach((y) => {
      y.check(), f = f ? y.isText && y.marks.length === 0 : !1, h = h ? y.isBlock : !1;
    }), d === p && h) {
      const { parent: y } = n.doc.resolve(d);
      y.isTextblock && !y.type.spec.code && !y.childCount && (d -= 1, p += 1);
    }
    let m;
    if (f) {
      if (Array.isArray(e))
        m = e.map((y) => y.text || "").join("");
      else if (e instanceof x) {
        let y = "";
        e.forEach((v) => {
          v.text && (y += v.text);
        }), m = y;
      } else typeof e == "object" && e && e.text ? m = e.text : m = e;
      n.insertText(m, d, p);
    } else
      m = a, n.replaceWith(d, p, m);
    t.updateSelection && gs(n, n.steps.length - 1, -1), t.applyInputRules && n.setMeta("applyInputRules", { from: d, text: m }), t.applyPasteRules && n.setMeta("applyPasteRules", { from: d, text: m });
  }
  return !0;
}, xs = () => ({ state: r, dispatch: e }) => No(r, e), vs = () => ({ state: r, dispatch: e }) => Co(r, e), ws = () => ({ state: r, dispatch: e }) => pr(r, e), ks = () => ({ state: r, dispatch: e }) => gr(r, e), Ss = () => ({ state: r, dispatch: e, tr: t }) => {
  try {
    const n = at(r.doc, r.selection.$from.pos, -1);
    return n == null ? !1 : (t.join(n, 2), e && e(t), !0);
  } catch {
    return !1;
  }
}, Ns = () => ({ state: r, dispatch: e, tr: t }) => {
  try {
    const n = at(r.doc, r.selection.$from.pos, 1);
    return n == null ? !1 : (t.join(n, 2), e && e(t), !0);
  } catch {
    return !1;
  }
}, Cs = () => ({ state: r, dispatch: e }) => ko(r, e), Es = () => ({ state: r, dispatch: e }) => So(r, e);
function Ar() {
  return typeof navigator < "u" ? /Mac/.test(navigator.platform) : !1;
}
function _s(r) {
  const e = r.split(/-(?!$)/);
  let t = e[e.length - 1];
  t === "Space" && (t = " ");
  let n, i, o, s;
  for (let a = 0; a < e.length - 1; a += 1) {
    const l = e[a];
    if (/^(cmd|meta|m)$/i.test(l))
      s = !0;
    else if (/^a(lt)?$/i.test(l))
      n = !0;
    else if (/^(c|ctrl|control)$/i.test(l))
      i = !0;
    else if (/^s(hift)?$/i.test(l))
      o = !0;
    else if (/^mod$/i.test(l))
      Be() || Ar() ? s = !0 : i = !0;
    else
      throw new Error(`Unrecognized modifier name: ${l}`);
  }
  return n && (t = `Alt-${t}`), i && (t = `Ctrl-${t}`), s && (t = `Meta-${t}`), o && (t = `Shift-${t}`), t;
}
const Ms = (r) => ({ editor: e, view: t, tr: n, dispatch: i }) => {
  const o = _s(r).split(/-(?!$)/), s = o.find((c) => !["Alt", "Ctrl", "Meta", "Shift"].includes(c)), a = new KeyboardEvent("keydown", {
    key: s === "Space" ? " " : s,
    altKey: o.includes("Alt"),
    ctrlKey: o.includes("Ctrl"),
    metaKey: o.includes("Meta"),
    shiftKey: o.includes("Shift"),
    bubbles: !0,
    cancelable: !0
  }), l = e.captureTransaction(() => {
    t.someProp("handleKeyDown", (c) => c(t, a));
  });
  return l == null || l.steps.forEach((c) => {
    const d = c.map(n.mapping);
    d && i && n.maybeStep(d);
  }), !0;
};
function Ht(r, e, t = {}) {
  const { from: n, to: i, empty: o } = r.selection, s = e ? z(e, r.schema) : null, a = [];
  r.doc.nodesBetween(n, i, (p, f) => {
    if (p.isText)
      return;
    const h = Math.max(n, f), b = Math.min(i, f + p.nodeSize);
    a.push({
      node: p,
      from: h,
      to: b
    });
  });
  const l = i - n, c = a.filter((p) => s ? s.name === p.node.type.name : !0).filter((p) => rt(p.node.attrs, t, { strict: !1 }));
  return o ? !!c.length : c.reduce((p, f) => p + f.to - f.from, 0) >= l;
}
const As = (r, e = {}) => ({ state: t, dispatch: n }) => {
  const i = z(r, t.schema);
  return Ht(t, i, e) ? Eo(t, n) : !1;
}, Ts = () => ({ state: r, dispatch: e }) => vr(r, e), Is = (r) => ({ state: e, dispatch: t }) => {
  const n = z(r, e.schema);
  return Po(n)(e, t);
}, Os = () => ({ state: r, dispatch: e }) => yr(r, e);
function Tr(r, e) {
  return e.nodes[r] ? "node" : e.marks[r] ? "mark" : null;
}
function vn(r, e) {
  const t = typeof e == "string" ? [e] : e;
  return Object.keys(r).reduce((n, i) => (t.includes(i) || (n[i] = r[i]), n), {});
}
const Rs = (r, e) => ({ tr: t, state: n, dispatch: i }) => {
  let o = null, s = null;
  const a = Tr(typeof r == "string" ? r : r.name, n.schema);
  return a ? (a === "node" && (o = z(r, n.schema)), a === "mark" && (s = te(r, n.schema)), i && t.selection.ranges.forEach((l) => {
    n.doc.nodesBetween(l.$from.pos, l.$to.pos, (c, d) => {
      o && o === c.type && t.setNodeMarkup(d, void 0, vn(c.attrs, e)), s && c.marks.length && c.marks.forEach((p) => {
        s === p.type && t.addMark(d, d + c.nodeSize, s.create(vn(p.attrs, e)));
      });
    });
  }), !0) : !1;
}, zs = () => ({ tr: r, dispatch: e }) => (e && r.scrollIntoView(), !0), Bs = () => ({ tr: r, dispatch: e }) => {
  if (e) {
    const t = new H(r.doc);
    r.setSelection(t);
  }
  return !0;
}, Fs = () => ({ state: r, dispatch: e }) => hr(r, e), Ls = () => ({ state: r, dispatch: e }) => br(r, e), Ps = () => ({ state: r, dispatch: e }) => To(r, e), $s = () => ({ state: r, dispatch: e }) => Ro(r, e), Ds = () => ({ state: r, dispatch: e }) => Oo(r, e);
function js(r, e, t = {}, n = {}) {
  return Fe(r, e, {
    slice: !1,
    parseOptions: t,
    errorOnInvalidContent: n.errorOnInvalidContent
  });
}
const Hs = (r, e = !1, t = {}, n = {}) => ({ editor: i, tr: o, dispatch: s, commands: a }) => {
  var l, c;
  const { doc: d } = o;
  if (t.preserveWhitespace !== "full") {
    const p = js(r, i.schema, t, {
      errorOnInvalidContent: (l = n.errorOnInvalidContent) !== null && l !== void 0 ? l : i.options.enableContentCheck
    });
    return s && o.replaceWith(0, d.content.size, p).setMeta("preventUpdate", !e), !0;
  }
  return s && o.setMeta("preventUpdate", !e), a.insertContentAt({ from: 0, to: d.content.size }, r, {
    parseOptions: t,
    errorOnInvalidContent: (c = n.errorOnInvalidContent) !== null && c !== void 0 ? c : i.options.enableContentCheck
  });
};
function Us(r, e) {
  const t = te(e, r.schema), { from: n, to: i, empty: o } = r.selection, s = [];
  o ? (r.storedMarks && s.push(...r.storedMarks), s.push(...r.selection.$head.marks())) : r.doc.nodesBetween(n, i, (l) => {
    s.push(...l.marks);
  });
  const a = s.find((l) => l.type.name === t.name);
  return a ? { ...a.attrs } : {};
}
function Js(r) {
  for (let e = 0; e < r.edgeCount; e += 1) {
    const { type: t } = r.edge(e);
    if (t.isTextblock && !t.hasRequiredAttrs())
      return t;
  }
  return null;
}
function Vs(r, e) {
  for (let t = r.depth; t > 0; t -= 1) {
    const n = r.node(t);
    if (e(n))
      return {
        pos: t > 0 ? r.before(t) : 0,
        start: r.start(t),
        depth: t,
        node: n
      };
  }
}
function Ut(r) {
  return (e) => Vs(e.$from, r);
}
function Ke(r, e, t) {
  return Object.fromEntries(Object.entries(t).filter(([n]) => {
    const i = r.find((o) => o.type === e && o.name === n);
    return i ? i.attribute.keepOnSplit : !1;
  }));
}
function Ws(r, e, t = {}) {
  const { empty: n, ranges: i } = r.selection, o = e ? te(e, r.schema) : null;
  if (n)
    return !!(r.storedMarks || r.selection.$from.marks()).filter((p) => o ? o.name === p.type.name : !0).find((p) => rt(p.attrs, t, { strict: !1 }));
  let s = 0;
  const a = [];
  if (i.forEach(({ $from: p, $to: f }) => {
    const h = p.pos, b = f.pos;
    r.doc.nodesBetween(h, b, (m, y) => {
      if (!m.isText && !m.marks.length)
        return;
      const v = Math.max(h, y), M = Math.min(b, y + m.nodeSize), _ = M - v;
      s += _, a.push(...m.marks.map((R) => ({
        mark: R,
        from: v,
        to: M
      })));
    });
  }), s === 0)
    return !1;
  const l = a.filter((p) => o ? o.name === p.mark.type.name : !0).filter((p) => rt(p.mark.attrs, t, { strict: !1 })).reduce((p, f) => p + f.to - f.from, 0), c = a.filter((p) => o ? p.mark.type !== o && p.mark.type.excludes(o) : !0).reduce((p, f) => p + f.to - f.from, 0);
  return (l > 0 ? l + c : l) >= s;
}
function wn(r, e) {
  const { nodeExtensions: t } = Uo(e), n = t.find((s) => s.name === r);
  if (!n)
    return !1;
  const i = {
    name: n.name,
    options: n.options,
    storage: n.storage
  }, o = G(V(n, "group", i));
  return typeof o != "string" ? !1 : o.split(" ").includes("list");
}
function Ir(r, { checkChildren: e = !0, ignoreWhitespace: t = !1 } = {}) {
  var n;
  if (t) {
    if (r.type.name === "hardBreak")
      return !0;
    if (r.isText)
      return /^\s*$/m.test((n = r.text) !== null && n !== void 0 ? n : "");
  }
  if (r.isText)
    return !r.text;
  if (r.isAtom || r.isLeaf)
    return !1;
  if (r.content.childCount === 0)
    return !0;
  if (e) {
    let i = !0;
    return r.content.forEach((o) => {
      i !== !1 && (Ir(o, { ignoreWhitespace: t, checkChildren: e }) || (i = !1));
    }), i;
  }
  return !1;
}
function qs(r, e, t) {
  var n;
  const { selection: i } = e;
  let o = null;
  if (_r(i) && (o = i.$cursor), o) {
    const a = (n = r.storedMarks) !== null && n !== void 0 ? n : o.marks();
    return !!t.isInSet(a) || !a.some((l) => l.type.excludes(t));
  }
  const { ranges: s } = i;
  return s.some(({ $from: a, $to: l }) => {
    let c = a.depth === 0 ? r.doc.inlineContent && r.doc.type.allowsMarkType(t) : !1;
    return r.doc.nodesBetween(a.pos, l.pos, (d, p, f) => {
      if (c)
        return !1;
      if (d.isInline) {
        const h = !f || f.type.allowsMarkType(t), b = !!t.isInSet(d.marks) || !d.marks.some((m) => m.type.excludes(t));
        c = h && b;
      }
      return !c;
    }), c;
  });
}
const Ks = (r, e = {}) => ({ tr: t, state: n, dispatch: i }) => {
  const { selection: o } = t, { empty: s, ranges: a } = o, l = te(r, n.schema);
  if (i)
    if (s) {
      const c = Us(n, l);
      t.addStoredMark(l.create({
        ...c,
        ...e
      }));
    } else
      a.forEach((c) => {
        const d = c.$from.pos, p = c.$to.pos;
        n.doc.nodesBetween(d, p, (f, h) => {
          const b = Math.max(h, d), m = Math.min(h + f.nodeSize, p);
          f.marks.find((v) => v.type === l) ? f.marks.forEach((v) => {
            l === v.type && t.addMark(b, m, l.create({
              ...v.attrs,
              ...e
            }));
          }) : t.addMark(b, m, l.create(e));
        });
      });
  return qs(n, t, l);
}, Gs = (r, e) => ({ tr: t }) => (t.setMeta(r, e), !0), Ys = (r, e = {}) => ({ state: t, dispatch: n, chain: i }) => {
  const o = z(r, t.schema);
  let s;
  return t.selection.$anchor.sameParent(t.selection.$head) && (s = t.selection.$anchor.parent.attrs), o.isTextblock ? i().command(({ commands: a }) => yn(o, { ...s, ...e })(t) ? !0 : a.clearNodes()).command(({ state: a }) => yn(o, { ...s, ...e })(a, n)).run() : (console.warn('[tiptap warn]: Currently "setNode()" only supports text block nodes.'), !1);
}, Xs = (r) => ({ tr: e, dispatch: t }) => {
  if (t) {
    const { doc: n } = e, i = oe(r, 0, n.content.size), o = S.create(n, i);
    e.setSelection(o);
  }
  return !0;
}, Qs = (r) => ({ tr: e, dispatch: t }) => {
  if (t) {
    const { doc: n } = e, { from: i, to: o } = typeof r == "number" ? { from: r, to: r } : r, s = C.atStart(n).from, a = C.atEnd(n).to, l = oe(i, s, a), c = oe(o, s, a), d = C.create(n, l, c);
    e.setSelection(d);
  }
  return !0;
}, Zs = (r) => ({ state: e, dispatch: t }) => {
  const n = z(r, e.schema);
  return jo(n)(e, t);
};
function kn(r, e) {
  const t = r.storedMarks || r.selection.$to.parentOffset && r.selection.$from.marks();
  if (t) {
    const n = t.filter((i) => e == null ? void 0 : e.includes(i.type.name));
    r.tr.ensureMarks(n);
  }
}
const ea = ({ keepMarks: r = !0 } = {}) => ({ tr: e, state: t, dispatch: n, editor: i }) => {
  const { selection: o, doc: s } = e, { $from: a, $to: l } = o, c = i.extensionManager.attributes, d = Ke(c, a.node().type.name, a.node().attrs);
  if (o instanceof S && o.node.isBlock)
    return !a.parentOffset || !Y(s, a.pos) ? !1 : (n && (r && kn(t, i.extensionManager.splittableMarks), e.split(a.pos).scrollIntoView()), !0);
  if (!a.parent.isBlock)
    return !1;
  const p = l.parentOffset === l.parent.content.size, f = a.depth === 0 ? void 0 : Js(a.node(-1).contentMatchAt(a.indexAfter(-1)));
  let h = p && f ? [
    {
      type: f,
      attrs: d
    }
  ] : void 0, b = Y(e.doc, e.mapping.map(a.pos), 1, h);
  if (!h && !b && Y(e.doc, e.mapping.map(a.pos), 1, f ? [{ type: f }] : void 0) && (b = !0, h = f ? [
    {
      type: f,
      attrs: d
    }
  ] : void 0), n) {
    if (b && (o instanceof C && e.deleteSelection(), e.split(e.mapping.map(a.pos), 1, h), f && !p && !a.parentOffset && a.parent.type !== f)) {
      const m = e.mapping.map(a.before()), y = e.doc.resolve(m);
      a.node(-1).canReplaceWith(y.index(), y.index() + 1, f) && e.setNodeMarkup(e.mapping.map(a.before()), f);
    }
    r && kn(t, i.extensionManager.splittableMarks), e.scrollIntoView();
  }
  return b;
}, ta = (r, e = {}) => ({ tr: t, state: n, dispatch: i, editor: o }) => {
  var s;
  const a = z(r, n.schema), { $from: l, $to: c } = n.selection, d = n.selection.node;
  if (d && d.isBlock || l.depth < 2 || !l.sameParent(c))
    return !1;
  const p = l.node(-1);
  if (p.type !== a)
    return !1;
  const f = o.extensionManager.attributes;
  if (l.parent.content.size === 0 && l.node(-1).childCount === l.indexAfter(-1)) {
    if (l.depth === 2 || l.node(-3).type !== a || l.index(-2) !== l.node(-2).childCount - 1)
      return !1;
    if (i) {
      let v = x.empty;
      const M = l.index(-1) ? 1 : l.index(-2) ? 2 : 3;
      for (let U = l.depth - M; U >= l.depth - 3; U -= 1)
        v = x.from(l.node(U).copy(v));
      const _ = l.indexAfter(-1) < l.node(-2).childCount ? 1 : l.indexAfter(-2) < l.node(-3).childCount ? 2 : 3, R = {
        ...Ke(f, l.node().type.name, l.node().attrs),
        ...e
      }, F = ((s = a.contentMatch.defaultType) === null || s === void 0 ? void 0 : s.createAndFill(R)) || void 0;
      v = v.append(x.from(a.createAndFill(null, F) || void 0));
      const T = l.before(l.depth - (M - 1));
      t.replace(T, l.after(-_), new w(v, 4 - M, 0));
      let $ = -1;
      t.doc.nodesBetween(T, t.doc.content.size, (U, Br) => {
        if ($ > -1)
          return !1;
        U.isTextblock && U.content.size === 0 && ($ = Br + 1);
      }), $ > -1 && t.setSelection(C.near(t.doc.resolve($))), t.scrollIntoView();
    }
    return !0;
  }
  const h = c.pos === l.end() ? p.contentMatchAt(0).defaultType : null, b = {
    ...Ke(f, p.type.name, p.attrs),
    ...e
  }, m = {
    ...Ke(f, l.node().type.name, l.node().attrs),
    ...e
  };
  t.delete(l.pos, c.pos);
  const y = h ? [
    { type: a, attrs: b },
    { type: h, attrs: m }
  ] : [{ type: a, attrs: b }];
  if (!Y(t.doc, l.pos, 2))
    return !1;
  if (i) {
    const { selection: v, storedMarks: M } = n, { splittableMarks: _ } = o.extensionManager, R = M || v.$to.parentOffset && v.$from.marks();
    if (t.split(l.pos, 2, y).scrollIntoView(), !R || !i)
      return !0;
    const F = R.filter((T) => _.includes(T.type.name));
    t.ensureMarks(F);
  }
  return !0;
}, xt = (r, e) => {
  const t = Ut((s) => s.type === e)(r.selection);
  if (!t)
    return !0;
  const n = r.doc.resolve(Math.max(0, t.pos - 1)).before(t.depth);
  if (n === void 0)
    return !0;
  const i = r.doc.nodeAt(n);
  return t.node.type === (i == null ? void 0 : i.type) && de(r.doc, t.pos) && r.join(t.pos), !0;
}, vt = (r, e) => {
  const t = Ut((s) => s.type === e)(r.selection);
  if (!t)
    return !0;
  const n = r.doc.resolve(t.start).after(t.depth);
  if (n === void 0)
    return !0;
  const i = r.doc.nodeAt(n);
  return t.node.type === (i == null ? void 0 : i.type) && de(r.doc, n) && r.join(n), !0;
}, na = (r, e, t, n = {}) => ({ editor: i, tr: o, state: s, dispatch: a, chain: l, commands: c, can: d }) => {
  const { extensions: p, splittableMarks: f } = i.extensionManager, h = z(r, s.schema), b = z(e, s.schema), { selection: m, storedMarks: y } = s, { $from: v, $to: M } = m, _ = v.blockRange(M), R = y || m.$to.parentOffset && m.$from.marks();
  if (!_)
    return !1;
  const F = Ut((T) => wn(T.type.name, p))(m);
  if (_.depth >= 1 && F && _.depth - F.depth <= 1) {
    if (F.node.type === h)
      return c.liftListItem(b);
    if (wn(F.node.type.name, p) && h.validContent(F.node.content) && a)
      return l().command(() => (o.setNodeMarkup(F.pos, h), !0)).command(() => xt(o, h)).command(() => vt(o, h)).run();
  }
  return !t || !R || !a ? l().command(() => d().wrapInList(h, n) ? !0 : c.clearNodes()).wrapInList(h, n).command(() => xt(o, h)).command(() => vt(o, h)).run() : l().command(() => {
    const T = d().wrapInList(h, n), $ = R.filter((U) => f.includes(U.type.name));
    return o.ensureMarks($), T ? !0 : c.clearNodes();
  }).wrapInList(h, n).command(() => xt(o, h)).command(() => vt(o, h)).run();
}, ra = (r, e = {}, t = {}) => ({ state: n, commands: i }) => {
  const { extendEmptyMarkRange: o = !1 } = t, s = te(r, n.schema);
  return Ws(n, s, e) ? i.unsetMark(s, { extendEmptyMarkRange: o }) : i.setMark(s, e);
}, ia = (r, e, t = {}) => ({ state: n, commands: i }) => {
  const o = z(r, n.schema), s = z(e, n.schema), a = Ht(n, o, t);
  let l;
  return n.selection.$anchor.sameParent(n.selection.$head) && (l = n.selection.$anchor.parent.attrs), a ? i.setNode(s, l) : i.setNode(o, { ...l, ...t });
}, oa = (r, e = {}) => ({ state: t, commands: n }) => {
  const i = z(r, t.schema);
  return Ht(t, i, e) ? n.lift(i) : n.wrapIn(i, e);
}, sa = () => ({ state: r, dispatch: e }) => {
  const t = r.plugins;
  for (let n = 0; n < t.length; n += 1) {
    const i = t[n];
    let o;
    if (i.spec.isInputRules && (o = i.getState(r))) {
      if (e) {
        const s = r.tr, a = o.transform;
        for (let l = a.steps.length - 1; l >= 0; l -= 1)
          s.step(a.steps[l].invert(a.docs[l]));
        if (o.text) {
          const l = s.doc.resolve(o.from).marks();
          s.replaceWith(o.from, o.to, r.schema.text(o.text, l));
        } else
          s.delete(o.from, o.to);
      }
      return !0;
    }
  }
  return !1;
}, aa = () => ({ tr: r, dispatch: e }) => {
  const { selection: t } = r, { empty: n, ranges: i } = t;
  return n || e && i.forEach((o) => {
    r.removeMark(o.$from.pos, o.$to.pos);
  }), !0;
}, la = (r, e = {}) => ({ tr: t, state: n, dispatch: i }) => {
  var o;
  const { extendEmptyMarkRange: s = !1 } = e, { selection: a } = t, l = te(r, n.schema), { $from: c, empty: d, ranges: p } = a;
  if (!i)
    return !0;
  if (d && s) {
    let { from: f, to: h } = a;
    const b = (o = c.marks().find((y) => y.type === l)) === null || o === void 0 ? void 0 : o.attrs, m = Er(c, l, b);
    m && (f = m.from, h = m.to), t.removeMark(f, h, l);
  } else
    p.forEach((f) => {
      t.removeMark(f.$from.pos, f.$to.pos, l);
    });
  return t.removeStoredMark(l), !0;
}, ca = (r, e = {}) => ({ tr: t, state: n, dispatch: i }) => {
  let o = null, s = null;
  const a = Tr(typeof r == "string" ? r : r.name, n.schema);
  return a ? (a === "node" && (o = z(r, n.schema)), a === "mark" && (s = te(r, n.schema)), i && t.selection.ranges.forEach((l) => {
    const c = l.$from.pos, d = l.$to.pos;
    let p, f, h, b;
    t.selection.empty ? n.doc.nodesBetween(c, d, (m, y) => {
      o && o === m.type && (h = Math.max(y, c), b = Math.min(y + m.nodeSize, d), p = y, f = m);
    }) : n.doc.nodesBetween(c, d, (m, y) => {
      y < c && o && o === m.type && (h = Math.max(y, c), b = Math.min(y + m.nodeSize, d), p = y, f = m), y >= c && y <= d && (o && o === m.type && t.setNodeMarkup(y, void 0, {
        ...m.attrs,
        ...e
      }), s && m.marks.length && m.marks.forEach((v) => {
        if (s === v.type) {
          const M = Math.max(y, c), _ = Math.min(y + m.nodeSize, d);
          t.addMark(M, _, s.create({
            ...v.attrs,
            ...e
          }));
        }
      }));
    }), f && (p !== void 0 && t.setNodeMarkup(p, void 0, {
      ...f.attrs,
      ...e
    }), s && f.marks.length && f.marks.forEach((m) => {
      s === m.type && t.addMark(h, b, s.create({
        ...m.attrs,
        ...e
      }));
    }));
  }), !0) : !1;
}, da = (r, e = {}) => ({ state: t, dispatch: n }) => {
  const i = z(r, t.schema);
  return zo(i, e)(t, n);
}, ua = (r, e = {}) => ({ state: t, dispatch: n }) => {
  const i = z(r, t.schema);
  return Bo(i, e)(t, n);
};
var pa = /* @__PURE__ */ Object.freeze({
  __proto__: null,
  blur: Yo,
  clearContent: Xo,
  clearNodes: Qo,
  command: Zo,
  createParagraphNear: es,
  cut: ts,
  deleteCurrentNode: ns,
  deleteNode: rs,
  deleteRange: is,
  deleteSelection: ss,
  enter: as,
  exitCode: ls,
  extendMarkRange: cs,
  first: ds,
  focus: fs,
  forEach: hs,
  insertContent: ms,
  insertContentAt: ys,
  joinBackward: ws,
  joinDown: vs,
  joinForward: ks,
  joinItemBackward: Ss,
  joinItemForward: Ns,
  joinTextblockBackward: Cs,
  joinTextblockForward: Es,
  joinUp: xs,
  keyboardShortcut: Ms,
  lift: As,
  liftEmptyBlock: Ts,
  liftListItem: Is,
  newlineInCode: Os,
  resetAttributes: Rs,
  scrollIntoView: zs,
  selectAll: Bs,
  selectNodeBackward: Fs,
  selectNodeForward: Ls,
  selectParentNode: Ps,
  selectTextblockEnd: $s,
  selectTextblockStart: Ds,
  setContent: Hs,
  setMark: Ks,
  setMeta: Gs,
  setNode: Ys,
  setNodeSelection: Xs,
  setTextSelection: Qs,
  sinkListItem: Zs,
  splitBlock: ea,
  splitListItem: ta,
  toggleList: na,
  toggleMark: ra,
  toggleNode: ia,
  toggleWrap: oa,
  undoInputRule: sa,
  unsetAllMarks: aa,
  unsetMark: la,
  updateAttributes: ca,
  wrapIn: da,
  wrapInList: ua
});
W.create({
  name: "commands",
  addCommands() {
    return {
      ...pa
    };
  }
});
W.create({
  name: "drop",
  addProseMirrorPlugins() {
    return [
      new ue({
        key: new pe("tiptapDrop"),
        props: {
          handleDrop: (r, e, t, n) => {
            this.editor.emit("drop", {
              editor: this.editor,
              event: e,
              slice: t,
              moved: n
            });
          }
        }
      })
    ];
  }
});
W.create({
  name: "editable",
  addProseMirrorPlugins() {
    return [
      new ue({
        key: new pe("editable"),
        props: {
          editable: () => this.editor.options.editable
        }
      })
    ];
  }
});
const fa = new pe("focusEvents");
W.create({
  name: "focusEvents",
  addProseMirrorPlugins() {
    const { editor: r } = this;
    return [
      new ue({
        key: fa,
        props: {
          handleDOMEvents: {
            focus: (e, t) => {
              r.isFocused = !0;
              const n = r.state.tr.setMeta("focus", { event: t }).setMeta("addToHistory", !1);
              return e.dispatch(n), !1;
            },
            blur: (e, t) => {
              r.isFocused = !1;
              const n = r.state.tr.setMeta("blur", { event: t }).setMeta("addToHistory", !1);
              return e.dispatch(n), !1;
            }
          }
        }
      })
    ];
  }
});
W.create({
  name: "keymap",
  addKeyboardShortcuts() {
    const r = () => this.editor.commands.first(({ commands: s }) => [
      () => s.undoInputRule(),
      // maybe convert first text block node to default node
      () => s.command(({ tr: a }) => {
        const { selection: l, doc: c } = a, { empty: d, $anchor: p } = l, { pos: f, parent: h } = p, b = p.parent.isTextblock && f > 0 ? a.doc.resolve(f - 1) : p, m = b.parent.type.spec.isolating, y = p.pos - p.parentOffset, v = m && b.parent.childCount === 1 ? y === p.pos : k.atStart(c).from === f;
        return !d || !h.type.isTextblock || h.textContent.length || !v || v && p.parent.type.name === "paragraph" ? !1 : s.clearNodes();
      }),
      () => s.deleteSelection(),
      () => s.joinBackward(),
      () => s.selectNodeBackward()
    ]), e = () => this.editor.commands.first(({ commands: s }) => [
      () => s.deleteSelection(),
      () => s.deleteCurrentNode(),
      () => s.joinForward(),
      () => s.selectNodeForward()
    ]), n = {
      Enter: () => this.editor.commands.first(({ commands: s }) => [
        () => s.newlineInCode(),
        () => s.createParagraphNear(),
        () => s.liftEmptyBlock(),
        () => s.splitBlock()
      ]),
      "Mod-Enter": () => this.editor.commands.exitCode(),
      Backspace: r,
      "Mod-Backspace": r,
      "Shift-Backspace": r,
      Delete: e,
      "Mod-Delete": e,
      "Mod-a": () => this.editor.commands.selectAll()
    }, i = {
      ...n
    }, o = {
      ...n,
      "Ctrl-h": r,
      "Alt-Backspace": r,
      "Ctrl-d": e,
      "Ctrl-Alt-Backspace": e,
      "Alt-Delete": e,
      "Alt-d": e,
      "Ctrl-a": () => this.editor.commands.selectTextblockStart(),
      "Ctrl-e": () => this.editor.commands.selectTextblockEnd()
    };
    return Be() || Ar() ? o : i;
  },
  addProseMirrorPlugins() {
    return [
      // With this plugin we check if the whole document was selected and deleted.
      // In this case we will additionally call `clearNodes()` to convert e.g. a heading
      // to a paragraph if necessary.
      // This is an alternative to ProseMirror's `AllSelection`, which doesn’t work well
      // with many other commands.
      new ue({
        key: new pe("clearDocument"),
        appendTransaction: (r, e, t) => {
          if (r.some((m) => m.getMeta("composition")))
            return;
          const n = r.some((m) => m.docChanged) && !e.doc.eq(t.doc), i = r.some((m) => m.getMeta("preventClearDocument"));
          if (!n || i)
            return;
          const { empty: o, from: s, to: a } = e.selection, l = k.atStart(e.doc).from, c = k.atEnd(e.doc).to;
          if (o || !(s === l && a === c) || !Ir(t.doc))
            return;
          const f = t.tr, h = Sr({
            state: t,
            transaction: f
          }), { commands: b } = new Ho({
            editor: this.editor,
            state: h
          });
          if (b.clearNodes(), !!f.steps.length)
            return f;
        }
      })
    ];
  }
});
W.create({
  name: "paste",
  addProseMirrorPlugins() {
    return [
      new ue({
        key: new pe("tiptapPaste"),
        props: {
          handlePaste: (r, e, t) => {
            this.editor.emit("paste", {
              editor: this.editor,
              event: e,
              slice: t
            });
          }
        }
      })
    ];
  }
});
W.create({
  name: "tabindex",
  addProseMirrorPlugins() {
    return [
      new ue({
        key: new pe("tabindex"),
        props: {
          attributes: () => this.editor.isEditable ? { tabindex: "0" } : {}
        }
      })
    ];
  }
});
class it {
  constructor(e = {}) {
    this.type = "node", this.name = "node", this.parent = null, this.child = null, this.config = {
      name: this.name,
      defaultOptions: {}
    }, this.config = {
      ...this.config,
      ...e
    }, this.name = this.config.name, e.defaultOptions && Object.keys(e.defaultOptions).length > 0 && console.warn(`[tiptap warn]: BREAKING CHANGE: "defaultOptions" is deprecated. Please use "addOptions" instead. Found in extension: "${this.name}".`), this.options = this.config.defaultOptions, this.config.addOptions && (this.options = G(V(this, "addOptions", {
      name: this.name
    }))), this.storage = G(V(this, "addStorage", {
      name: this.name,
      options: this.options
    })) || {};
  }
  static create(e = {}) {
    return new it(e);
  }
  configure(e = {}) {
    const t = this.extend({
      ...this.config,
      addOptions: () => jt(this.options, e)
    });
    return t.name = this.name, t.parent = this.parent, t;
  }
  extend(e = {}) {
    const t = new it(e);
    return t.parent = this, this.child = t, t.name = e.name ? e.name : t.parent.name, e.defaultOptions && Object.keys(e.defaultOptions).length > 0 && console.warn(`[tiptap warn]: BREAKING CHANGE: "defaultOptions" is deprecated. Please use "addOptions" instead. Found in extension: "${t.name}".`), t.options = G(V(t, "addOptions", {
      name: t.name
    })), t.storage = G(V(t, "addStorage", {
      name: t.name,
      options: t.options
    })), t;
  }
}
let ha = class {
  constructor(e, t, n) {
    this.isDragging = !1, this.component = e, this.editor = t.editor, this.options = {
      stopEvent: null,
      ignoreMutation: null,
      ...n
    }, this.extension = t.extension, this.node = t.node, this.decorations = t.decorations, this.innerDecorations = t.innerDecorations, this.view = t.view, this.HTMLAttributes = t.HTMLAttributes, this.getPos = t.getPos, this.mount();
  }
  mount() {
  }
  get dom() {
    return this.editor.view.dom;
  }
  get contentDOM() {
    return null;
  }
  onDragStart(e) {
    var t, n, i, o, s, a, l;
    const { view: c } = this.editor, d = e.target, p = d.nodeType === 3 ? (t = d.parentElement) === null || t === void 0 ? void 0 : t.closest("[data-drag-handle]") : d.closest("[data-drag-handle]");
    if (!this.dom || !((n = this.contentDOM) === null || n === void 0) && n.contains(d) || !p)
      return;
    let f = 0, h = 0;
    if (this.dom !== p) {
      const M = this.dom.getBoundingClientRect(), _ = p.getBoundingClientRect(), R = (i = e.offsetX) !== null && i !== void 0 ? i : (o = e.nativeEvent) === null || o === void 0 ? void 0 : o.offsetX, F = (s = e.offsetY) !== null && s !== void 0 ? s : (a = e.nativeEvent) === null || a === void 0 ? void 0 : a.offsetY;
      f = _.x - M.x + R, h = _.y - M.y + F;
    }
    const b = this.dom.cloneNode(!0);
    (l = e.dataTransfer) === null || l === void 0 || l.setDragImage(b, f, h);
    const m = this.getPos();
    if (typeof m != "number")
      return;
    const y = S.create(c.state.doc, m), v = c.state.tr.setSelection(y);
    c.dispatch(v);
  }
  stopEvent(e) {
    var t;
    if (!this.dom)
      return !1;
    if (typeof this.options.stopEvent == "function")
      return this.options.stopEvent({ event: e });
    const n = e.target;
    if (!(this.dom.contains(n) && !(!((t = this.contentDOM) === null || t === void 0) && t.contains(n))))
      return !1;
    const o = e.type.startsWith("drag"), s = e.type === "drop";
    if ((["INPUT", "BUTTON", "SELECT", "TEXTAREA"].includes(n.tagName) || n.isContentEditable) && !s && !o)
      return !0;
    const { isEditable: l } = this.editor, { isDragging: c } = this, d = !!this.node.type.spec.draggable, p = S.isSelectable(this.node), f = e.type === "copy", h = e.type === "paste", b = e.type === "cut", m = e.type === "mousedown";
    if (!d && p && o && e.target === this.dom && e.preventDefault(), d && o && !c && e.target === this.dom)
      return e.preventDefault(), !1;
    if (d && l && !c && m) {
      const y = n.closest("[data-drag-handle]");
      y && (this.dom === y || this.dom.contains(y)) && (this.isDragging = !0, document.addEventListener("dragend", () => {
        this.isDragging = !1;
      }, { once: !0 }), document.addEventListener("drop", () => {
        this.isDragging = !1;
      }, { once: !0 }), document.addEventListener("mouseup", () => {
        this.isDragging = !1;
      }, { once: !0 }));
    }
    return !(c || s || f || h || b || m && p);
  }
  /**
   * Called when a DOM [mutation](https://developer.mozilla.org/en-US/docs/Web/API/MutationObserver) or a selection change happens within the view.
   * @return `false` if the editor should re-read the selection or re-parse the range around the mutation
   * @return `true` if it can safely be ignored.
   */
  ignoreMutation(e) {
    return !this.dom || !this.contentDOM ? !0 : typeof this.options.ignoreMutation == "function" ? this.options.ignoreMutation({ mutation: e }) : this.node.isLeaf || this.node.isAtom ? !0 : e.type === "selection" || this.dom.contains(e.target) && e.type === "childList" && (Be() || Mt()) && this.editor.isFocused && [
      ...Array.from(e.addedNodes),
      ...Array.from(e.removedNodes)
    ].every((n) => n.isContentEditable) ? !1 : this.contentDOM === e.target && e.type === "attributes" ? !0 : !this.contentDOM.contains(e.target);
  }
  /**
   * Update the attributes of the prosemirror node.
   */
  updateAttributes(e) {
    this.editor.commands.command(({ tr: t }) => {
      const n = this.getPos();
      return typeof n != "number" ? !1 : (t.setNodeMarkup(n, void 0, {
        ...this.node.attrs,
        ...e
      }), !0);
    });
  }
  /**
   * Delete the node.
   */
  deleteNode() {
    const e = this.getPos();
    if (typeof e != "number")
      return;
    const t = e + this.node.nodeSize;
    this.editor.commands.deleteRange({ from: e, to: t });
  }
};
var Or = { exports: {} }, wt = {};
/**
 * @license React
 * use-sync-external-store-shim.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
var Sn;
function ma() {
  if (Sn) return wt;
  Sn = 1;
  var r = O;
  function e(p, f) {
    return p === f && (p !== 0 || 1 / p === 1 / f) || p !== p && f !== f;
  }
  var t = typeof Object.is == "function" ? Object.is : e, n = r.useState, i = r.useEffect, o = r.useLayoutEffect, s = r.useDebugValue;
  function a(p, f) {
    var h = f(), b = n({ inst: { value: h, getSnapshot: f } }), m = b[0].inst, y = b[1];
    return o(function() {
      m.value = h, m.getSnapshot = f, l(m) && y({ inst: m });
    }, [p, h, f]), i(function() {
      return l(m) && y({ inst: m }), p(function() {
        l(m) && y({ inst: m });
      });
    }, [p]), s(h), h;
  }
  function l(p) {
    var f = p.getSnapshot;
    p = p.value;
    try {
      var h = f();
      return !t(p, h);
    } catch {
      return !0;
    }
  }
  function c(p, f) {
    return f();
  }
  var d = typeof window > "u" || typeof window.document > "u" || typeof window.document.createElement > "u" ? c : a;
  return wt.useSyncExternalStore = r.useSyncExternalStore !== void 0 ? r.useSyncExternalStore : d, wt;
}
Or.exports = ma();
var Rr = Or.exports;
const ga = (...r) => (e) => {
  r.forEach((t) => {
    typeof t == "function" ? t(e) : t && (t.current = e);
  });
}, ba = ({ contentComponent: r }) => {
  const e = Rr.useSyncExternalStore(r.subscribe, r.getSnapshot, r.getServerSnapshot);
  return O.createElement(O.Fragment, null, Object.values(e));
};
function ya() {
  const r = /* @__PURE__ */ new Set();
  let e = {};
  return {
    /**
     * Subscribe to the editor instance's changes.
     */
    subscribe(t) {
      return r.add(t), () => {
        r.delete(t);
      };
    },
    getSnapshot() {
      return e;
    },
    getServerSnapshot() {
      return e;
    },
    /**
     * Adds a new NodeView Renderer to the editor.
     */
    setRenderer(t, n) {
      e = {
        ...e,
        [t]: Hr.createPortal(n.reactElement, n.element, t)
      }, r.forEach((i) => i());
    },
    /**
     * Removes a NodeView Renderer from the editor.
     */
    removeRenderer(t) {
      const n = { ...e };
      delete n[t], e = n, r.forEach((i) => i());
    }
  };
}
class xa extends O.Component {
  constructor(e) {
    var t;
    super(e), this.editorContentRef = O.createRef(), this.initialized = !1, this.state = {
      hasContentComponentInitialized: !!(!((t = e.editor) === null || t === void 0) && t.contentComponent)
    };
  }
  componentDidMount() {
    this.init();
  }
  componentDidUpdate() {
    this.init();
  }
  init() {
    const e = this.props.editor;
    if (e && !e.isDestroyed && e.options.element) {
      if (e.contentComponent)
        return;
      const t = this.editorContentRef.current;
      t.append(...e.options.element.childNodes), e.setOptions({
        element: t
      }), e.contentComponent = ya(), this.state.hasContentComponentInitialized || (this.unsubscribeToContentComponent = e.contentComponent.subscribe(() => {
        this.setState((n) => n.hasContentComponentInitialized ? n : {
          hasContentComponentInitialized: !0
        }), this.unsubscribeToContentComponent && this.unsubscribeToContentComponent();
      })), e.createNodeViews(), this.initialized = !0;
    }
  }
  componentWillUnmount() {
    const e = this.props.editor;
    if (!e || (this.initialized = !1, e.isDestroyed || e.view.setProps({
      nodeViews: {}
    }), this.unsubscribeToContentComponent && this.unsubscribeToContentComponent(), e.contentComponent = null, !e.options.element.firstChild))
      return;
    const t = document.createElement("div");
    t.append(...e.options.element.childNodes), e.setOptions({
      element: t
    });
  }
  render() {
    const { editor: e, innerRef: t, ...n } = this.props;
    return O.createElement(
      O.Fragment,
      null,
      O.createElement("div", { ref: ga(t, this.editorContentRef), ...n }),
      (e == null ? void 0 : e.contentComponent) && O.createElement(ba, { contentComponent: e.contentComponent })
    );
  }
}
const va = At((r, e) => {
  const t = O.useMemo(() => Math.floor(Math.random() * 4294967295).toString(), [r.editor]);
  return O.createElement(xa, {
    key: t,
    innerRef: e,
    ...r
  });
});
O.memo(va);
var kt = {};
/**
 * @license React
 * use-sync-external-store-shim/with-selector.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
var Nn;
function wa() {
  if (Nn) return kt;
  Nn = 1;
  var r = O, e = Rr;
  function t(c, d) {
    return c === d && (c !== 0 || 1 / c === 1 / d) || c !== c && d !== d;
  }
  var n = typeof Object.is == "function" ? Object.is : t, i = e.useSyncExternalStore, o = r.useRef, s = r.useEffect, a = r.useMemo, l = r.useDebugValue;
  return kt.useSyncExternalStoreWithSelector = function(c, d, p, f, h) {
    var b = o(null);
    if (b.current === null) {
      var m = { hasValue: !1, value: null };
      b.current = m;
    } else m = b.current;
    b = a(function() {
      function v(T) {
        if (!M) {
          if (M = !0, _ = T, T = f(T), h !== void 0 && m.hasValue) {
            var $ = m.value;
            if (h($, T)) return R = $;
          }
          return R = T;
        }
        if ($ = R, n(_, T)) return $;
        var U = f(T);
        return h !== void 0 && h($, U) ? $ : (_ = T, R = U);
      }
      var M = !1, _, R, F = p === void 0 ? null : p;
      return [function() {
        return v(d());
      }, F === null ? void 0 : function() {
        return v(F());
      }];
    }, [d, p, f, h]);
    var y = i(c, b[0], b[1]);
    return s(function() {
      m.hasValue = !0, m.value = y;
    }, [y]), l(y), y;
  }, kt;
}
wa();
const ka = Tn({
  editor: null
});
ka.Consumer;
const zr = Tn({
  onDragStart: void 0
}), Sa = () => $r(zr), ct = O.forwardRef((r, e) => {
  const { onDragStart: t } = Sa(), n = r.as || "div";
  return (
    // @ts-ignore
    O.createElement(n, { ...r, ref: e, "data-node-view-wrapper": "", onDragStart: t, style: {
      whiteSpace: "normal",
      ...r.style
    } })
  );
});
function Cn(r) {
  return !!(typeof r == "function" && r.prototype && r.prototype.isReactComponent);
}
function En(r) {
  return !!(typeof r == "object" && r.$$typeof && (r.$$typeof.toString() === "Symbol(react.forward_ref)" || r.$$typeof.description === "react.forward_ref"));
}
function Na(r) {
  return !!(typeof r == "object" && r.$$typeof && (r.$$typeof.toString() === "Symbol(react.memo)" || r.$$typeof.description === "react.memo"));
}
function Ca(r) {
  if (Cn(r) || En(r))
    return !0;
  if (Na(r)) {
    const e = r.type;
    if (e)
      return Cn(e) || En(e);
  }
  return !1;
}
function Ea() {
  try {
    if (Gt)
      return parseInt(Gt.split(".")[0], 10) >= 19;
  } catch {
  }
  return !1;
}
class _a {
  /**
   * Immediately creates element and renders the provided React component.
   */
  constructor(e, { editor: t, props: n = {}, as: i = "div", className: o = "" }) {
    this.ref = null, this.id = Math.floor(Math.random() * 4294967295).toString(), this.component = e, this.editor = t, this.props = n, this.element = document.createElement(i), this.element.classList.add("react-renderer"), o && this.element.classList.add(...o.split(" ")), this.editor.isInitialized ? Ur(() => {
      this.render();
    }) : queueMicrotask(() => {
      this.render();
    });
  }
  /**
   * Render the React component.
   */
  render() {
    var e;
    const t = this.component, n = this.props, i = this.editor, o = Ea(), s = Ca(t), a = { ...n };
    a.ref && !(o || s) && delete a.ref, !a.ref && (o || s) && (a.ref = (l) => {
      this.ref = l;
    }), this.reactElement = O.createElement(t, { ...a }), (e = i == null ? void 0 : i.contentComponent) === null || e === void 0 || e.setRenderer(this.id, this);
  }
  /**
   * Re-renders the React component with new props.
   */
  updateProps(e = {}) {
    this.props = {
      ...this.props,
      ...e
    }, this.render();
  }
  /**
   * Destroy the React component.
   */
  destroy() {
    var e;
    const t = this.editor;
    (e = t == null ? void 0 : t.contentComponent) === null || e === void 0 || e.removeRenderer(this.id);
  }
  /**
   * Update the attributes of the element that holds the React component.
   */
  updateAttributes(e) {
    Object.keys(e).forEach((t) => {
      this.element.setAttribute(t, e[t]);
    });
  }
}
class Ma extends ha {
  constructor(e, t, n) {
    if (super(e, t, n), !this.node.isLeaf) {
      this.options.contentDOMElementTag ? this.contentDOMElement = document.createElement(this.options.contentDOMElementTag) : this.contentDOMElement = document.createElement(this.node.isInline ? "span" : "div"), this.contentDOMElement.dataset.nodeViewContentReact = "", this.contentDOMElement.dataset.nodeViewWrapper = "", this.contentDOMElement.style.whiteSpace = "inherit";
      const i = this.dom.querySelector("[data-node-view-content]");
      if (!i)
        return;
      i.appendChild(this.contentDOMElement);
    }
  }
  /**
   * Setup the React component.
   * Called on initialization.
   */
  mount() {
    const e = {
      editor: this.editor,
      node: this.node,
      decorations: this.decorations,
      innerDecorations: this.innerDecorations,
      view: this.view,
      selected: !1,
      extension: this.extension,
      HTMLAttributes: this.HTMLAttributes,
      getPos: () => this.getPos(),
      updateAttributes: (c = {}) => this.updateAttributes(c),
      deleteNode: () => this.deleteNode(),
      ref: Lr()
    };
    if (!this.component.displayName) {
      const c = (d) => d.charAt(0).toUpperCase() + d.substring(1);
      this.component.displayName = c(this.extension.name);
    }
    const i = { onDragStart: this.onDragStart.bind(this), nodeViewContentRef: (c) => {
      c && this.contentDOMElement && c.firstChild !== this.contentDOMElement && (c.hasAttribute("data-node-view-wrapper") && c.removeAttribute("data-node-view-wrapper"), c.appendChild(this.contentDOMElement));
    } }, o = this.component, s = Pr((c) => O.createElement(zr.Provider, { value: i }, Ge(o, c)));
    s.displayName = "ReactNodeView";
    let a = this.node.isInline ? "span" : "div";
    this.options.as && (a = this.options.as);
    const { className: l = "" } = this.options;
    this.handleSelectionUpdate = this.handleSelectionUpdate.bind(this), this.renderer = new _a(s, {
      editor: this.editor,
      props: e,
      as: a,
      className: `node-${this.node.type.name} ${l}`.trim()
    }), this.editor.on("selectionUpdate", this.handleSelectionUpdate), this.updateElementAttributes();
  }
  /**
   * Return the DOM element.
   * This is the element that will be used to display the node view.
   */
  get dom() {
    var e;
    if (this.renderer.element.firstElementChild && !(!((e = this.renderer.element.firstElementChild) === null || e === void 0) && e.hasAttribute("data-node-view-wrapper")))
      throw Error("Please use the NodeViewWrapper component for your node view.");
    return this.renderer.element;
  }
  /**
   * Return the content DOM element.
   * This is the element that will be used to display the rich-text content of the node.
   */
  get contentDOM() {
    return this.node.isLeaf ? null : this.contentDOMElement;
  }
  /**
   * On editor selection update, check if the node is selected.
   * If it is, call `selectNode`, otherwise call `deselectNode`.
   */
  handleSelectionUpdate() {
    const { from: e, to: t } = this.editor.state.selection, n = this.getPos();
    if (typeof n == "number")
      if (e <= n && t >= n + this.node.nodeSize) {
        if (this.renderer.props.selected)
          return;
        this.selectNode();
      } else {
        if (!this.renderer.props.selected)
          return;
        this.deselectNode();
      }
  }
  /**
   * On update, update the React component.
   * To prevent unnecessary updates, the `update` option can be used.
   */
  update(e, t, n) {
    const i = (o) => {
      this.renderer.updateProps(o), typeof this.options.attrs == "function" && this.updateElementAttributes();
    };
    if (e.type !== this.node.type)
      return !1;
    if (typeof this.options.update == "function") {
      const o = this.node, s = this.decorations, a = this.innerDecorations;
      return this.node = e, this.decorations = t, this.innerDecorations = n, this.options.update({
        oldNode: o,
        oldDecorations: s,
        newNode: e,
        newDecorations: t,
        oldInnerDecorations: a,
        innerDecorations: n,
        updateProps: () => i({ node: e, decorations: t, innerDecorations: n })
      });
    }
    return e === this.node && this.decorations === t && this.innerDecorations === n || (this.node = e, this.decorations = t, this.innerDecorations = n, i({ node: e, decorations: t, innerDecorations: n })), !0;
  }
  /**
   * Select the node.
   * Add the `selected` prop and the `ProseMirror-selectednode` class.
   */
  selectNode() {
    this.renderer.updateProps({
      selected: !0
    }), this.renderer.element.classList.add("ProseMirror-selectednode");
  }
  /**
   * Deselect the node.
   * Remove the `selected` prop and the `ProseMirror-selectednode` class.
   */
  deselectNode() {
    this.renderer.updateProps({
      selected: !1
    }), this.renderer.element.classList.remove("ProseMirror-selectednode");
  }
  /**
   * Destroy the React component instance.
   */
  destroy() {
    this.renderer.destroy(), this.editor.off("selectionUpdate", this.handleSelectionUpdate), this.contentDOMElement = null;
  }
  /**
   * Update the attributes of the top-level element that holds the React component.
   * Applying the attributes defined in the `attrs` option.
   */
  updateElementAttributes() {
    if (this.options.attrs) {
      let e = {};
      if (typeof this.options.attrs == "function") {
        const t = this.editor.extensionManager.attributes, n = Jo(this.node, t);
        e = this.options.attrs({ node: this.node, HTMLAttributes: n });
      } else
        e = this.options.attrs;
      this.renderer.updateAttributes(e);
    }
  }
}
function Aa(r, e) {
  return (t) => t.editor.contentComponent ? new Ma(r, t, e) : {};
}
function dt({
  subId: r,
  defaultAttrs: e,
  view: t
}) {
  const n = `${ci}/${r}`, i = Rn(
    r.replace(/-([a-z])/g, (o, s) => s.toUpperCase())
  );
  return it.create({
    name: i,
    group: "block",
    atom: !0,
    selectable: !0,
    draggable: !0,
    addAttributes() {
      return {
        attrs: {
          default: e,
          parseHTML: (o) => Le(o.getAttribute("data-attrs") ?? "", e),
          renderHTML: (o) => ({
            "data-attrs": ve(o.attrs ?? e)
          })
        }
      };
    },
    parseHTML() {
      return [{ tag: `div[data-cms-block="${n}"]` }];
    },
    renderHTML({ HTMLAttributes: o }) {
      return [
        "div",
        Nr(o, { "data-cms-block": n })
      ];
    },
    addNodeView() {
      return Aa((o) => {
        const s = o.node.attrs.attrs ?? e;
        return /* @__PURE__ */ u(t, { attrs: s, updateAttrs: (l) => {
          o.updateAttributes({ attrs: { ...s, ...l } });
        }, selected: o.selected });
      });
    }
  });
}
function ut(r) {
  return Rn(r.replace(/-([a-z])/g, (e, t) => t.toUpperCase()));
}
const Jt = "header-buttons", _e = ut(Jt);
function Ta({ attrs: r, selected: e }) {
  const { t } = ot("theme-marketplace-core"), n = !!(r.downloadUrl || r.previewUrl);
  return /* @__PURE__ */ u(
    ct,
    {
      contentEditable: !1,
      className: "my-4 rounded-lg border border-dashed border-surface-300 bg-surface-50 p-4 dark:border-surface-600 dark:bg-surface-900 " + (e ? "ring-2 ring-blue-500/60" : ""),
      children: /* @__PURE__ */ g("div", { className: "flex items-start gap-3", children: [
        /* @__PURE__ */ u(Bn, { className: "h-5 w-5 shrink-0 text-blue-500" }),
        /* @__PURE__ */ g("div", { className: "min-w-0 flex-1", children: [
          /* @__PURE__ */ u("p", { className: "text-xs font-semibold uppercase tracking-wide text-surface-500 dark:text-surface-400", children: t("blocks.headerButtons.title") }),
          /* @__PURE__ */ u("p", { className: "text-sm text-surface-900 dark:text-surface-50 truncate", children: n ? [r.downloadUrl, r.previewUrl].filter(Boolean).join(" · ") : t("blocks.headerButtons.untitled") })
        ] })
      ] })
    }
  );
}
function Ia({ editor: r }) {
  const e = r.getAttributes(_e), t = { ...Pe, ...e.attrs ?? {} };
  function n(i) {
    r.chain().updateAttributes(_e, { attrs: { ...t, ...i } }).run();
  }
  return /* @__PURE__ */ g("div", { className: "space-y-3", children: [
    /* @__PURE__ */ g("div", { className: "grid grid-cols-[1fr_2fr] gap-2", children: [
      /* @__PURE__ */ g("div", { children: [
        /* @__PURE__ */ u("label", { className: "label", children: "Byline prefix" }),
        /* @__PURE__ */ u(
          "input",
          {
            className: "input",
            placeholder: "by",
            value: t.creatorPrefix,
            onChange: (i) => n({ creatorPrefix: i.target.value })
          }
        )
      ] }),
      /* @__PURE__ */ g("div", { children: [
        /* @__PURE__ */ u("label", { className: "label", children: "Created by" }),
        /* @__PURE__ */ u(
          "input",
          {
            className: "input",
            placeholder: "Brad Frost",
            value: t.creator,
            onChange: (i) => n({ creator: i.target.value })
          }
        )
      ] })
    ] }),
    /* @__PURE__ */ g("div", { children: [
      /* @__PURE__ */ u("label", { className: "label", children: "Download URL" }),
      /* @__PURE__ */ u(
        "input",
        {
          type: "url",
          className: "input",
          placeholder: "https://github.com/example/your-project/releases/latest",
          value: t.downloadUrl,
          onChange: (i) => n({ downloadUrl: i.target.value })
        }
      )
    ] }),
    /* @__PURE__ */ g("div", { children: [
      /* @__PURE__ */ u("label", { className: "label", children: "Live Preview URL" }),
      /* @__PURE__ */ u(
        "input",
        {
          type: "url",
          className: "input",
          placeholder: "https://demo.example.com",
          value: t.previewUrl,
          onChange: (i) => n({ previewUrl: i.target.value })
        }
      )
    ] }),
    /* @__PURE__ */ g("div", { className: "grid grid-cols-2 gap-2", children: [
      /* @__PURE__ */ g("div", { children: [
        /* @__PURE__ */ u("label", { className: "label", children: "Download label" }),
        /* @__PURE__ */ u(
          "input",
          {
            className: "input",
            value: t.downloadLabel,
            onChange: (i) => n({ downloadLabel: i.target.value })
          }
        )
      ] }),
      /* @__PURE__ */ g("div", { children: [
        /* @__PURE__ */ u("label", { className: "label", children: "Preview label" }),
        /* @__PURE__ */ u(
          "input",
          {
            className: "input",
            value: t.previewLabel,
            onChange: (i) => n({ previewLabel: i.target.value })
          }
        )
      ] })
    ] }),
    /* @__PURE__ */ g("div", { children: [
      /* @__PURE__ */ u("label", { className: "label", children: "Free badge label" }),
      /* @__PURE__ */ u(
        "input",
        {
          className: "input",
          value: t.freeLabel,
          onChange: (i) => n({ freeLabel: i.target.value })
        }
      )
    ] })
  ] });
}
const Oa = dt({
  subId: Jt,
  defaultAttrs: Pe,
  view: Ta
}), Ra = {
  id: `marketplace-core/${Jt}`,
  nodeName: _e,
  titleKey: "blocks.headerButtons.title",
  namespace: "theme-marketplace-core",
  icon: Bn,
  category: "layout",
  extensions: [Oa],
  insert: (r) => {
    r.focus().insertContent({ type: _e, attrs: { attrs: Pe } }).run();
  },
  isActive: (r) => r.isActive(_e),
  inspector: (r) => /* @__PURE__ */ u(Ia, { editor: r.editor })
}, Vt = "gallery", Me = ut(Vt);
function za({ attrs: r, selected: e }) {
  const { t } = ot("theme-marketplace-core");
  return /* @__PURE__ */ u(
    ct,
    {
      contentEditable: !1,
      className: "my-4 rounded-lg border border-dashed border-surface-300 bg-surface-50 p-4 dark:border-surface-600 dark:bg-surface-900 " + (e ? "ring-2 ring-blue-500/60" : ""),
      children: /* @__PURE__ */ g("div", { className: "flex items-start gap-3", children: [
        /* @__PURE__ */ u(Tt, { className: "h-5 w-5 shrink-0 text-blue-500" }),
        /* @__PURE__ */ g("div", { className: "min-w-0 flex-1", children: [
          /* @__PURE__ */ u("p", { className: "text-xs font-semibold uppercase tracking-wide text-surface-500 dark:text-surface-400", children: t("blocks.gallery.title") }),
          /* @__PURE__ */ u("p", { className: "text-sm text-surface-900 dark:text-surface-50 truncate", children: t("blocks.gallery.count", { n: r.images.length }) })
        ] })
      ] })
    }
  );
}
function Ba({ editor: r }) {
  const e = r.getAttributes(Me), t = { ...$e, ...e.attrs ?? {} }, [n, i] = he(!1);
  function o(c) {
    r.chain().updateAttributes(Me, { attrs: { ...t, ...c } }).run();
  }
  function s(c, d) {
    const p = [...t.images];
    p[c] = d, o({ images: p });
  }
  function a(c) {
    o({ images: t.images.filter((d, p) => p !== c) });
  }
  function l(c, d) {
    const p = c + d;
    if (p < 0 || p >= t.images.length) return;
    const f = [...t.images];
    [f[c], f[p]] = [f[p], f[c]], o({ images: f });
  }
  return /* @__PURE__ */ g("div", { className: "space-y-3", children: [
    t.images.length === 0 && /* @__PURE__ */ u("p", { className: "text-xs text-surface-500", children: 'No images yet — click "Add image" to pick from the media library.' }),
    t.images.map((c, d) => /* @__PURE__ */ g(
      "div",
      {
        className: "flex items-start gap-2 rounded border border-surface-200 p-2 dark:border-surface-700",
        children: [
          c.url && /* @__PURE__ */ u("img", { src: c.url, alt: c.alt, className: "h-16 w-16 object-cover rounded" }),
          /* @__PURE__ */ g("div", { className: "flex-1 min-w-0", children: [
            /* @__PURE__ */ u(
              "input",
              {
                className: "input text-xs",
                placeholder: "Image alt",
                value: c.alt,
                onChange: (p) => s(d, { ...c, alt: p.target.value })
              }
            ),
            /* @__PURE__ */ u("p", { className: "text-[10px] text-surface-500 mt-1 truncate", title: c.url, children: c.url })
          ] }),
          /* @__PURE__ */ g("div", { className: "flex flex-col gap-1", children: [
            /* @__PURE__ */ u(
              "button",
              {
                type: "button",
                onClick: () => l(d, -1),
                disabled: d === 0,
                className: "btn-ghost p-1",
                title: "Move up",
                children: /* @__PURE__ */ u(Ii, { className: "h-3 w-3" })
              }
            ),
            /* @__PURE__ */ u(
              "button",
              {
                type: "button",
                onClick: () => l(d, 1),
                disabled: d === t.images.length - 1,
                className: "btn-ghost p-1",
                title: "Move down",
                children: /* @__PURE__ */ u(Ti, { className: "h-3 w-3" })
              }
            ),
            /* @__PURE__ */ u(
              "button",
              {
                type: "button",
                onClick: () => a(d),
                className: "btn-ghost p-1 text-red-600",
                title: "Remove",
                children: /* @__PURE__ */ u(st, { className: "h-3 w-3" })
              }
            )
          ] })
        ]
      },
      d
    )),
    /* @__PURE__ */ g(
      "button",
      {
        type: "button",
        onClick: () => i(!0),
        className: "btn-secondary text-xs w-full",
        children: [
          /* @__PURE__ */ u(Tt, { className: "h-3.5 w-3.5" }),
          "Add image from library"
        ]
      }
    ),
    n && /* @__PURE__ */ u(
      Fr,
      {
        onClose: () => i(!1),
        onPick: (c) => {
          i(!1);
          const d = pt(c, "large") || pt(c, "medium") || pt(c);
          d && o({ images: [...t.images, { url: d, alt: c.alt ?? "" }] });
        }
      }
    )
  ] });
}
const Fa = dt({
  subId: Vt,
  defaultAttrs: $e,
  view: za
}), La = {
  id: `marketplace-core/${Vt}`,
  nodeName: Me,
  titleKey: "blocks.gallery.title",
  namespace: "theme-marketplace-core",
  icon: Tt,
  category: "media",
  extensions: [Fa],
  insert: (r) => {
    r.focus().insertContent({ type: Me, attrs: { attrs: $e } }).run();
  },
  isActive: (r) => r.isActive(Me),
  inspector: (r) => /* @__PURE__ */ u(Ba, { editor: r.editor })
}, Wt = "specs", Ae = ut(Wt);
function Pa({ attrs: r, selected: e }) {
  const { t } = ot("theme-marketplace-core"), n = r.rows.map((i) => i.label).filter(Boolean).slice(0, 3).join(" · ");
  return /* @__PURE__ */ u(
    ct,
    {
      contentEditable: !1,
      className: "my-4 rounded-lg border border-dashed border-surface-300 bg-surface-50 p-4 dark:border-surface-600 dark:bg-surface-900 " + (e ? "ring-2 ring-blue-500/60" : ""),
      children: /* @__PURE__ */ g("div", { className: "flex items-start gap-3", children: [
        /* @__PURE__ */ u(Fn, { className: "h-5 w-5 shrink-0 text-blue-500" }),
        /* @__PURE__ */ g("div", { className: "min-w-0 flex-1", children: [
          /* @__PURE__ */ u("p", { className: "text-xs font-semibold uppercase tracking-wide text-surface-500 dark:text-surface-400", children: t("blocks.specs.title") }),
          /* @__PURE__ */ u("p", { className: "text-sm text-surface-900 dark:text-surface-50 truncate", children: n || t("blocks.specs.untitled") })
        ] })
      ] })
    }
  );
}
function $a({ editor: r }) {
  const e = r.getAttributes(Ae), t = { ...De, ...e.attrs ?? {} };
  function n(a) {
    r.chain().updateAttributes(Ae, { attrs: { ...t, ...a } }).run();
  }
  function i(a, l, c) {
    const d = [...t.rows];
    d[a] = { ...d[a], [l]: c }, n({ rows: d });
  }
  function o() {
    n({ rows: [...t.rows, { label: "", value: "" }] });
  }
  function s(a) {
    n({ rows: t.rows.filter((l, c) => c !== a) });
  }
  return /* @__PURE__ */ g("div", { className: "space-y-3", children: [
    /* @__PURE__ */ g("div", { children: [
      /* @__PURE__ */ u("label", { className: "label", children: "Section heading" }),
      /* @__PURE__ */ u("input", { className: "input", value: t.heading, onChange: (a) => n({ heading: a.target.value }) })
    ] }),
    t.rows.map((a, l) => /* @__PURE__ */ g("div", { className: "space-y-2 rounded border border-surface-200 p-2 dark:border-surface-700", children: [
      /* @__PURE__ */ g("div", { className: "flex items-center justify-between", children: [
        /* @__PURE__ */ g("span", { className: "text-xs font-semibold uppercase text-surface-500", children: [
          "Row ",
          l + 1
        ] }),
        /* @__PURE__ */ u("button", { type: "button", onClick: () => s(l), className: "btn-ghost p-1 text-red-600", children: /* @__PURE__ */ u(st, { className: "h-3 w-3" }) })
      ] }),
      /* @__PURE__ */ g("div", { className: "grid grid-cols-2 gap-2", children: [
        /* @__PURE__ */ g("div", { children: [
          /* @__PURE__ */ u("label", { className: "label", children: "Label" }),
          /* @__PURE__ */ u(
            "input",
            {
              className: "input text-xs",
              value: a.label,
              onChange: (c) => i(l, "label", c.target.value)
            }
          )
        ] }),
        /* @__PURE__ */ g("div", { children: [
          /* @__PURE__ */ u("label", { className: "label", children: "Value" }),
          /* @__PURE__ */ u(
            "input",
            {
              className: "input text-xs",
              value: a.value,
              onChange: (c) => i(l, "value", c.target.value)
            }
          )
        ] })
      ] })
    ] }, l)),
    /* @__PURE__ */ g("button", { type: "button", onClick: o, className: "btn-secondary text-xs w-full", children: [
      /* @__PURE__ */ u(It, { className: "h-3.5 w-3.5" }),
      "Add row"
    ] })
  ] });
}
const Da = dt({
  subId: Wt,
  defaultAttrs: De,
  view: Pa
}), ja = {
  id: `marketplace-core/${Wt}`,
  nodeName: Ae,
  titleKey: "blocks.specs.title",
  namespace: "theme-marketplace-core",
  icon: Fn,
  category: "layout",
  extensions: [Da],
  insert: (r) => {
    r.focus().insertContent({ type: Ae, attrs: { attrs: De } }).run();
  },
  isActive: (r) => r.isActive(Ae),
  inspector: (r) => /* @__PURE__ */ u($a, { editor: r.editor })
}, _n = [
  "dashboard",
  "analytics",
  "monitoring",
  "trending_up",
  "insights",
  "bolt",
  "rocket_launch",
  "auto_awesome",
  "star",
  "favorite",
  "shopping_bag",
  "shopping_cart",
  "credit_card",
  "payments",
  "sell",
  "lock",
  "security",
  "shield",
  "verified_user",
  "key",
  "settings",
  "tune",
  "build",
  "construction",
  "extension",
  "palette",
  "brush",
  "format_paint",
  "color_lens",
  "design_services",
  "code",
  "terminal",
  "data_object",
  "developer_mode",
  "integration_instructions",
  "cloud",
  "cloud_upload",
  "cloud_download",
  "storage",
  "database",
  "search",
  "filter_alt",
  "sort",
  "view_module",
  "view_list",
  "mail",
  "send",
  "chat",
  "forum",
  "notifications",
  "person",
  "group",
  "groups",
  "manage_accounts",
  "support_agent",
  "download",
  "upload",
  "file_download",
  "file_upload",
  "save",
  "language",
  "translate",
  "public",
  "globe",
  "travel_explore",
  "speed",
  "memory",
  "bar_chart",
  "pie_chart",
  "show_chart",
  "shopping_basket",
  "store",
  "inventory",
  "package_2",
  "local_shipping",
  "smartphone",
  "devices",
  "tablet_mac",
  "laptop_mac",
  "tv",
  "schedule",
  "today",
  "event",
  "calendar_month",
  "timer",
  "help",
  "info",
  "question_mark",
  "lightbulb",
  "tips_and_updates",
  "check_circle",
  "task_alt",
  "verified",
  "done",
  "thumb_up",
  "warning",
  "error",
  "block",
  "report",
  "priority_high"
], Mn = "mp-icon-picker-font", Ha = "https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,400,0,0";
function Ua() {
  if (typeof document > "u" || document.getElementById(Mn)) return;
  const r = document.createElement("link");
  r.id = Mn, r.rel = "stylesheet", r.href = Ha, document.head.appendChild(r);
}
const An = {
  fontFamily: '"Material Symbols Outlined"',
  fontWeight: "normal",
  fontStyle: "normal",
  fontSize: 24,
  lineHeight: 1,
  letterSpacing: "normal",
  textTransform: "none",
  display: "inline-block",
  whiteSpace: "nowrap",
  wordWrap: "normal",
  direction: "ltr",
  WebkitFontSmoothing: "antialiased",
  fontVariationSettings: '"FILL" 0'
};
function Ja({
  value: r,
  onChange: e,
  placeholder: t = "e.g. dashboard, security, bolt"
}) {
  const [n, i] = he(!1), [o, s] = he(""), a = Dr(null);
  Yt(() => {
    Ua();
  }, []), Yt(() => {
    if (!n) return;
    const c = (d) => {
      a.current && (a.current.contains(d.target) || i(!1));
    };
    return document.addEventListener("mousedown", c), () => document.removeEventListener("mousedown", c);
  }, [n]);
  const l = jr(() => {
    const c = o.trim().toLowerCase();
    return c ? _n.filter((d) => d.includes(c)) : _n;
  }, [o]);
  return /* @__PURE__ */ g("div", { ref: a, className: "relative", children: [
    /* @__PURE__ */ g("div", { className: "flex items-stretch gap-2", children: [
      /* @__PURE__ */ u(
        "input",
        {
          className: "input text-xs flex-1",
          value: r,
          placeholder: t,
          onChange: (c) => e(c.target.value),
          onFocus: () => i(!0)
        }
      ),
      /* @__PURE__ */ u(
        "button",
        {
          type: "button",
          onClick: () => i((c) => !c),
          className: "flex items-center justify-center w-10 rounded border border-surface-200 bg-surface-50 dark:border-surface-700 dark:bg-surface-800 shrink-0",
          "aria-label": "Pick icon",
          title: r || "No icon selected",
          children: /* @__PURE__ */ u("span", { style: An, children: r || "image" })
        }
      )
    ] }),
    n && /* @__PURE__ */ g("div", { className: "absolute z-20 mt-1 w-full rounded border border-surface-200 bg-white shadow-lg dark:border-surface-700 dark:bg-surface-900", children: [
      /* @__PURE__ */ u("div", { className: "border-b border-surface-100 p-2 dark:border-surface-800", children: /* @__PURE__ */ u(
        "input",
        {
          className: "input text-xs w-full",
          placeholder: "Search icons…",
          value: o,
          onChange: (c) => s(c.target.value),
          autoFocus: !0
        }
      ) }),
      /* @__PURE__ */ u("div", { className: "max-h-60 overflow-y-auto p-2", children: l.length === 0 ? /* @__PURE__ */ u("p", { className: "text-center text-xs text-surface-500 py-4", children: "No match — keep typing in the field above to use it anyway." }) : /* @__PURE__ */ u("div", { className: "grid grid-cols-6 gap-1", children: l.map((c) => /* @__PURE__ */ g(
        "button",
        {
          type: "button",
          title: c,
          onClick: () => {
            e(c), i(!1), s("");
          },
          className: "flex flex-col items-center justify-center gap-1 rounded p-2 text-[10px] " + (c === r ? "bg-blue-100 text-blue-700 dark:bg-blue-900/40 dark:text-blue-300" : "hover:bg-surface-100 text-surface-700 dark:hover:bg-surface-800 dark:text-surface-300"),
          children: [
            /* @__PURE__ */ u("span", { style: An, children: c }),
            /* @__PURE__ */ u("span", { className: "truncate w-full text-center", children: c })
          ]
        },
        c
      )) }) })
    ] })
  ] });
}
const qt = "features", Te = ut(qt);
function Va({ attrs: r, selected: e }) {
  const { t } = ot("theme-marketplace-core");
  return /* @__PURE__ */ u(
    ct,
    {
      contentEditable: !1,
      className: "my-4 rounded-lg border border-dashed border-surface-300 bg-surface-50 p-4 dark:border-surface-600 dark:bg-surface-900 " + (e ? "ring-2 ring-blue-500/60" : ""),
      children: /* @__PURE__ */ g("div", { className: "flex items-start gap-3", children: [
        /* @__PURE__ */ u(Pn, { className: "h-5 w-5 shrink-0 text-blue-500" }),
        /* @__PURE__ */ g("div", { className: "min-w-0 flex-1", children: [
          /* @__PURE__ */ u("p", { className: "text-xs font-semibold uppercase tracking-wide text-surface-500 dark:text-surface-400", children: t("blocks.features.title") }),
          /* @__PURE__ */ u("p", { className: "text-sm text-surface-900 dark:text-surface-50 truncate", children: t("blocks.features.count", { n: r.items.length }) })
        ] })
      ] })
    }
  );
}
function Wa({ editor: r }) {
  const e = r.getAttributes(Te), t = { ...je, ...e.attrs ?? {} };
  function n(a) {
    r.chain().updateAttributes(Te, { attrs: { ...t, ...a } }).run();
  }
  function i(a, l, c) {
    const d = [...t.items];
    d[a] = { ...d[a], [l]: c }, n({ items: d });
  }
  function o() {
    n({
      items: [...t.items, { icon: "bolt", title: "" }]
    });
  }
  function s(a) {
    n({ items: t.items.filter((l, c) => c !== a) });
  }
  return /* @__PURE__ */ g("div", { className: "space-y-3", children: [
    /* @__PURE__ */ g("div", { children: [
      /* @__PURE__ */ u("label", { className: "label", children: "Section heading" }),
      /* @__PURE__ */ u("input", { className: "input", value: t.heading, onChange: (a) => n({ heading: a.target.value }) })
    ] }),
    t.items.map((a, l) => /* @__PURE__ */ g("div", { className: "space-y-2 rounded border border-surface-200 p-2 dark:border-surface-700", children: [
      /* @__PURE__ */ g("div", { className: "flex items-center justify-between", children: [
        /* @__PURE__ */ g("span", { className: "text-xs font-semibold uppercase text-surface-500", children: [
          "Feature ",
          l + 1
        ] }),
        /* @__PURE__ */ u("button", { type: "button", onClick: () => s(l), className: "btn-ghost p-1 text-red-600", children: /* @__PURE__ */ u(st, { className: "h-3 w-3" }) })
      ] }),
      /* @__PURE__ */ g("div", { children: [
        /* @__PURE__ */ u("label", { className: "label", children: "Icon" }),
        /* @__PURE__ */ u(
          Ja,
          {
            value: a.icon,
            onChange: (c) => i(l, "icon", c)
          }
        )
      ] }),
      /* @__PURE__ */ g("div", { children: [
        /* @__PURE__ */ u("label", { className: "label", children: "Title" }),
        /* @__PURE__ */ u(
          "input",
          {
            className: "input text-xs",
            value: a.title,
            onChange: (c) => i(l, "title", c.target.value)
          }
        )
      ] })
    ] }, l)),
    /* @__PURE__ */ g("button", { type: "button", onClick: o, className: "btn-secondary text-xs w-full", children: [
      /* @__PURE__ */ u(It, { className: "h-3.5 w-3.5" }),
      "Add feature"
    ] })
  ] });
}
const qa = dt({
  subId: qt,
  defaultAttrs: je,
  view: Va
}), Ka = {
  id: `marketplace-core/${qt}`,
  nodeName: Te,
  titleKey: "blocks.features.title",
  namespace: "theme-marketplace-core",
  icon: Pn,
  category: "layout",
  extensions: [qa],
  insert: (r) => {
    r.focus().insertContent({ type: Te, attrs: { attrs: je } }).run();
  },
  isActive: (r) => r.isActive(Te),
  inspector: (r) => /* @__PURE__ */ u(Wa, { editor: r.editor })
}, Ga = [
  `<div data-cms-block="marketplace-core/header-buttons" data-attrs="${ve(Pe)}"></div>`,
  `<div data-cms-block="marketplace-core/gallery" data-attrs="${ve($e)}"></div>`,
  `<div data-cms-block="marketplace-core/specs" data-attrs="${ve(De)}"></div>`,
  `<div data-cms-block="marketplace-core/features" data-attrs="${ve(je)}"></div>`,
  "",
  "## Description",
  "",
  "Write the long-form description of your theme or plugin here. Markdown is supported.",
  ""
].join(`

`), nl = {
  id: "marketplace-core",
  name: "Marketplace Core",
  version: "1.1.1",
  description: "App-store style theme for listing themes / plugins. Modern Corporate aesthetic with ambient shadows and rounded XL corners.",
  scssEntry: "theme.css",
  cssText: Xt,
  i18n: { en: ye, fr: ri, de: ii, es: oi, nl: si, pt: ai, ko: li },
  defaultPostMarkdown: { post: Ga },
  settings: {
    navLabelKey: "title",
    defaultConfig: X,
    component: zi
  },
  compileCss: (r) => Ei(Xt, r.style),
  imageFormats: {
    inputFormats: [".jpg", ".jpeg", ".png", ".webp"],
    outputFormat: "webp",
    quality: 82,
    formats: {
      small: { width: 480, height: 300, fit: "cover" },
      medium: { width: 800, height: 500, fit: "cover" },
      large: { width: 1600, height: 1e3, fit: "cover" }
    },
    defaultFormat: "medium"
  },
  templates: {
    base: Xr,
    home: Qr,
    single: Zr,
    category: ei,
    author: ti,
    notFound: ni
  },
  blocks: [Ra, La, ja, Ka],
  register(r) {
    r.addFilter("post.html.body", (e) => ki(e));
  }
};
export {
  nl as default
};
